# v2 同一 Reader 全文複查

**PASS_BOUNDED**

在基本Python/list/arithmetic受眾與本文給定CPython實作性前提內，八題均能由公開正文重建，未留需修訂的語意/推導缺口。不是對外部CPython源碼的獨立真實性驗證，也不是人類理解或學習效果結論。

實際 thread ID：01a15ce1-3e75-7a61-9b82-997618be952e

實際讀取路徑：
- `/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/intervals/reader-input-v2/task.json`
- `/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/intervals/reader-input-v2/article.en.md`
- `/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/intervals/reader-input-v2/article.zh-TW.md`

Only judgments anchored by evidence objects marked judgment_reused_from_first_read=true were reused from first-read transcript for exactly unchanged public quotations. No old output files, source docs, author repair notes or expected answers read. All v2 bodies reread; changed memory and representation passages reconstructed anew.

Original reader-input and body-reader-output were neither reread nor modified. First NEEDS_REVISION remains historical evidence.

## Q1: Reconstruct input/result/constraints and mutation contract.

輸入為 1..10000 個 [start,end]，整數端點滿足 0<=start<=end<=10000，表示包含兩端的連續閉區間。輸出各區間互不重疊、按起點排序，且覆蓋恰為輸入 union：端點相接須合併，整數端點不表示僅含整數點，零長度仍覆蓋一點。保留輸入是本文選擇而非原題要求；主程式保留 caller 外層順序與內層值，sorted 建外層 references list，答案另建 pair 才直接修改。空輸入契約外，但程式回傳 []。未承諾處理非法型別或錯誤 pair 長度。

複查/沿用標記：只沿用上述逐字不變正文的契約判斷；v2 全文另已重讀。

> There are between 1 and 10,000 pairs, and their integer endpoints satisfy `0 <= start <= end <= 10000`.

（精確不變引句；沿用判斷）

> The returned intervals must cover exactly the positions covered by the input.

（精確不變引句；沿用判斷）

> Integer endpoints do not mean that the interval contains only integer points.

（精確不變引句；沿用判斷）

> We will return intervals in increasing start order and preserve the caller's input, although preserving it is an implementation choice rather than a requirement stated by the problem.

（精確不變引句；沿用判斷）


## Q2: Derive each choice and the state meaning without external knowledge.

起點不遞減使 left<=start，於是 start<=right 時 union 是 [left,max(right,end)]，不縮短、無內部 gap；start>right 時未來 start 至少一樣大，無法回填 gap，舊尾段定案。merged 的每個 pair 是已處理連通覆蓋群組，並非必為原 pair；只有最後一段尚可往右延伸，左界不後退，故不用回查更早答案。ordered 持原 pair references，lambda 抽各 pair 第一數作 key，一次一組。v2 fresh-pair 機制只對所示原地更新實作成立，不是普遍必要性。

複查/沿用標記：重用精確不變的順序、union、狀態引句判斷；fresh-pair 範圍句重新判讀。

> The important permission is that future starts cannot be smaller than the start currently being processed.

（精確不變引句；沿用判斷）

> A pair in `merged` represents all coverage in one connected group of processed intervals, not necessarily one original input pair.

（精確不變引句；沿用判斷）

> Their union is `[left, max(right, end)]`: keep the earlier left endpoint and whichever right endpoint reaches farther.

（精確不變引句；沿用判斷）

> A growing last interval may reach farther right, but its left endpoint never moves backward to join an earlier result interval.

（精確不變引句；沿用判斷）

> This adaptation keeps the shown implementation's fresh answer pairs, so its in-place endpoint updates cannot change the caller's pairs.

（v2新重建/新比較）


## Q3: Reconstruct a new small legal input with before/after transitions and stopping condition.

這次另構造七組合法輸入，沒有沿用第一輪範例。先按起點排成下列 ordered，逐步狀態如下。0 與 1 之間即使沒有整數點仍有連續位置的 gap，因此 [0,0] 獨立。兩個 start=2 的 pair 順序不影響最大 end=5。七次 visit、三次 append、四次 max 更新之後輸入耗盡，回傳 [[0,0],[1,9],[12,12]]；尾段已在 merged，不需 flush。抽出 v2 的完整碼實際執行，結果與逐步推演相符，輸入值及順序保持。

複查/沿用標記：新輸入、新 before/after trace、新實際執行；停止規則的逐字引句相同而沿用。

> The scan visits each pair in `ordered`, binding its two numbers to `start` and `end`.

（精確不變引句；沿用判斷）

> The loop then runs out of input and returns that list. The last interval is already stored, so no final flush is needed.

（精確不變引句；沿用判斷）


### transitions

```json
[
  {
    "incoming": [
      0,
      0
    ],
    "before": [],
    "branch": "not merged true; right-hand lookup skipped",
    "operation": "append [0,0]",
    "after": [
      [
        0,
        0
      ]
    ]
  },
  {
    "incoming": [
      1,
      2
    ],
    "before": [
      [
        0,
        0
      ]
    ],
    "branch": "1>0 gap",
    "operation": "append [1,2]",
    "after": [
      [
        0,
        0
      ],
      [
        1,
        2
      ]
    ]
  },
  {
    "incoming": [
      2,
      5
    ],
    "before": [
      [
        0,
        0
      ],
      [
        1,
        2
      ]
    ],
    "branch": "2>2 false; touch",
    "operation": "max(2,5)=5",
    "after": [
      [
        0,
        0
      ],
      [
        1,
        5
      ]
    ]
  },
  {
    "incoming": [
      2,
      3
    ],
    "before": [
      [
        0,
        0
      ],
      [
        1,
        5
      ]
    ],
    "branch": "2>5 false; contained",
    "operation": "max(5,3)=5",
    "after": [
      [
        0,
        0
      ],
      [
        1,
        5
      ]
    ]
  },
  {
    "incoming": [
      5,
      6
    ],
    "before": [
      [
        0,
        0
      ],
      [
        1,
        5
      ]
    ],
    "branch": "5>5 false; touch",
    "operation": "max(5,6)=6",
    "after": [
      [
        0,
        0
      ],
      [
        1,
        6
      ]
    ]
  },
  {
    "incoming": [
      6,
      9
    ],
    "before": [
      [
        0,
        0
      ],
      [
        1,
        6
      ]
    ],
    "branch": "6>6 false; touch",
    "operation": "max(6,9)=9",
    "after": [
      [
        0,
        0
      ],
      [
        1,
        9
      ]
    ]
  },
  {
    "incoming": [
      12,
      12
    ],
    "before": [
      [
        0,
        0
      ],
      [
        1,
        9
      ]
    ],
    "branch": "12>9 gap",
    "operation": "append [12,12]",
    "after": [
      [
        0,
        0
      ],
      [
        1,
        9
      ],
      [
        12,
        12
      ]
    ]
  }
]
```

### runtime_observation

```json
{
  "executed": "exact complete v2 English public code block",
  "input": [
    [
      6,
      9
    ],
    [
      0,
      0
    ],
    [
      2,
      5
    ],
    [
      1,
      2
    ],
    [
      12,
      12
    ],
    [
      5,
      6
    ],
    [
      2,
      3
    ]
  ],
  "ordered": [
    [
      0,
      0
    ],
    [
      1,
      2
    ],
    [
      2,
      5
    ],
    [
      2,
      3
    ],
    [
      5,
      6
    ],
    [
      6,
      9
    ],
    [
      12,
      12
    ]
  ],
  "result": [
    [
      0,
      0
    ],
    [
      1,
      9
    ],
    [
      12,
      12
    ]
  ],
  "input_value_and_order_unchanged": true,
  "no_output_pair_is_input_pair": true,
  "en_and_zh_complete_python_blocks_equal": true
}
```

## Q4: Reconstruct correctness, branch boundaries and a failed plausible shortcut.

每次迭代後 invariant 要求 exact union、start-ordered、pairwise non-overlap，且除尾段外對未處理輸入均定案。空初態覆蓋空集合；第一 pair 自成 union。overlap 保留左界與 max end，恰好加入新覆蓋而不縮短或造 gap，故不碰早先群組；gap append 恰好新增本 interval，且未來 start 不會變小，舊尾段永久分離。每次消耗一對，n 有限，終止時 invariant 涵蓋全部。strict > 是 gap；等號走 overlap。錯誤捷徑：[[1,10],[2,3],[4,5]] 若只記前一原始 end，會用 4>3 假造 gap；right=end 也會讓內含縮短。[[5,6],[1,2]] 只刪 sort 沒改公式會丟掉 [1,2]；它否定此程式任意順序套用，沒有證明所有解都必須 sorting。

複查/沿用標記：重用上述逐字不變 invariant、分支與反例判斷；已對 v2 全文重新檢查其邊界。

> "`merged` contains the exact union of the processed intervals as start-ordered, non-overlapping intervals; all but its last interval are final against every unprocessed interval."

（精確不變引句；沿用判斷）

> For an overlap, replacing `[left,right]` with `[left,max(right,end)]` adds exactly the new interval's positions.

（精確不變引句；沿用判斷）

> Future starts are at least `start`, so the old last pair is now final.

（精確不變引句；沿用判斷）

> Each iteration consumes one of the finite `n` input pairs.

（精確不變引句；沿用判斷）

> With `[[1,10], [2,3], [4,5]]`, that compares `4` with `3` and invents a gap.

（精確不變引句；沿用判斷）


## Q5: Reconstruct each stated main/alternative/changed-constraint cost, variables, operation frequencies, aggregate work, auxiliary/transient/output conventions. Quote actual explanatory bridges; flag recalled knowledge.

成本模型把有界整數一次比較、reference read/write、固定兩格 pair 當常數，不假設任意長整數免費。掃描、append幾何級數、sort merge charging、in-place-sort變體、repeated-selection與已排序輸入適配均已盤點，包含主複雜度後文字。v2 sorting workspace 不再只是 proportional n 的結論：新正文給了 m=min(a,b)、2m<=n、one-at-a-time重用、old-buffer釋放，以及 sort/scan分期，使 auxiliary、transient與output的峰值可以從文字計數重建。正文的具體 CPython 行為仍是本次閱讀的明示 premises；未讀連結或用演算法記憶額外補證。

複查/沿用標記：混合：逐字不變的 time/append/variant 引句沿用舊判斷；v2 key/buffer/phase/liveness memory bridge 全部重新推導。

> Count a bounded endpoint comparison, a reference read/write, and a fixed two-slot pair creation as constant work.

（精確不變引句；沿用判斷）

> Peak scratch storage therefore follows the largest individual merge, not the sum of all merges.

（v2新重建/新比較）

> Together with the `n` key slots, these live arrays and records use `O(n)` sorting workspace.

（v2新重建/新比較）


### cost_inventory

```json
[
  {
    "method": "主程式 scan 與結果",
    "variables": "n=input pair count; k=returned count, k<=n",
    "frequency": "n visits；每步 bounded compare/read/write；k append；k fixed-two-slot pairs retained",
    "aggregate": "O(n) bounded work + O(k) total appends = O(n)",
    "auxiliary": "scan loop variables O(1), ordered 仍 live O(n)",
    "output_and_transient": "outer list proportional spare slots + k fresh pairs => O(k) output；array growth若 old/new短暫並存只加固定倍容量，不改上界",
    "evidence": [
      {
        "article": "article.en.md",
        "quote": "The scan visits `n` pairs. Each iteration performs a bounded number of endpoint reads, comparisons and writes. It never searches through `merged`; selecting its last slot uses the stored position directly.",
        "judgment_reused_from_first_read": true
      },
      {
        "article": "article.en.md",
        "quote": "The returned output occupies `O(k)` space: one outer list and `k` fresh two-slot pairs, including proportional spare capacity.",
        "judgment_reused_from_first_read": true
      }
    ]
  },
  {
    "method": "append amortized",
    "variables": "C=final capacity; r<1=preceding capacity fixed ratio; k=appends",
    "frequency": "k ordinary writes；full capacity 時 allocate/copy；single append 可超過常數",
    "aggregate": "S=C+rC+...，S-rS=C-r^(m+1)C<=C，故 S<=C/(1-r)=O(C)；C=O(k)，總寫入與搬移 O(k)",
    "auxiliary": "spare capacity按比例，不把每次 allocate 尺寸相加當 peak",
    "output_and_transient": "buffer capacity O(k)；小配置只固定工作",
    "evidence": [
      {
        "article": "article.en.md",
        "quote": "Therefore `S <= C/(1-r)`. The fixed ratio contributes a constant multiplier, and proportional spare capacity makes `C = O(k)` for `k` appends.",
        "judgment_reused_from_first_read": true
      }
    ]
  },
  {
    "method": "主程式 CPython adaptive sort time",
    "variables": "a,b=run lengths; h=level；n=input count",
    "frequency": "key per pair once；run recognition O(n)；short run insertion max target64，item至多固定positions；<=n boundaries各至多 O(log n) level計算",
    "aggregate": "merge front pointers從不倒退，O(a+b)；conceptual level O(n) × O(log n)；actual Powersort midpoint subdivisions寬 n/2^h，到1則分開，故 levels O(log n)，item path levels decrease不重複同層計費，亦 O(n log n). sort+scan = worst O(n log n)，既有順序可省工作",
    "auxiliary": "見下項 live workspace 分析",
    "output_and_transient": "不將 Program Movie 假裝成 CPython 內部 merge trace",
    "evidence": [
      {
        "article": "article.en.md",
        "quote": "Combining sorted stretches of lengths `a` and `b` takes `O(a+b)` work: compare their front items, move the smaller, and advance its position until both are exhausted.",
        "judgment_reused_from_first_read": true
      },
      {
        "article": "article.en.md",
        "quote": "The schedule merges deeper boundaries before crossing a shallower one. Along an item's path through these merges, levels decrease; the item cannot be charged repeatedly at one level.",
        "judgment_reused_from_first_read": true
      },
      {
        "article": "article.en.md",
        "quote": "CPython also extends short runs by insertion, but the target run length is bounded by 64, so each inserted item crosses only a fixed number of positions; this adds linear work too.",
        "judgment_reused_from_first_read": true
      }
    ]
  },
  {
    "method": "v2 新增 sort live memory bridge",
    "variables": "n key slots; a,b runs; m=min(a,b)",
    "frequency": "key result per input有一reference slot；merge逐次執行，並非所有 merge buffers同時存在",
    "aggregate": "n keys + <=2m<=a+b<=n scratch slots + fixed-size pending records O(log n) => O(n) workspace. ordered n references另外 O(n).",
    "auxiliary": "每次 merge複製較短remaining run 的 keys與matching references，old dynamic buffer先釋放再擴充；single peak不累加所有 merges。sort cleanup before scan；scan phase ordered O(n)+loop O(1)+output O(k)",
    "output_and_transient": "不計 output的 peak O(n)；含 output O(n+k)=O(n)，k<=n；不同階段的 allocation不乘 merge 次數",
    "new_small_accounting_example": "n=10、a=3、b=7 => m=3，single merge最多3 keys+3 pair refs=6 scratch slots，另10 key-reference slots；不是每次 merge增加6個永久slots。這只是依正文模型計費，未觀測CPython內部。",
    "evidence": [
      {
        "article": "article.en.md",
        "quote": "During sorting, the key function's one result per input needs `n` key-reference slots.",
        "judgment_reused_from_first_read": false
      },
      {
        "article": "article.en.md",
        "quote": "With `m = min(a,b)`, this needs at most `m` key slots and `m` matching pair-reference slots: `2m <= a+b <= n`.",
        "judgment_reused_from_first_read": false
      },
      {
        "article": "article.en.md",
        "quote": "Merges execute one at a time and reuse this buffer; when more space is needed, CPython releases the old dynamic buffer before allocating the larger one.",
        "judgment_reused_from_first_read": false
      },
      {
        "article": "article.en.md",
        "quote": "The sort releases its dynamic key-reference array and merge buffer before the interval scan begins.",
        "judgment_reused_from_first_read": false
      },
      {
        "article": "article.en.md",
        "quote": "Sorting workspace and answer growth occur in different phases, so their allocation totals must not be multiplied by the number of merges.",
        "judgment_reused_from_first_read": false
      }
    ]
  },
  {
    "method": "改 intervals.sort(...)",
    "variables": "same n,k",
    "frequency": "同排序工作與 n scan；省單獨 sorted outer reference list",
    "aggregate": "仍 worst O(n log n) time（同 sort + scan推得），正文未聲稱改善時間",
    "auxiliary": "同類 sort workspace仍 O(n) 上界，不能僅由 input mutation permission推出 O(1)",
    "output_and_transient": "O(k) retained output；重排 caller outer list，故改變本文 preservation 選擇",
    "evidence": [
      {
        "article": "article.en.md",
        "quote": "Calling `intervals.sort(...)` instead would remove the separate sorted outer list but rearrange the caller's list. It would not establish constant auxiliary space: Python's sorting workspace can still grow with `n`.",
        "judgment_reused_from_first_read": true
      }
    ]
  },
  {
    "method": "repeated selection",
    "variables": "n used markers，k output groups",
    "frequency": "n selections each n marker checks=n²；only remaining candidates variant n+(n-1)+...+1=n(n+1)/2；選中每pair merge一次；k append",
    "aggregate": "O(n²) selection + O(n) amortized merge = O(n²)",
    "auxiliary": "n Boolean markers O(n)，chosen index/best start O(1)，不保留 sorted list",
    "output_and_transient": "same O(k) fresh result and aggregate append argument",
    "new_small_accounting_example": "上述 n=7 =>49 marker checks；remaining-only model為28 candidates；可依原index次序1,3,2,6,5,0,4餵入，結果仍三組。",
    "evidence": [
      {
        "article": "article.en.md",
        "quote": "With `n` markers checked on each of `n` selections, there are `n*n` marker checks. Even a version that scans only the remaining candidates must inspect `n + (n-1) + ... + 1` candidates.",
        "judgment_reused_from_first_read": true
      },
      {
        "article": "article.en.md",
        "quote": "This alternative takes `O(n^2)` time, `O(n)` auxiliary marker space, and `O(k)` output space with the same fresh-pair and append argument.",
        "judgment_reused_from_first_read": true
      }
    ]
  },
  {
    "method": "changed input contract: guaranteed nondecreasing starts",
    "variables": "n intervals,k returned groups",
    "frequency": "0 sort；n scan visits；k append<=n",
    "aggregate": "O(n) time including amortized appends",
    "auxiliary": "O(1) state beyond retained result，no ordered and no sort workspace",
    "output_and_transient": "O(k) fresh pairs/list；v2明示這是沿用 shown implementation的選擇，並非所有保留輸入解法必要",
    "evidence": [
      {
        "article": "article.en.md",
        "quote": "There are still `n` visits and at most `n` appends, so the scan takes `O(n)` time. With no `ordered` list and no sort workspace, it needs `O(1)` auxiliary state beyond the retained `O(k)` result.",
        "judgment_reused_from_first_read": true
      },
      {
        "article": "article.en.md",
        "quote": "This adaptation keeps the shown implementation's fresh answer pairs, so its in-place endpoint updates cannot change the caller's pairs.",
        "judgment_reused_from_first_read": false
      }
    ]
  }
]
```

## Q6: Map full runnable code to the transitions and actual Python behavior.

完整碼使用 typing.List 註記 nested ints，但 runtime 不驗證型別或 pair長度。sorted以第一數當 key，建新 outer list但共享原pairs；for start,end逐pair解包。空 merged 令 not merged為True，or短路避免空[-1]。非空且 start>last_end只 append fresh pair；否則含 equality，寫 last_end=max(last_end,end)，對應連通群組擴張/內含不縮短。return時尾段已有存入。新例實際執行可觀察到輸入順序及值不變，三個答案pairs均不是原pair物件。雙語完整 Python block逐字相同。非法型別/元素數的exception名稱正文沒有交代，也不在合法輸入契約中，本 reader不補。

複查/沿用標記：重用上述精確不變的Python行為解釋；重新抽取v2完整碼並執行新例、比較兩語言code block。

> Python evaluates the key once per input pair and returns a new outer list in ascending key order.

（精確不變引句；沿用判斷）

> Python's `or` stops once its left side is true, so the first iteration never evaluates `merged[-1][1]` on an empty list.

（精確不變引句；沿用判斷）

> The type hints describe nested integer lists; they do not validate input at runtime or specify that each inner list has exactly two items.

（精確不變引句；沿用判斷）


### runtime_observation

```json
{
  "executed": "exact complete v2 English public code block",
  "input": [
    [
      6,
      9
    ],
    [
      0,
      0
    ],
    [
      2,
      5
    ],
    [
      1,
      2
    ],
    [
      12,
      12
    ],
    [
      5,
      6
    ],
    [
      2,
      3
    ]
  ],
  "ordered": [
    [
      0,
      0
    ],
    [
      1,
      2
    ],
    [
      2,
      5
    ],
    [
      2,
      3
    ],
    [
      5,
      6
    ],
    [
      6,
      9
    ],
    [
      12,
      12
    ]
  ],
  "result": [
    [
      0,
      0
    ],
    [
      1,
      9
    ],
    [
      12,
      12
    ]
  ],
  "input_value_and_order_unchanged": true,
  "no_output_pair_is_input_pair": true,
  "en_and_zh_complete_python_blocks_equal": true
}
```

## Q7: Challenge necessary/exclusive claims using a legal alternative mechanism; identify what is actually licensed.

排序不是所有正確解的必要條件：正文自己給repeated selection建立不遞減起點，足以沿用同一gap proof。在already-sorted契約下，fresh answer pairs也不是所有保留caller資料的方法都必須有：合法輸入[[1,2],[4,5]]可append原pair reference而不寫其內容；一般有overlap時可把merged[-1]槽位替換成新union pair，不改共享input pair。這個反機制沒有反駁v2，因新句已限縮為shown implementation的fresh pairs配合in-place endpoint updates。它只阻止讀者推出每個保留輸入解法都必須全新pair的更強結論。若要求回傳後任意修改output也與input隔離，則需另立更強契約；正文沒有把它偷換成題目要求。in-place outer sort也不能僅憑變更mutation permission推出constant workspace，新memory機制已解釋原因。

複查/沿用標記：v2 necessary-claim範圍重新判斷；sorting非普遍必要與sort workspace caveat引句逐字不變。

> Sorting by start is one way to obtain the needed order; it is not a claim that every correct algorithm must sort.

（精確不變引句；沿用判斷）

> This adaptation keeps the shown implementation's fresh answer pairs, so its in-place endpoint updates cannot change the caller's pairs.

（v2新重建/新比較）

> 這個調整保留所示實作新建答案端點組的做法，讓原地更新答案終點時不會改到呼叫端的端點組。

（v2新重建/新比較）

> Changing mutation permission alone does not remove that cost.

（精確不變引句；沿用判斷）


### reader_constructed_alternative_costs

```json
"sorted contract下每pair bounded work，n visits，<=n appends與<=n fixed pair replacements，沿用本文append證明 =>O(n)時間；retained output O(k)，其外O(1)state與O(1) transient replacement。總pair allocation可為O(n)，不能誤當peak。此為reader機制挑戰，不是正文新增實作或作者修復。"
```

## Q8: Compare complete English/Traditional Chinese decision, exception, numerical/code and cost claims.

已逐段重查完整雙語正文，包含原電影與程式、完整正確性、成本、主成本之後的variants、English interview practice與Master Map。未發現決策、例外、數字、code或成本主張的語意漂移；新增buffer細節與fresh-pair範圍句兩語言亦等義。此處為同一Reader對v2的完整比較，並非第二獨立Reader，也沒有以雙語相同當成外部真實性證明。

複查/沿用標記：完整v2新比較；僅尾部精確不變摘要的既有成本判斷重用。

> With `m = min(a,b)`, this needs at most `m` key slots and `m` matching pair-reference slots: `2m <= a+b <= n`.

（v2新重建/新比較）

> 令 `m = min(a,b)`，這最多需要 `m` 個 key 位置與 `m` 個對應的端點組 reference 位置：`2m <= a+b <= n`。

（v2新重建/新比較）

> For eight items split into runs of four and four, that is at most four temporary keys and four matching references.

（v2新重建/新比較）

> 例如八個元素分成長度四與四的 runs，最多暫存四個 keys 與四個對應 references。

（v2新重建/新比較）

> Guaranteed sorted input -> omit ordering -> O(n) time, O(1) auxiliary state

（精確不變引句；沿用判斷）

> Guaranteed sorted input -> omit ordering -> O(n) time, O(1) auxiliary state

（精確不變引句；沿用判斷）


### comparison

```json
[
  {
    "area": "contract",
    "comparison": "兩語言同樣1..10000 pairs、0<=start<=end<=10000、continuous closed intervals、touch合併、零長度有效、精確union、保留caller為選擇。"
  },
  {
    "area": "decisions / state / invariant",
    "comparison": "<=合併、>gap、max end、左界不退、only-last、每步後invariant、有限n終止及兩個失敗捷徑完全一致。"
  },
  {
    "area": "movie / numerical / runnable code",
    "comparison": "原movie六組pair與ordered、max(4,3)=4、max(4,6)=6、touch 6與8、gap12>10、結果[[1,10],[12,12]]一致；兩個完整Python code blocks逐字相同。"
  },
  {
    "area": "Python exceptions / behavior",
    "comparison": "fresh outer vs shared inner、fresh answer pairs、assignment reference、key once、or短路、hints不validate、empty input outside constraints均等義；未有一語新增exception保證。"
  },
  {
    "area": "append / main sort time",
    "comparison": "C,r,S幾何級數、r=1/2只是doubling示意、實際較溫和、balanced conceptual vs Powersort actual、midpoint level、64 insertion target、<=n boundaries一致。"
  },
  {
    "area": "new live-memory bridge",
    "comparison": "n key-reference slots；現有bounded integer key；copy smaller remaining run；m=min(a,b)、2m<=a+b<=n；eight items 4+4 => four temporary keys + four refs；one merge at a time、buffer reuse、old buffer release before larger allocation、fixed-size pending run records、phase cleanup均等義，沒有將sum allocations誤譯為peak。"
  },
  {
    "area": "all later variants",
    "comparison": "intervals.sort省outer list但mutates且仍workspace；repeated selection n²或n(n+1)/2、O(n)markers、O(k)output；sorted-contract省sort得O(n)/O(1)aux+O(k)output均等義。fresh pairs的新限縮在兩語言同樣明指所示實作。"
  },
  {
    "area": "English interview practice / Master Map",
    "comparison": "完整尾部均已讀；兩篇保留相同English問答與text map，主時間O(n log n)、scan O(n)、aux O(n)、output O(k)、sorted input O(1)aux摘要均相符。"
  }
]
```

## Findings

目前未留需修訂 findings。讀取界線與CPython外部事實未驗證的界線如上。第一輪 NEEDS_REVISION 保留，並未改寫成PASS；本次是新版正文的同一Reader bounded複查。
