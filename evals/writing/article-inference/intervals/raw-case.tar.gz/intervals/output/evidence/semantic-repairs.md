# Actual author repairs after the first complete English draft

1. The append paragraph asserted that changing a geometric growth fraction only changes a multiplier, without deriving that multiplier. Replaced its doubling-only illustration with the finite-sum cancellation S-rS and connected final capacity C to k. No algorithm or cost conclusion changed.
2. The sorting paragraph used a balanced merge picture, then imported the actual Powersort bound without enough connection. Kept the conceptual merge explanation, added the binary subdivision/midpoint level bound, decreasing-level charge and final pending-level bound from CPython source. Added key/run work, bounded short-run extension and per-boundary level-computation work. Qualified the analysis to CPython instead of universal Python implementation behavior.

These repairs are semantic explanation additions by the Content Owner, separate from sloptrim expression changes. The untouched first complete draft is first-draft.en.md. No reader feedback or expected answer was used.

3. The original type-hint explanation called List[List[int]] a list of pairs. Corrected it to nested integer lists; pair length is supplied by the problem contract, not encoded by that hint. Updated the pinned raw-source line anchor to the local source's actual merge-policy span.
