# Author semantic reconstruction before translation

Status: English approved by its Content Owner after the actual repairs in semantic-repairs.md. This is author review, not independent reader review. First complete artifact: first-draft.en.md; reviewed artifact: article.en.md. Test execution: runtime-tests.json. No publication, compiler Stage 0–7 admission or human learning result is claimed.

## Main method: reconstruct from the finished body

Body support starts with “If starts arrive in increasing order, then left <= start” and the two branches in “Which order makes a decision permanent?”. A valid next pair has start <= end. Combining those with start <= right proves the union is [left,max(right,end)]: no missing middle gap; the left boundary need not move. If start > right, all future starts >= start, so no future pair can touch right or bridge the gap. Earlier answer intervals remain separated because the evolving group's left boundary stays fixed. This proves the last-pair-only choice, not an assertion that sorting is necessary for every possible algorithm.

State checkpoint is explicitly after each iteration in “Why is the partial answer correct?”. The empty processed prefix has empty union. The first append constructs its union. Overlap modifies only the last end; gap finalizes the old last and adds the new exact pair. Every iteration consumes one input; termination leaves exact union and nonoverlap. A fresh reader can compute [[0,2],[1,1],[2,4],[7,7]] -> [[0,4],[7,7]] from those premises alone: [1,1] is contained, [2,4] touches the retained end 2, and 7 exceeds 4. This extra reconstruction is private, not an extra advertised runtime example.

The movie's six states match the complete fence exactly. Negative indexing selects the current result pair; short-circuit or prevents invalid indexing on the empty result. sorted creates only a new outer ordering; new [start,end] result pairs prevent input alias mutation. The List hint correction matters because hints neither encode pair length nor enforce values at runtime.

## Failure reconstruction

The body supplies [[1,10],[2,3],[4,5]]: the previous raw end is 3, but the processed group's right endpoint is 10. Comparing 4 to 3 violates the represented state. It also supplies [[5,6],[1,2]]: without sorted starts, preserving left=5 loses earlier coverage. Neither counterexample relies on outside notes.

## Cost reconstruction: main method

The elementary model is declared in the first cost paragraph: bounded endpoints, constant reference operations and fixed pair allocation. The loop has n visits and bounded non-append work per visit. Its last-slot lookup does not search the answer. New pairs and surviving output are bounded by n and k respectively (in fact this code makes exactly k new pairs, with no deletions).

For append, the public body now derives the finite-sum bound rather than asserting the word amortized: S-rS <= C gives S <= C/(1-r); fixed r<1 and proportional overallocation give C=O(k). k slot writes plus O(k) total moved references -> O(k). CPython list_resize lines 98–126 supplies proportional overallocation and finite initial allocations. No assertion that each append is worst-case O(1), and no claim that CPython doubles capacity.

For sorting, the public body first derives O(a+b) merge work from front positions moving only forward, and O(n) work per conceptual level. It defines log2(n) via repeated doubling. The repaired actual-Powersort explanation closes the earlier library-bound gap: adjacent nonempty run midpoints are >=1 input position apart; binary cell width n/2^h <=1 separates them, bounding powers by O(log n). found_new_run merges larger powers before assigning a smaller one; powers are strictly increasing from bottom to top, so an item's ancestor merges move to shallower powers without repeating a level. Cleanup sees only that many pending runs. Charging a merge's linear work to its items gives O(n log n) total. Power calculation has O(log n) binary steps for at most n boundaries. Run recognition and bounded (<=64) short-run extension add O(n); key extraction adds n fixed reads. The main method therefore has O(n log n)+O(n)=O(n log n) worst-case work under the declared CPython/bounded-integer model. No remembered rule is left as the only explanation of that formula. The paper underlying Powersort was not read, and the article does not claim a formal proof of that paper or an exact trace of all CPython optimizations.

Memory: k result pair objects plus an outer array with proportional spare capacity -> O(k) output. ordered retains n references; key/workspace arrays are O(n); a fixed number of loop scalars -> O(1). Auxiliary O(n), peak O(n+k)=O(n). It is not O(1) just because the loop uses a constant number of variable names.

## Other approaches actually introduced

1. intervals.sort: condition is permission to reorder input. It removes only ordered's separate outer array, not sort workspace. Same bound on comparisons and merge/key storage remains. Body explicitly refuses constant auxiliary-space inference. Retained input pairs and fresh output pair behavior do not change.
2. Repeated selection: retain n Boolean used markers, inspect n markers for each of n selected pairs, store fixed current candidate state, mark one, feed one pair into the exact same merge step. Starts are nondecreasing, so proof and k-output append bound transfer. n*n checks -> O(n^2), n markers -> O(n) auxiliary, k output pairs -> O(k). The optional remaining-candidate formulation separately derives n(n+1)/2. It supplies no unsupported faster-cost claim.
3. Guaranteed start-sorted input: remove ordered and the sorting step; do not remove fresh pairs, max updates or append work. n visits + O(k) append cost, k<=n -> O(n). Fixed loop/reference state -> O(1) auxiliary excluding O(k) output. Input ordering guarantee is a precondition, not inferred from examples. Code and proof do not authorize applying that adaptation to arbitrary intervals.

## Source boundaries and scope

Raw LeetCode statement was read independently. Primary Python docs and CPython v3.14.0 source were fetched; local runtime used Python 3.14.6. Examples and derivations are original constructions, not solutions copied from editorial material. The wording does not assert that reference code execution demonstrates reader benefit. All exposed links are public primary sources. Source and program observations are separated from conceptual merge accounting.

No unresolved author-identified algorithm/content defect remains after these repairs. Full-domain exhaustive proof-by-testing, native learner evidence, independent article-only Reader, annotations, website runtime and publication are NOT_RUN by this Owner.
