from pathlib import Path
import re,json,difflib
out=Path(__file__).resolve().parents[1]
en=(out/'article.en.md').read_text();zh=(out/'article.zh-TW.md').read_text()
def blocks(s):
    result=[];buf=[];lines=s.splitlines();i=0
    def flush():
        if buf:result.append(('p','\n'.join(buf)));buf.clear()
    while i<len(lines):
        line=lines[i]
        if line.startswith('```'):
            flush();tag=line[3:];body=[];i+=1
            while i<len(lines) and not lines[i].startswith('```'):body.append(lines[i]);i+=1
            assert i<len(lines),'unclosed fence'
            result.append(('f:'+tag,'\n'.join(body)))
        elif re.match(r'^#{1,6} ',line):
            flush();result.append(('h:'+str(len(line.split(' ',1)[0])),line.split(' ',1)[1]))
        elif not line.strip():flush()
        else:buf.append(line)
        i+=1
    flush();return result
be,bz=blocks(en),blocks(zh)
assert [x[0] for x in be]==[x[0] for x in bz],'block sequence'
for i,((typ,e),(_,z)) in enumerate(zip(be,bz),1):
    if typ.startswith('f:'):assert e==z,('fence mismatch',i)
    if typ=='p':
        assert re.findall(r'`[^`]+`',e)==re.findall(r'`[^`]+`',z),('inline code mismatch',i)
        assert re.findall(r'\]\(([^)]+)\)',e)==re.findall(r'\]\(([^)]+)\)',z),('link mismatch',i)
assert re.findall(r'```python\n(.*?)\n```',en,re.S)[0]+'\n'==(out/'reference.py').read_text()
for s in (en,zh):assert not re.search(r'^\s*\|.*\|\s*$',s,re.M),'table'
m=json.loads((out/'metadata.json').read_text())
assert m['english_title']==en.splitlines()[0][2:]
assert m['title']==zh.splitlines()[0][2:]
report={'heading_fence_paragraph_sequence':'PASS','blocks':len(be),'prose_paragraphs':sum(t=='p' for t,_ in be),'headings':sum(t.startswith('h:') for t,_ in be),'fences':sum(t.startswith('f:') for t,_ in be),'fence_bytes_identical':'PASS','paragraph_inline_code_order':'PASS','paragraph_source_link_destinations':'PASS','reference_matches_python_fence':'PASS','tableless':'PASS','metadata_h1_match':'PASS','scope':'Mechanical pairing only; not a semantic or independent-reader result.'}
(out/'evidence/mechanical-checks.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'evidence/first-final.en.diff').write_text(''.join(difflib.unified_diff((out/'first-draft.en.md').read_text().splitlines(True),en.splitlines(True),fromfile='first-draft.en.md',tofile='article.en.md')))
(out/'evidence/first-final.zh-TW.diff').write_text(''.join(difflib.unified_diff((out/'first-draft.zh-TW.md').read_text().splitlines(True),zh.splitlines(True),fromfile='first-draft.zh-TW.md',tofile='article.zh-TW.md')))
print(json.dumps(report))
