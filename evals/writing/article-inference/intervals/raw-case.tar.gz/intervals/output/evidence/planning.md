# Content plan

## Contents

1. What must the result preserve?
2. Which order makes a decision permanent?
3. What does the Python state represent?
4. Program Movie: containment, extension, touching, and a gap
5. The complete Python implementation
6. Why is the partial answer correct?
7. Where do the time and memory costs come from?
8. An alternative, and a constraint that changes the choice
9. English interview practice
10. Master Map

The opening orientation precedes these sections. This planning outline is not duplicated as a manual public TOC.

## Derived decisions and prerequisites

- Exact closed-interval coverage: merge endpoint equality, preserve real gaps; contract and first branch section.
- Ordering: arbitrary arrivals cannot justify a final gap, nondecreasing starts can; ordering section and unsorted counterexample.
- Retained state: keep maximum group end rather than previous raw end; representation, movie and proof.
- Object ownership: new outer ordering is insufficient to prevent shared-pair mutation; fresh output pairs in representation and code.
- Input guarantee pivot: a reliable nondecreasing-start contract removes ordering work/workspace; alternative section.

Representation question follows the ordering/gap proof; code follows concrete state transitions. Costs rely on the actual retained lists and mutations. A conceptual merge plan is distinguished from actual CPython scheduling, with the scheduling-level bridge added during author self-review.

## Embedded symbol tree (containment, not execution order)

```text
Solution
  merge(intervals)
    ordered       start-sorted outer list, shares input pairs
    merged        new output list, owns fresh answer pairs
    start, end    current input endpoints
```

## Decision map

```text
closed endpoints -> equality is overlap -> max end on overlap
arbitrary input order -> order starts -> strict gap becomes final
preserve caller pairs -> allocate fresh output pairs
reliable sorted input -> remove ordering -> same merge transitions
```

## Runtime map

```text
valid input -> sorted outer references -> merged=[]
  first/gap -> fresh pair append
  overlap -> mutate output's last endpoint
  finite exhaustion -> return already stored result
invalid pair contract -> outside reference method's input assumptions
```

No invalid-input validator is invented. The two falsifying shortcuts are tested in the public prose, not hidden only in this plan.
