from pathlib import Path
from itertools import product
from copy import deepcopy
import importlib.util,json,platform,time
out=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('interval_reference',out/'reference.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
solve=module.Solution().merge

def graph_oracle(pairs):
    # Independent formulation: intervals form vertices; overlap forms an edge.
    # A connected component of closed intervals has continuous union.
    remaining=set(range(len(pairs))); answer=[]
    while remaining:
        root=remaining.pop(); component=[root]; pending=[root]
        while pending:
            i=pending.pop()
            for j in list(remaining):
                if pairs[i][0] <= pairs[j][1] and pairs[j][0] <= pairs[i][1]:
                    remaining.remove(j); component.append(j); pending.append(j)
        answer.append([min(pairs[i][0] for i in component),max(pairs[i][1] for i in component)])
    return sorted(answer)

named=[
 ('statement-1',[[1,3],[2,6],[8,10],[15,18]],[[1,6],[8,10],[15,18]]),
 ('touching',[[1,4],[4,5]],[[1,5]]),
 ('reverse-touching',[[4,7],[1,4]],[[1,7]]),
 ('program-movie',[[8,10],[1,4],[2,3],[3,6],[6,8],[12,12]],[[1,10],[12,12]]),
 ('group-end-counterexample',[[1,10],[2,3],[4,5]],[[1,10]]),
 ('unsorted-gap',[[5,6],[1,2]],[[1,2],[5,6]]),
 ('point',[[12,12]],[[12,12]]),
 ('duplicates',[[1,3],[1,3]],[[1,3]]),
 ('same-start',[[1,2],[1,10],[1,1]],[[1,10]]),
 ('integer-gap',[[1,4],[5,6]],[[1,4],[5,6]]),
 ('empty-extension',[],[]),
 ('constraint-extremes',[[0,0],[10000,10000],[0,10000]],[[0,10000]])]
started=time.monotonic();checks=[]
for name,pairs,expected in named:
    before=deepcopy(pairs); got=solve(pairs)
    assert got == expected,(name,got,expected)
    assert pairs==before,(name,'input mutated')
    assert all(row is not src for row in got for src in pairs),(name,'pair alias')
    checks.append({'name':name,'input':pairs,'expected':expected,'observed':got,'result':'PASS'})
choices=[(a,b) for a in range(5) for b in range(a,5)]
count=0
for size in range(1,5):
    for sequence in product(choices,repeat=size):
        pairs=[list(x) for x in sequence]; before=deepcopy(pairs)
        got=solve(pairs); expected=graph_oracle(pairs)
        assert got==expected,(pairs,got,expected)
        assert pairs==before,(pairs,'mutation')
        assert all(row is not src for row in got for src in pairs)
        count+=1
report={'python':platform.python_version(),'named_cases':checks,'exhaustive':{'endpoint_domain':[0,4],'ordered_input_lengths':[1,4],'distinct_interval_choices':len(choices),'tested_sequences':count,'oracle':'undirected overlap graph connected components; min/max per component','result':'PASS'},'elapsed_seconds':round(time.monotonic()-started,3),'limits':'Finite exhaustive small domain and named cases; not exhaustive over LeetCode full domain, not reader or learner evidence.'}
(out/'evidence/runtime-tests.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'named_passed':len(checks),'exhaustive_sequences_passed':count,'elapsed_seconds':report['elapsed_seconds'],'python':report['python']}))
