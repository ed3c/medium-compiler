# Traditional Chinese first-draft preservation and repair

first-draft.zh-TW.md is the untouched complete first translation. article.zh-TW.md is the approved edition after this expression adjustment.

The first mechanical pairing check stopped at block 43 because English introduced C=O(k) before the inline k occurrence, while the translation placed the phrase k appends before C=O(k). The formulas and relationship were already equivalent. Rephrased the Traditional Chinese sentence to introduce the capacity formula before identifying k, retaining its meaning and satisfying the strict inline-identity sequence check. No checkpoint, algorithm, formula or qualification changed. The actual failed assertion is preserved in mechanical-first-failure.log; the checker was not weakened.

Second mechanical attempt exposed remaining inline ordering differences in blocks 47 and 52 (shared object/allocation wording, total-space cause/conclusion, and auxiliary/output order). A diagnostic inspected all remaining differences at once. Reordered those three Traditional Chinese clauses without changing their relationships, and preserved the complete prior edition as intermediate-02.zh-TW.md. The third acceptance attempt is the final attempt for this check.
