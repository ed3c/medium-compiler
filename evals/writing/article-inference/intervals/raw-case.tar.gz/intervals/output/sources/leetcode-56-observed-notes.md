# Primary problem observations

Source read through web.open: https://leetcode.com/problems/merge-intervals/ (description only, no editorial or solution body).

Observed contract: input is an array of two-endpoint intervals; merge overlaps and return non-overlapping covering intervals. Number of intervals is at least 1 and at most 10^4; every pair has exactly 2 entries; integer endpoints satisfy 0 <= start <= end <= 10^4. The page explicitly treats [1,4] and [4,5] as overlapping, yielding [1,5]. A reverse input [4,7],[1,4] yields [1,7]. These notes capture inspected facts, not an assertion that the complete HTML was archived locally.
