from pathlib import Path
from copy import deepcopy
import json

def preserve_values_reuse_unchanged(ordered_pairs):
    result=[]
    for pair in ordered_pairs:
        if not result or pair[0] > result[-1][1]:
            result.append(pair)
        elif pair[1] > result[-1][1]:
            result[-1]=[result[-1][0],pair[1]]
    return result

cases=[
    ([[1,2],[2,4],[6,7]],[[1,4],[6,7]]),
    ([[1,2],[5,6]],[[1,2],[5,6]]),
    ([[1,5],[2,3]],[[1,5]])]
results=[]
for pairs,expected in cases:
    original=deepcopy(pairs);result=preserve_values_reuse_unchanged(pairs)
    assert result==expected
    assert pairs==original
    shared=[any(output_pair is input_pair for input_pair in pairs) for output_pair in result]
    assert any(shared)
    results.append({'input':pairs,'expected':expected,'observed':result,'input_values_preserved':True,'output_pair_shares_original_object':shared})
report={'purpose':'Counterexample to generic necessity of all-fresh answer pairs, holding exact-union and caller-value preservation at return fixed.','precondition':'Inputs in this witness are already nondecreasing by start.','not_claimed':'No later-mutation independence between shared output and input aliases; no claim of a replacement public implementation.','cases':results,'result':'PASS'}
Path(__file__).with_name('necessity-witness-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
