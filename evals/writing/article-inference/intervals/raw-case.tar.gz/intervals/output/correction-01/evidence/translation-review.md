# Traditional Chinese review after repaired English approval

The English semantic approval was saved before the repaired complete translation was created. first-repair.zh-TW.md retains that first complete repaired translation; article.zh-TW.md additionally smooths one sentence about shared inner objects. No original draft or review is overwritten.

The sorted-input claim now says “這個調整保留所示實作新建答案端點組的做法，讓原地更新答案終點時不會改到呼叫端的端點組。” It scopes the allocation to the shown implementation and names the in-place write it protects. It no longer states “仍然必須” as a generic necessary condition for preserving caller pairs. This matches the approved English selected-recipe claim, not an assertion that shared unchanged pairs are impossible.

The new memory explanation preserves the n input/key-slot connection, existing endpoint objects, a,b run sizes, possible trimming, m=min(a,b), at-most m keys plus m matching references and 2m<=a+b<=n. The eight-item illustration is explicitly an upper bound. It keeps sequential merge execution, buffer reuse and freeing the old dynamic allocation before enlarging. The fixed-size pending records use the earlier logarithmic-count argument. It therefore explains the same n key slots plus linear scratch upper bound, not merely the phrase O(n) workspace.

The phase explanation preserves key-reference array and merge-buffer release before interval scanning, ordered remaining live while O(k) output grows, constant loop state, O(n) auxiliary peak and O(n+k)=O(n) total under k<=n. It does not claim that caller endpoint integers themselves are destroyed during key-reference cleanup. The unchanged intervals.sort paragraph can now reuse this publicly explained workspace derivation. Other method costs, reference code, Program Movie, English invariant/interview text, headings and Master Map are preserved.

Both editions approved by their author for the two feedback-informed repairs. This is not an independent Reader verdict. Metadata content and reference code do not require changes; correction handoff identifies the distinct revised body paths. No new model/session/reader, full-domain tests, compiler stage, provider effect or publication is claimed.
