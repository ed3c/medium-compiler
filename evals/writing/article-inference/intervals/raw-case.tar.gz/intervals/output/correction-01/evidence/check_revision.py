from pathlib import Path
import re,json,difflib
c=Path(__file__).resolve().parents[1]
en=(c/'article.en.md').read_text();zh=(c/'article.zh-TW.md').read_text()
old_en=(c/'pre-feedback/article.en.md').read_text();old_zh=(c/'pre-feedback/article.zh-TW.md').read_text()
def blocks(s):
    result=[];buf=[];lines=s.splitlines();i=0
    def flush():
        if buf:result.append(('p','\n'.join(buf)));buf.clear()
    while i<len(lines):
        line=lines[i]
        if line.startswith('```'):
            flush();tag=line[3:];body=[];i+=1
            while i<len(lines) and not lines[i].startswith('```'):body.append(lines[i]);i+=1
            assert i<len(lines),'unclosed fence'
            result.append(('f:'+tag,'\n'.join(body)))
        elif re.match(r'^#{1,6} ',line):flush();result.append(('h:'+str(len(line.split(' ',1)[0])),line.split(' ',1)[1]))
        elif not line.strip():flush()
        else:buf.append(line)
        i+=1
    flush();return result
be,bz=blocks(en),blocks(zh)
assert [t for t,_ in be]==[t for t,_ in bz],'block shape'
for i,((t,e),(_,z)) in enumerate(zip(be,bz),1):
    if t.startswith('f:'):assert e==z,('fence',i)
    if t=='p':
        assert re.findall(r'`[^`]+`',e)==re.findall(r'`[^`]+`',z),('inline code',i)
        assert re.findall(r'\]\(([^)]+)\)',e)==re.findall(r'\]\(([^)]+)\)',z),('link destinations',i)
assert re.findall(r'```python\n(.*?)\n```',en,re.S)==re.findall(r'```python\n(.*?)\n```',old_en,re.S),'changed reference code'
assert en.splitlines()[0]==old_en.splitlines()[0]
assert zh.splitlines()[0]==old_zh.splitlines()[0]
assert 'Preserving the caller\'s pairs still requires fresh answer pairs.' not in en
assert '仍然必須建立新的答案端點組' not in zh
for name,before,after in [('en',old_en,en),('zh-TW',old_zh,zh)]:
    (c/'evidence'/f'pre-feedback-revised.{name}.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'pre-feedback/article.{name}.md',tofile=f'correction-01/article.{name}.md')))
report={'result':'PASS','block_sequence':'aligned','paragraphs_each':sum(t=='p' for t,_ in be),'headings_each':sum(t.startswith('h:') for t,_ in be),'fences_each':sum(t.startswith('f:') for t,_ in be),'inline_identity_order':'PASS','link_destinations':'PASS','fence_identity':'PASS','reference_code_unchanged':'PASS','titles_unchanged':'PASS','scope':'Mechanical preservation only, not independent semantic acceptance.'}
(c/'evidence/mechanical-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
