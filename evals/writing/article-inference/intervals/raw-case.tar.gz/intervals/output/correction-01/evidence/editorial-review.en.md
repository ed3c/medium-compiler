# English editorial supplement: first downstream correction

The complete repaired English draft was saved as english-repair-draft.md before this review. The local sloptrim detector was actually executed on it; its raw diagnostic is sloptrim-repair.raw.json. The reader-article supplement was applied to the new English content despite a clean score. The necessity wording was already scoped by the substantive repair and was not restored for stylistic terseness.

Actual final expression/technical-precision changes after reading the draft:
- Clarified that source merge code may trim already-positioned portions, so smaller-run buffer slots and the eight-item illustration are upper bounds, not exact allocations on every input.
- Replaced “dynamic keys” with “dynamic key-reference array”, so cleanup cannot be misread as destruction of the caller's integer endpoint objects.

Preserved the finite buffer calculation, sequential reuse, old-buffer release, pending records and phase liveness. These sentences supply missing premises and are not removable narration about the manuscript. No Python fence, existing number, link destination or unchanged runtime state was altered. Newly added public source links identify already captured primary CPython source, not a new external solution.

The completed edited English edition is article.en.md. The final detector raw diagnostic is saved separately. Its result is only a style observation, not semantic approval. No final translation existed before the English semantic approval record was saved.
