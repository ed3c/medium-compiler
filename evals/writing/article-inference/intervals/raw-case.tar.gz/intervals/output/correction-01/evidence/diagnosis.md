# First downstream correction: scope and live storage

This is a feedback-informed correction of the existing delivery, not a new blind run. Original first drafts, final bodies, author-review.en.md, bilingual-review.md, earlier failures and all prior reviews remain untouched. pre-feedback/ contains exact copies of the original final bodies. No other article, annotation, Reader report or expected-answer artifact was read.

## 1. Necessary fresh pairs: contextual reading and countermechanism

The full sorted-input paragraph says “same merge rule”, and the shown code appends fresh pairs and subsequently assigns into merged[-1][1]. Under the specific adaptation that removes ordering and preserves those exact allocation and write operations, fresh pairs are retained and protect the caller. That licenses a description of this selected implementation.

However, “same merge rule” also naturally denotes the mathematical overlap/max-end rule, not a promise to preserve every object-update operation. The sentence “Preserving the caller's pairs still requires fresh answer pairs” does not state the narrower premise. Read as a requirement over all caller-preserving implementations, it is too strong. It would also be too strong to assert that every individual answer pair must be fresh even whenever the original update statement is present: an interval never extended could remain shared without changing caller values. Safe generic claims must distinguish an alias that is later written from an alias whose contents are only read.

A legal countermechanism keeps caller values unchanged at return: append an original pair on a gap; on a strict extension replace the last outer-list reference with a new [left,end] pair; on containment do nothing. This preserves the same mathematical union rule and can share an unchanged output pair. It does not promise that later edits by the caller to a shared output pair cannot affect its input alias. The article's selected implementation remains stronger in that respect; the generic preservation sentence did not state that stronger alias-independence requirement.

Repair the first overclaim itself, in the sorted-input paragraph, to describe the shown implementation and its in-place endpoint write. The earlier representation paragraph already says that appending an original pair AND THEN modifying it shares that mutation; it is conditional and requires no technical change. Code, proof, time, memory bounds and metadata claims do not change.

## What the original saved review actually did

Original author-review.en.md says “new [start,end] result pairs prevent input alias mutation” and in the sorted-input adaptation says “remove ordered and the sorting step; do not remove fresh pairs, max updates or append work.” The saved bilingual review likewise says the adaptation “keeps n visits, at most n appends and fresh pairs”. These records reconstruct the selected recipe and reuse its cost argument. They do NOT record extraction of the requires quantifier, a competing caller-preserving update mechanism, or a test that preservation necessitates fresh pairs. They establish sufficiency for the shown code, not necessity. No such original adversarial check can be claimed retrospectively.

## 2. Temporary sorting storage: source truth versus body explanation

Original body merely said sorting can retain keys and temporary reference storage proportional to n. The original saved review compressed that again to “key/workspace arrays are O(n)”. It counted ordered and result objects but did not record reconstructing buffer size, sequential reuse, old-buffer release, peak liveness or sort/scan phase separation. The source could establish the bound while the public body still failed to explain it for this audience. Original approval missed that dependency; byte preservation, code tests and bilingual agreement cannot repair it.

New inspection of the already captured CPython v3.14.0 source establishes: key results occupy n slots; merge_at selects the smaller trimmed run; with a key function the scratch buffer has both key and value-reference slots; merge_getmem reuses sufficient storage and frees an old dynamic buffer before enlarging it; cleanup releases the sort keys and buffer before returning. These are now turned into a body calculation, not left as a link: m=min(a,b), 2m<=a+b<=n; one live merge buffer is reused across sequential merges; n key slots plus linear scratch plus logarithmic fixed-size run records -> O(n) sorting workspace. After sort, only ordered survives into the interval scan alongside the growing output. The intervals.sort trade-off can now reuse a publicly explained workspace argument.

## Transferable missing action

The frozen method already explicitly says that a sufficient mechanism does not establish necessity and instructs trying a legal different mechanism. There is no basis to claim the rule was absent. Its execution was missing here. A concrete addition to the review procedure would produce two small witnesses for each applicable substantive claim:

1. For a necessity/exclusivity statement, record its quantified requirement separately from the selected mutation/ownership operations. Hold the requirement fixed, replace one operation, and construct or execute a lawful countermechanism. Either show why it fails or narrow the public claim to the selected operation pattern. This creates inspectable work beyond saying “check necessity carefully”.
2. For a retained-storage/peak claim, make a short allocation-lifetime trace: what is allocated, how its capacity depends on input, whether it is reused/freed, and which buffers coexist at the claimed checkpoint. Calculate peak live storage rather than repeating a library bound. A temporary object is not exempt from this trace.

These are proposed operational review actions, not edits to the frozen instructions or proof that future transfer will succeed. This correction supplies those missing actions for the two actual claims only.
