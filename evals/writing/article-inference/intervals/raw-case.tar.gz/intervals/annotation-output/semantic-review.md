# Intervals annotation Owner review

狀態：完整 annotation 已建立並完成本 Owner 的有界逐段重建；**正文 p38 的必要性範圍仍待上游裁定，整體 semantic completion 未宣告**。這份紀錄不是獨立 Reader 證據。只讀 supplied annotation-input；未讀 author review、source docs、repository examples、Reader 結果或 expected answers，未修改正文。

## 實際初稿與修正

`first-draft-manifest.json` 是第一次完整產出的 44 段 annotation、18 個 derived decision/concept、16 個 Active items，先保存才進入最後檢查。它不是 16 個獨立學習成果。首次機械檢查在 `verification-first.json` 留下一項缺陷：Active 05 已有 item-specific cue/oracle，但它引用的 `state` decision 缺少契約仍要求的 decision-level active_cue/oracle。`review_and_repair.py` 僅補上這兩個 source-bound 欄位；初稿與首次失敗原樣保留，未以覆寫初稿掩蓋失敗。最終差異只涉及這兩個欄位。

完整初稿 SHA-256：`b9e37164708ed096459179d6739d937adb8e8934492a0f84e99513a2a48c207d`。
最終 manifest SHA-256：`13d8c000d06c24e91a3a137f7c547aadbb6298692025eb15b5ada681399051c3`。

## 必須保留的正文問題：p38 necessity scope

原句：`Preserving the caller's pairs still requires fresh answer pairs.` 同段先說 `Feed each arriving pair directly into the same merge rule.`

正向可支持的推論：p11 說 `Later endpoint updates therefore modify an answer pair, not an input pair.` 並解釋先建立 fresh two-item list。沿用正文實作的端點原地寫入方式，fresh answer pairs 足以保護 caller。p38 若「same merge rule」明確也包含該物件建構與原地寫入方式，這是一個可成立的局部解讀。

反向則不能直接成立：保護 caller 不推出所有合法 merge 實作都必須一開始配置 fresh pairs。例如已排序輸入 `[[1,2],[4,5]]` 沒有延伸操作，答案外層 list 可參照原 pairs 而不修改 caller；更一般地，可以在需要延伸時建立替代 pair，而不是修改已共享的 pair。這是用來測試必要性的反機制，不是新增正文演算法或批准它的成本。

原始發現是「未限制實作的 requires 過強」；完整段落的 `same merge rule` 提供了局部限制的可能，因此不在這裡把廣義讀法當作已證實的正文錯誤。已將完整發現及兩種讀法送回 parent。依 parent 指示，**保留待裁定**，不能把 annotation 的較窄表述當正文已修正。p38 annotation 顯示「沿用本文更新 answer end 的實作」，不主張它是所有合法方案的唯一方法；這種限縮不解除正文依賴。p43 及相關 sorted-input decision/Active item 也不宣稱 fresh-pair 的普遍必要性。若上游 reapprove 不同正文 bytes，當前 manifest 必須重新綁定、重審，不可只改 blob 欄位。

## 重建主論證：不是只確認引用存在

精確覆蓋與非重疊：p1 `The returned intervals must cover exactly the positions covered by the input.` 先限定結果。p2 明說 closed intervals 包含相接端點且 `[1,4]` 與 `[5,6]` 有 gap；所以「整數端點差 1」不授權填上連續位置。反例換成 half-open intervals 時 equality 結論不再被這個 contract 支持。

ordering 的權限：p4 的 `left <= start` 加上合法輸入 `start <= end`，才允許 p5 保留 left 的 union 公式。p6 `Every later interval starts at least as far right as start` 與 strict gap 合起來，得到每個 later start > right，故無法回接。p7 的 earlier gaps 加上 left 不後退，才使「只看最後一段」成立。這沒有反推「每個正確演算法都必須 sort」；p8 與 p38 明示可靠 producer order 是不同合法機制。反例是 p27 的 `[[5,6],[1,2]]`：拿掉順序前提後同一公式保留錯誤 left。所有相應 notes 與 Active answers 都保留這個 domain。

maximum end 的必要範圍：p5 的 union 需兩個 right endpoints 中較遠者，而不是永遠直接賦新 end；p15 `max(4,3)` 和 p26 `[[1,10],[2,3],[4,5]]` 證明使用 previous original end 會縮掉已知群組覆蓋或捏造 gap。這是本文群組表示法應保留的資訊，不是要求每個實作必須呼叫名為 max 的函式。

representation/ownership：p9 將 pair 定為 connected processed group。p10 只給新 outer list，p11 說 inner pairs 仍參照原物件；因此 `sorted` 不推出 deep copy。本文 `merged.append([start,end])` 先配置 answer pair，接著 end-slot mutation 只改 answer。反方向「凡保持 input 就只能用此配置方式」沒有被批准。

checkpoint：p21 明定 `immediately after each iteration`。在這個 checkpoint，merged 是精確的 processed union，且 earlier pairs 對未處理資料已 final。p22 建立空前綴及第一輪；p23 overlap 保留 left 與原 gap、取 max end 不丟覆蓋；p24 gap 加新段且 future starts 不回頭；p25 每輪消耗一對有限輸入，終止時 processed=whole input。未處理完時不能將 processed union 當 whole-input result。「unfinished」也不表示資料尚未存到 merged；p18 說 last interval 已存，故無 final flush。

## 成本由正文重算

p28 固定模型：`n` 是 input count、`k` 是 returned count，k<=n；有界端點比較、reference 讀寫、固定 two-slot creation 為 elementary constant。不是任意長整數模型，也不是所有 Python 指令等物理時間。

scan：p29 每對一次 visit，各次 bounded endpoint reads/comparisons/writes，不搜尋 merged。未把 append 一行當 constant worst-case。p30 的 aggregate chain 是：每次擴容可能複製 array，歷史大容量以固定 r<1 往回縮；`S-rS = C-r^(m+1)C <= C`，因此 `S<=C/(1-r)`。固定 r 的分母為常數、C=O(k)，再加 k 次 ordinary writes，得整個 k 次 append 的 O(k)。由 k<=n，n 次 visit 的 O(n) 加 O(k) 仍是 O(n)。一個 append 可能 linear；若改成每次只增加固定一格而整體複製，固定 r 的前提失效，不能沿用線性 aggregate。

sorting：p31 指標不後退，每個 merge 最多遍歷 a+b items，故 O(a+b)；一層每個 item 只屬於一個 merge，整層 O(n)；大小 doubling h 次達 2^h，h 約 log2(n)，得概念 balanced O(n log n)。未把此圖像冒充實際 CPython call trace。p32 用 natural-run midpoints 的細分層級 <=約 log2(n)、沿 item 路徑層級下降且同層不重複計費，加 logarithmic pending cleanup，把每次 merge 費用分到其 items，得到 n 個 items 各 O(log n) 計費。p33 keys/run detection 是 linear；run extension 目標 <=64 使每次 insertion 跨固定上限位置，仍 linear；至多 n boundary 各 O(log n) subdivisions，仍 O(n log n)。合計 scan 保持該 worst-case upper bound。這是依正文重建的 accounting；外部 CPython source truth 未另查證。

space：p34 由一個 result outer list、k 個 fresh two-slot pairs 加 proportional spare capacity 得 O(k)。ordered 留 n references，sort keys/temporary reference workspace 可 proportional n，loop scalars constant，故 output-excluded auxiliary O(n)，含 output O(n+k)=O(n)。共享 input objects 不是 n 次新 pair 配置。p35 只移除 outer copy，不移除 sort workspace；不能反推 constant auxiliary。

repeated selection：p36 每次選剩餘最小 start，故產生相同 nondecreasing order，p4–7 的 merge argument 保持。p37 的 n selections × n marker checks 是 n²；只查 remaining 時 n+(n-1)+…+1，首尾配對得 n(n+1)/2，所以同樣平方。n 個 Boolean markers 加 constant search scalars 是 O(n) auxiliary；同樣 fresh-pair result 仍有 O(k) output 與 p30 append aggregate。不是因為「看起來有 nested loop」才判平方。

sorted-input adaptation：p38 reliable producer contract 供應順序，移除 ordering 並保留 p5/p6 規則。n visits × bounded work 加至多 n append 的 aggregate 是 O(n)；不留 ordered/sort workspace，僅 loop/scalars 是 O(1) auxiliary，仍保留 O(k) result。若只有少數範例已排序或 input 可以逆序，p27 反例阻止這個適用範圍。fresh-pair 必要性措辭依前述待裁定，未以筆記補正文。

## 每段新增可見內容的方向與區分檢查

以下是實際 annotation 的逐段審查紀錄；每段的 `reading_context` 都含當段完整 exact English quote，跨段依賴另附 exact supporting paragraphs。完整來源引用是追溯材料，不被當成語意證明。cue 均為短問句，不能單獨當定理。

| p | 本段新增內容重建／附近非法推論 | 結果 |
|---|---|---|
| 0 | sort→ordered scan→gap permanence 依 p4/6/7；任意順序時不成立 | 有條件支持 |
| 1 | exact coverage 排除填 gap；不是只包住最左到最右 | 支持；descriptive checkpoint null |
| 2 | shared endpoint→overlap；整數端點不推出離散集合 | 支持；checkpoint null |
| 3 | caller preservation 是選定實作權限，不是 problem requirement | 支持；checkpoint null |
| 4 | left<=start 需 ordered arrivals；比較在本次 update 前 | 支持 |
| 5 | overlap+ordered→保留 left/max end；contained example 排除直接 end | 支持 |
| 6 | strict gap+future monotonic starts→final；沒有 order 不成立 | 支持 |
| 7 | earlier gaps+left 不後退→只查 last；不能省掉先前 invariant | 支持 |
| 8 | sort 足以提供順序，不是所有 correct algorithms 的必要條件 | 支持；checkpoint null |
| 9 | last pair 是 group，與 previous input pair 區分 | 支持；連 p21/26 |
| 10 | key 每 pair 一次、new outer list；equal starts 的 max union 同值 | 支持；不聲稱 deep copy |
| 11 | fresh output pair 先建後改；shared originals 的 mutation 反例 | 支持；未作唯一方法宣稱 |
| 12 | constructed input 是例子；未宣稱執行過程式 | 支持；checkpoint null |
| 13 | sorted 完成才 scan/unpack；outer 不 rearrange input | 支持 |
| 14 | empty 判斷先於 last lookup；append 後變 [[1,4]] | 支持 |
| 15 | 前態 [1,4] 加 contained [2,3] end 仍 4；不能退到 3 | 支持 |
| 16 | max(4,6) 寫 end slot，left 因 order 保持 1 | 支持 |
| 17 | 先 6 再 8 的 closed touching 更新；half-open 改變 contract | 支持 |
| 18 | gap append 前後各值、input exhaustion→return；last 已存無 flush | 支持 |
| 19 | or 的左側短路才保護空 list；交換 operands 不受此論證保護 | 支持 |
| 20 | hints 不作 runtime validation；empty behavior 不成合法 input 宣稱 | 支持 |
| 21 | post-iteration processed union；不擴為 update 中途或完整輸入 | 支持 |
| 22 | empty processed set 初始化、first append 建立 base | 支持 |
| 23 | overlap union 不填 gap；left 不變保留 earlier separation | 支持；語意為 union 加入新段覆蓋，非數量相加 |
| 24 | gap 後 old last final、新 last 接手 unfinished | 支持；依 future starts |
| 25 | finite n 消耗與全處理完成→result；unfinished 不等於 missing data | 支持 |
| 26 | group end=10，不是 previous end=3；false gap witness | 支持 |
| 27 | same scan 在亂序丟 [1,2]；不推出所有免 sort 方案都錯 | 支持 |
| 28 | bounded model 與上界，不是 runtime 保證恰好翻倍 | 支持；checkpoint null |
| 29 | n visits bounded work，append aggregate 另連 p30；不從一行判常數 | 支持 |
| 30 | r 固定、C=O(k)、整序列；不保證每次 append constant | 支持 |
| 31 | conceptual balanced merge levels；不冒充 exact CPython trace | 支持；checkpoint null |
| 32 | schedule 的 level accounting 連 p31 merge 費；不是實際觀察紀錄 | 依正文有界重建；未外查 source truth |
| 33 | 固定 64 與至多 n boundaries 加到前界；不忽略 schedule work | 支持 |
| 34 | O(k) output、O(n) aux 分開；shared input pairs 不重算配置 | 支持 |
| 35 | 改 mutation 只去 outer copy，workspace 仍可能成長 | 支持；checkpoint null |
| 36 | used 保證只選未用且選最小；相同 start 不需固定 tie order | 支持 |
| 37 | n² / arithmetic sum 推平方；markers 與 output 分開 | 支持 |
| 38 | reliable order→去 ordering；cost chain 完整，fresh necessity 措辭待裁定 | **BODY SCOPE UNRESOLVED** |
| 39 | interview 摘要須接 p4/6/8，不能變所有演算法必 sort | 支持 |
| 40 | group coverage 非 previous input end，連 p5/9/26 | 支持 |
| 41 | equality 僅在 closed contract；half-open 不套用 | 支持；checkpoint null |
| 42 | worst-case CPython sort+aggregate scan；cost premises 連 p28–34 | 支持；不是新成本證明 |
| 43 | reliable sorted contract、aux 排 output、append aggregate 仍保留 | 成本支持；連 p38 的正文範圍待裁定 |

## Active、chunks 與 pronunciation

16 項 Active 逐項核對：primary term 與 source_quote 是原段精確 substring；其 complete English sentence 沒把短語當不完整答案；cue/oracle 也帶條件。例如 item 04 的 `one way` 專門區分充分機制與必要機制，item 11 的 amortized cost 必須說 k 次序列而非每次 constant；item 13/14 區分 output auxiliary 與 in-place workspace；item 16 強調 reliable producer contract 與 output exclusion。跨段 cost 或 reasoning 依賴均有 supporting_sources，不依賴 heading 或本文外常識來填推導。所有 Active 指向的 decision 也含 cue/oracle。

chunks 由 `author_annotations.py` 的逐段 B 清單明確指定：先檢查句子／分句，再在介系詞、分詞或條件界線加 minor；沒有按每 3–5 字機械分割。bundle 只選真正緊密的工程詞組，例如 `closed interval`、`partial answer`、`Powersort merge schedule`；不把每個 chunk 都框起。識別字、公式、原有 brackets、比較運算符保留為 source bytes。major boundary 交給既有 renderer 的 `//`+line-break 規則；未自行更改 schema。長成本段保留若干較長 syntactic chunks，沒有為字數拆開 identifier 或條件。

發音來源：NOT_RUN。只有 input allowlist 可讀，沒有獨立 pronunciation entries；因此所有 tokens 無 stress，使用 plain-word fallback，不偽造 primary-stress 或 prosody PASS。syntax/bundle 是本 Owner 的閱讀版面判斷，沒有獨立眼動、真人朗讀或 pronunciation reviewer。完整 bytes 恢復只驗證 identity，不能替代 attachment/meaning 審查。

## 機械結果與權限

`verification-final.json` 檢查 44/44 coverage、concatenated token text 等於 exact supplied English paragraph、quote bindings、decision/Active links、question cues <=15 words、stress fallback、paired Markdown Git blobs 等，最終 errors 為空。這是本地針對真實 manifest 的檢查，不是原 repository admission CLI 或 site runtime。重算 Markdown Git blob 與模板相同，未僅信任宣告的 digest。正文檔案未寫入。

consumer output 是 flat `output.json`：annotation_content_created=true、publication_performed=false、source_body_changed=false；它記錄動作，不表示 semantic approval。沒有 publication、source-body、git、CI 或 provider 寫入。四次接觸仍是同篇原文的教學設計；沒有發生 learner attempt、oracle comparison 或測量讀速，learner evidence=NOT_OBSERVED。完整 review 受 p38 未裁定事項約束。
