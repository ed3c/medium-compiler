from pathlib import Path
import json,copy,hashlib,os,difflib
O=Path(__file__).parent;PREV=O.parent;I=PREV.parent/'annotation-input-v2'
p=json.loads((I/'paragraphs.json').read_text());old=json.loads((PREV/'manifest.json').read_text());m=json.loads((I/'manifest-template.json').read_text())
def mapped(i):return i if i<=34 else i+2
def src(i):return {'paragraph_index':i,'english_quote':p[i]['english_source']}
def expand(i):return [34,35,36] if i==34 else [mapped(i)]
def rebind(obj):
 if isinstance(obj,dict):
  if set(obj)=={'paragraph_index','english_quote'}:
   raise RuntimeError('references must be rebound as lists')
  result={}
  for k,v in obj.items():
   if k=='supporting_sources':result[k]=[src(j) for r in v for j in expand(r['paragraph_index'])]
   elif k=='paragraph_index':result[k]=mapped(v)
   elif k=='source_paragraph_indices':result[k]=[j for n in v for j in expand(n)]
   else:result[k]=rebind(v)
  return result
 if isinstance(obj,list):return [rebind(x) for x in obj]
 return copy.deepcopy(obj)
m['decisions']=rebind(old['decisions']);m['active_items']=rebind(old['active_items'])
anns={mapped(a['paragraph_index']):rebind(a) for a in old['paragraph_annotations']}
# Changed/additional clauses are authored, not automatic word-count chunks.
B={
34:['one outer list','including proportional spare capacity.','ordered holds','Those shared objects','merely because ordered is new.'],
35:["the key function's one result","Our key is",'To merge runs','CPython copies','while writing the merged order','it may first skip','With m = min(a,b)','this needs at most','For eight items','that is at most','Merges execute one at a time','when more space is needed','CPython releases the old dynamic buffer','before allocating the larger one.','Peak scratch storage','not the sum of all merges.','Pending-run records','the logarithmic pending count','Together with the n key slots','these live arrays and records','CPython key storage'],
36:['before the interval scan begins.','During the scan','ordered remains live','while the O(k) result grows','loop variables occupy constant space.','Excluding the output','Including the output','hence O(n)','Sorting workspace and answer growth','so their allocation totals','CPython sort cleanup.'],
40:['the useful adaptation','Feed each arriving pair','The ordering premise','the gap proof','There are still n visits','so the scan takes','With no ordered list','it needs O(1)','beyond the retained O(k) result.','This adaptation keeps',"so its in-place endpoint updates",'This is preferable','merely observing'],
}
bundles={34:['two-slot pairs'],35:['Peak scratch storage','sorting workspace'],36:['different phases'],40:['nondecreasing start order','fresh answer pairs']}
def projection(i,cue):
 s=p[i]['english_source'];cuts={0:None};spans=[]
 for phrase in B[i]:
  a=s.index(phrase)
  if a:cuts[a]='major' if s[:a].rstrip().endswith(('.', '?', ';', ':')) else 'minor'
 for phrase in bundles[i]:
  a=s.index(phrase);b=a+len(phrase);cuts.setdefault(a,None);cuts.setdefault(b,None);spans.append((a,b))
 keys=sorted(cuts);tokens=[]
 for j,a in enumerate(keys):
  b=keys[j+1] if j+1<len(keys) else len(s);t={'text':s[a:b],'break_before':cuts[a]}
  if (a,b) in spans:t['bundle']=True
  tokens.append(t)
 return {'tokens':tokens,'skeleton':cue}
def context(text,ids):return {'text':text,'supporting_sources':[src(i) for i in dict.fromkeys(ids)]}
def authored(i,note,premise,cp,deps,cue,active=False):
 return {'paragraph_index':i,'kind':'PASSIVE_AND_ACTIVE' if active else 'PASSIVE','decision_ids':['space'],'english_source':p[i]['english_source'],'zh_note':note,'reading_context':{'premises':[context(premise,[i]+deps)],'checkpoint':context(cp,[i]+deps) if cp else None},'speed_reading':projection(i,cue)}
anns[34]=authored(34,'output 有 k 個 fresh two-slot pairs 與 outer list，為 O(k)；ordered 只持有 n 個 input references，不是另建 n 組 input pairs。','n 是輸入數、k 是結果數；fixed pairs 與 proportional spare capacity 按本文模型計數。',None,[11,28,30],'Which objects are new and which references are shared?',True)
anns[35]=authored(35,'n 個 key slots 加上較短 run 的至多 2m 暫存；2m<=a+b<=n，合併逐次重用 buffer，所以按最大一次估 peak，而非累加每次配置。','本文分析 CPython 3.14 key-based sort；m=min(a,b)，a、b 為本次 runs 長度，pending count 沿用前段 logarithmic 界。','各 merge 依序使用 buffer；擴容前先釋放舊 dynamic buffer，peak 以同時存活的 slots 與 records 計。',[10,28,31,32],'Why does peak workspace follow one merge rather than their sum?',True)
anns[36]=authored(36,'sort 的 dynamic arrays 在 scan 前釋放；scan 留 ordered 並增長 O(k) output。auxiliary peak O(n)，含 output 為 O(n+k)=O(n)。','n、k 定義與 k<=n 不變；計 peak live storage，output 與 auxiliary 分開。','sort cleanup 先於 scan；scan 時保留 ordered、result 與固定 loop variables，不保留 dynamic sort buffer。',[28,34,35],'Which allocations remain live when the interval scan begins?',True)
a=anns[40]
a['english_source']=p[40]['english_source']
a['zh_note']='可靠的 nondecreasing starts 保證允許省略 ordering；本文保留 fresh answer pairs，使原地 end 更新不改 caller。scan O(n)，output 外 state O(1)。'
a['speed_reading']=projection(40,'What guarantee permits removing the ordering step?')
# The updated body directly states the selected implementation's sufficient ownership mechanism.
a['reading_context']['premises'][0]['text']='排序保證來自 input producer；此 adaptation 明確保留所示 fresh-pair／原地 end 更新方式，O(1) 不含結果。'
a['reading_context']['premises'][0]['supporting_sources']=[src(i) for i in [40,5,6,11,28,29,30,34,35,36]]
a['reading_context']['checkpoint']['supporting_sources']=[src(i) for i in [40,5,6,11,28,29,30,34,35,36]]
# All expanded source bindings now point to v2; costs refer to the actual new storage derivation.
space=next(x for x in m['decisions'] if x['id']=='space')
space['source_paragraph_indices']=[34,35,36,37]
space['passive']='output 的 k 組 fresh pairs 為 O(k)；n key slots 加可重用的至多 2m merge slots 與 pending records 為 O(n) sorting workspace。sort cleanup 後 scan 留 ordered 與 result；list.sort 只去掉 outer copy，不消除 workspace。'
space['oracle']='Removing the separate outer list leaves sorting workspace: n key-reference slots, a reused smaller-run merge buffer and pending-run records can still scale with n.'
# Update the item oracle to expose the body derivation rather than merely name its workspace.
item=next(x for x in m['active_items'] if x['id']=='intervals-active-13')
item['oracle']='ordered holds n references. Sorting has n key slots plus a reused merge buffer with 2m <= n slots and bounded pending-run records; after cleanup, the scan retains ordered and the O(k) result.'
item['supporting_sources']=[src(i) for i in [11,28,30,35,36]]
# New productive targets follow genuinely new workspace/lifetime reasoning, not a quota.
m['active_items'] += [
 {'id':'intervals-active-17','paragraph_index':35,'decision_id':'space','term':'Peak scratch storage','source_quote':'Peak scratch storage','english_sentence':'Peak scratch storage follows the largest individual merge because merges execute one at a time and reuse the buffer.','active_cue':'Why does the merge count not multiply peak scratch storage?','oracle':'The buffer is reused sequentially, and an old dynamic buffer is released before a larger one is allocated. With m=min(a,b), at most 2m <= n merge slots are needed at once.','supporting_sources':[src(28),src(32)]},
 {'id':'intervals-active-18','paragraph_index':36,'decision_id':'space','term':'different phases','source_quote':'different phases','english_sentence':'Sorting workspace and answer growth occur in different phases, so their allocation totals must not be multiplied by the number of merges.','active_cue':'What storage is live during the scan, and how is peak space bounded?','oracle':'Dynamic sort keys and the merge buffer have been released. ordered remains live with n references while the O(k) result grows; auxiliary peak is O(n), and peak including output is O(n+k)=O(n) because k<=n.','supporting_sources':[src(28),src(34),src(35)]}
]
m['paragraph_annotations']=[anns[i] for i in range(46)]
(O/'first-revised-draft-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
(O/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
# Reuse is explicit and exact; rebindings are excluded from semantic-text reuse claims.
changes=[]
for olda in old['paragraph_annotations']:
 oi=olda['paragraph_index'];ni=mapped(oi)
 if oi==34:changes.append({'old_index':34,'new_indices':[34,35,36],'action':'reauthored replaced paragraph plus two added paragraphs'});continue
 newa=anns[ni]
 changes.append({'old_index':oi,'new_index':ni,'english_body_identical':olda['english_source']==newa['english_source'],'zh_note_exactly_reused':olda['zh_note']==newa['zh_note'],'context_text_exactly_reused':[(v['text']) for v in olda['reading_context']['premises']]==[(v['text']) for v in newa['reading_context']['premises']],'speed_projection_exactly_reused':olda['speed_reading']==newa['speed_reading'],'all_source_bindings_revalidated':True})
oldref={'english':old['english_source']['git_blob'],'zh':old['source']['git_blob']};newref={'english':m['english_source']['git_blob'],'zh':m['source']['git_blob']}
delta={'scope':'revision from own v1 manifest, not blind generation','old_git_blobs':oldref,'new_git_blobs':newref,'paragraph_mapping_and_reuse':changes,'active_items_reused_with_rebound_indices':[x['id'] for x in old['active_items']],'active_oracle_reauthored':['intervals-active-13'],'active_added':['intervals-active-17','intervals-active-18'],'decision_semantics_reauthored':['space'],'historical_unresolved_finding':'v1 p38 necessity-scope retained in parent semantic-review.md unchanged; v2 p40 explicitly names the shown fresh-pair implementation; reviewed anew in correction semantic-review.md'}
(O/'delta.json').write_text(json.dumps(delta,ensure_ascii=False,indent=2)+'\n')
records={'input_root':str(I),'files':[{'path':str(x.relative_to(I)),'sha256':hashlib.sha256(x.read_bytes()).hexdigest(),'bytes':x.stat().st_size} for x in sorted(I.rglob('*')) if x.is_file()],'own_v1_inputs':['manifest.json','read-records.json','semantic-review.md','author_annotations.py','verify_manifest.py'],'instruction_reuse':'All frozen instruction file hashes compared with own v1 read-records and unchanged; reuse previously read relevant contracts, no repository access.','article_read':'New complete bilingual bodies read, changed paragraphs 34–45 re-read in untruncated exact paragraph output; unchanged English paragraph identity checked against own v1 manifest.','other_outputs_read':False,'author_or_reader_reports_read':False,'pronunciation':'NOT_RUN; plain-word fallback','learner_evidence':'NOT_OBSERVED','independent_reader':'NOT_RUN','draft_sha256':hashlib.sha256((O/'first-revised-draft-manifest.json').read_bytes()).hexdigest()}
if os.environ.get('CODEX_THREAD_ID'):records['CODEX_THREAD_ID']=os.environ['CODEX_THREAD_ID']
(O/'read-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
(O/'output.json').write_text(json.dumps({'annotation_content_created':True,'publication_performed':False,'source_body_changed':False},indent=2)+'\n')
print(json.dumps({'paragraphs':len(m['paragraph_annotations']),'decisions':len(m['decisions']),'active_items':len(m['active_items']),'old_and_new_ids':{'old':oldref,'new':newref}}))
