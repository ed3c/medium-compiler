目前 source 是 v2 的46段，完整 exact English projection 來自該 packet。42個原 speed projections 依 source identity 與語意再檢後明示沿用；p34、35、36、40重新撰寫 boundaries/bundles。公式、identifier、source punctuation 保持原 bytes。

pronunciation authority 未提供、外部查詢 NOT_RUN，所有英文 tokens 無 stress 欄位，採 faithful plain-word fallback。syntactic chunk/bundle 是本 Owner 的有界判斷，沒有獨立 pronunciation/chunk reviewer、browser layout drive 或真人讀速測量。主要 claim 依完整 note+premises+checkpoint+sources 閱讀，問句 cue 不是獨立定理。

原 v1 的 p38 unresolved finding 保持原樣保存；這次是實際 v2 p40 以 shown implementation 限定的正文改寫，經 direction/counterexample 重建後解除本版該範圍問題，不是刪除歷史警告。
