from pathlib import Path
import json,hashlib
O=Path(__file__).parent;I=O.parent.parent/'annotation-input-v2'
p=json.loads((I/'paragraphs.json').read_text());m=json.loads((O/'manifest.json').read_text());errors=[]
def require(v,message):
 if not v:errors.append(message)
def refs(rs,label):
 require(bool(rs),label+' empty')
 for r in rs: require(0<=r['paragraph_index']<len(p) and bool(r['english_quote']) and r['english_quote'] in p[r['paragraph_index']]['english_source'],label+' invalid quote')
ds={d['id']:d for d in m['decisions']}
require(len(ds)==len(m['decisions']),'duplicate decision')
require([a['paragraph_index'] for a in m['paragraph_annotations']]==list(range(len(p))),'coverage')
for a in m['paragraph_annotations']:
 i=a['paragraph_index'];require(a['english_source']==p[i]['english_source'],f'{i} exact primary')
 require(''.join(t['text'] for t in a['speed_reading']['tokens'])==a['english_source'],f'{i} lossless')
 require(len(a['speed_reading']['skeleton'].split())<=15 and a['speed_reading']['skeleton'].endswith('?'),f'{i} question cue')
 require(all(d in ds for d in a['decision_ids']),f'{i} decision link')
 for v in a['reading_context']['premises']:refs(v['supporting_sources'],f'{i} premise')
 if a['reading_context']['checkpoint']:refs(a['reading_context']['checkpoint']['supporting_sources'],f'{i} checkpoint')
 for t in a['speed_reading']['tokens']:
  require(t['break_before'] in [None,'minor','major'],f'{i} marker');require('stress' not in t,f'{i} stress fallback')
for x in m['active_items']:
 i=x['paragraph_index'];require(x['decision_id'] in m['paragraph_annotations'][i]['decision_ids'],x['id']+' decision bind')
 require(x['term'] in p[i]['english_source'] and x['source_quote'] in p[i]['english_source'],x['id']+' term binding')
 require(m['paragraph_annotations'][i]['kind']=='PASSIVE_AND_ACTIVE',x['id']+' role')
 require(bool(ds[x['decision_id']].get('active_cue')) and bool(ds[x['decision_id']].get('oracle')),x['id']+' missing decision-level active fields')
 require(x['english_sentence'].endswith('.'),x['id']+' sentence')
 if x.get('supporting_sources'):refs(x['supporting_sources'],x['id'])
for path,field in [('article.zh-TW.md','source'),('article.en.md','english_source')]:
 blob=hashlib.sha1(b'blob '+str(len((I/path).read_bytes())).encode()+b'\0'+(I/path).read_bytes()).hexdigest()
 require(blob==m[field]['git_blob'],path+' Git blob')
result={'mechanical_checks_only':True,'errors':errors,'paragraphs':len(p),'decisions':len(ds),'active_items':len(m['active_items']),'source_projection':'supplied paragraphs.json English text, with full Markdown Git blobs independently recomputed','semantic_completion':'OWNER_REVIEWED_CURRENT_EDITION_SEPARATE_FROM_INDEPENDENT_READER','learner_evidence':'NOT_OBSERVED'}
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(bool(errors))
