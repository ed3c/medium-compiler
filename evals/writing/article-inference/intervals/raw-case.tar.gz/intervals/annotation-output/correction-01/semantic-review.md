# correction-01：目前完整 annotation 的實際審查

本次是對 v2 approved body 的修訂與完整再檢，不是 blind annotation generation。只使用 annotation-input-v2 與本 Owner 的 v1 output；沒有讀取 Content Owner／Reader reports、原始 source docs、其他 case outputs 或 expected answers。本文外 CPython 實作真實性未另查驗，以下判斷限定 supplied article 能否支持 annotation。

原有 44 段與初稿、首次欄位缺陷、`semantic-review.md` 的 p38 unresolved finding 全部保留在上層，未覆寫。新版為 46 段；來源 English Git blob 是 `dd23e01dd1f80f08a41c360f5bf61ea96d6e092c`，zh-TW Git blob 是 `4bae9aeeea0595847debac205a192bb8356c509e`。Git blob 由實際 Markdown bytes 重算；不是只改宣告。

## 實際 delta 與沿用範圍

新版 p0–33 的 English paragraphs 與 v1 逐字相同。原 p34 拆成新版 p34、35、36，原 p35–37 移到 p37–39，原 p38 改寫成 p40，原 p39–43 移到 p41–45。v2 supplied bilingual body 與 paragraph map 均已檢視。所有全文 exact quotes 與 paragraph indices 重新綁定，沒有繼續用舊 p34 的 quote 假裝支援新分段。

原有 42 個 zh_notes 的語意文字與其 speed projections 原樣沿用，條件與 checkpoint 逐段重新讀過；對應與每欄 exact-reuse 結果記錄在 `delta.json`。這些不能計成 42 次新的獨立內容生成。p34 重新撰寫，p35/36 新增，p40 的 note、premise 與 projection 依新正文重寫。`space` decision 的 passive/oracle 新撰；Active 13 的成本 oracle 依新 workspace 推導重寫；Active 17/18 分別練習 peak scratch storage 與不同階段的 allocation lifetime，沒有詞彙數量配額。

`first-revised-draft-manifest.json` 是第一次完整新版稿，保存後才檢查。第一次機械檢查發現 Active 13 的 `auxiliary space` 主引用仍在 p34，而新 p34 已不含該 phrase。這是實際 reanchor 缺陷，留在 `verification-first.json`。最終將該項移到真的含此語句與結論的 p36，並把 p34 改回 PASSIVE、補 p34 為該項 supporting source。初稿未修改；兩次 verifier 輸出都保留。沒有第二次失敗或隱藏修正。

## 原始 p38 問題如何在正文解決

v1 原句 `Preserving the caller's pairs still requires fresh answer pairs.` 曾因可能把充分機制說成普遍必要條件而保留 unresolved。原發現及「same merge rule 也許可限縮」的可能解讀沒有被刪除。

v2 p40 實際改為：`This adaptation keeps the shown implementation's fresh answer pairs, so its in-place endpoint updates cannot change the caller's pairs.` 中文也明說「這個調整保留所示實作新建答案端點組的做法」。這次判斷依正文的新關係，並非沿用 parent 的結論：主詞是 this adaptation，對象是 shown implementation；fresh pair 先建立，後續 in-place end 更新作用於答案 pair（p11），故不影響 input pair。它不再量化所有保留 input 的演算法。

反向檢查仍用「無 overlap 的 sorted input 可以只參照 originals，或延伸時替換 pair」測必要性。這些合法不同機制不違反 v2 的局部充分條件，因為 v2 已沒有說它們不存在或不合法。因此舊 necessity-scope 在**新版正文**已得到 source-supported 解決；v1 自身仍是原先 unresolved 的歷史狀態，不能改標為當時已通過。新 p40、p45、ownership/sorted-input decisions 與 Active 16 都未重引入 universal requires。沒有用 annotation 補正文缺失。

## 新空間論證的重建與反例

p34 的 output：每個 returned pair 固定兩個位置，k 對加 outer list 與 proportional spare capacity（p30）是 O(k)。ordered 有 n references，但 p11 已說指向 input pair objects；新 outer list 不推出 n 次 pair 配置。這只是在計 representation，不把 output 算成 auxiliary。

p35 正文明示這些依賴：

- `the key function's one result per input needs n key-reference slots`，配 p10 每 pair 一次 key；key 是既有 bounded endpoint integer，沒有虛構 n 個新任意長 key objects。
- `With m = min(a,b), this needs at most m key slots and m matching pair-reference slots: 2m <= a+b <= n.` 因此一個 merge 的暫存兩組 references 至多 n slots。八個 items 分 4+4 時，是四個 key slots 加四個 matching references；不是四個總 slots。
- `Merges execute one at a time and reuse this buffer`，需要更大時先釋放舊 dynamic buffer。故同時存活的是最大的一次 merge buffer，不能乘所有 merges 的次數。
- pending records 的 position/length/level 固定大小；p32 的 pending-count logarithmic argument 給 O(log n)，也在 O(n) 內。把 n 個 key slots、至多 n 個 merge slots、O(log n) records 相加，仍為 O(n)。這是加總**同時存活**的結構，不是只引用結論。

p36 正文明說 dynamic key array 與 merge buffer 在 interval scan 前釋放；scan 期間 ordered 的 n references 留著，output 增長至 k pairs，loop scalars constant。排序期 auxiliary O(n)，掃描期 auxiliary n+O(1)，兩階段的 max 仍 O(n)。包含 output 的上界 O(n+k)，由 k<=n 得 O(n)；這是可用上界，不宣稱每一類排序 workspace 與完整 result 同時達峰值。

區分測試：若每個 merge buffer 都保留到最後，正文的 sequential reuse／release 前提就不成立，不能用「最大一次 buffer」作證。若錯把 4 keys+4 references 算四格，新段的 `2m` 直接反駁。若只去掉 ordered outer copy 而仍保留 n key slots 與 scratch，p37 的 list.sort 仍不能證明 O(1)。若 n 不再是 bounded scalar model，p28 的單位假設也不能照搬。這些 counterfactuals 只測推論邊界，沒有新增正文方案或效果宣稱。

## 全文目前 annotation 再檢

完整 notes、premises、checkpoint、question cue 與所有 Active sentences/oracles 都按目前段號核對。以下不是「引用存在即通過」：每格指出目前推論及其阻止的錯誤外推。p0–33 雖字句沿用，也再次檢查它們是否受新增空間段或 p40 的範圍變化影響。

| p | 重建與方向／checkpoint 檢查 |
|---|---|
| 0 | order→future starts 不回頭→gap permanent；非任意順序結論。 |
| 1 | 結果須 exact covered positions；整段包住會填 gap，descriptive checkpoint=null。 |
| 2 | closed endpoints 共點即 overlap；整數 endpoints 不推出離散點集合，checkpoint=null。 |
| 3 | input 不保證順序，preservation 是實作選擇，不是題目硬要求。 |
| 4 | 合併前已有 left<=start<=end，order 前提不能從結果倒推。 |
| 5 | ordered overlap 的 union 保留 left 並 max end；contained case 排除直接 end。 |
| 6 | start>right 且 future>=start，才使舊群組 final。 |
| 7 | earlier gaps 與 left 不回頭，才允許只查 last，非掃描歷史可任意丟棄。 |
| 8 | sort 是充分取得 order 的機制；新版 p40 producer guarantee 仍是合法不同機制。 |
| 9 | last pair 是 connected processed group，不能當 previous input pair。 |
| 10 | once-per-pair key 與新 outer list；equal starts 用 max 維持 union，不靠特定 tie order。 |
| 11 | fresh output pair 先建後改，局部 sufficient ownership mechanism；不擴成 universally necessary。 |
| 12 | constructed Program Movie，不把它當 observed code execution。 |
| 13 | 先 sorted 產生 ordered，再解包每一對；保留原 input outer order。 |
| 14 | 空 list 先進 append，沒有 last endpoint 可讀；post append 為 [[1,4]]。 |
| 15 | contained [2,3] 不能把 end4 退成3；max 後 [[1,4]]。 |
| 16 | max(4,6) 寫 end，left 由 order 保持1。 |
| 17 | closed touching 先從6延伸8，再由8延伸10；不是 strict gap。 |
| 18 | gap append [12,12] 後存有兩段，input exhausted 可直接 return；last 非 missing data。 |
| 19 | or 先評 not merged 才短路；不能交換求值次序仍沿用安全證明。 |
| 20 | type hints 不 runtime validate，每 pair 兩格與非空來自 contract；empty return 不等於合法題目輸入。 |
| 21 | invariant 僅在 iteration 完成後指 processed union；不是 update 中途或未完成 input 的全體答案。 |
| 22 | empty prefix 為 empty union，first append 建立 base。 |
| 23 | overlap 無內部 gap、left 不移動，維持 earlier separation 與 exact union；不是重複位置數量相加。 |
| 24 | strict gap append 後 old last final，new last 是唯一可能延伸者。 |
| 25 | finite n 一輪消耗一對，termination 才使 processed=whole input。 |
| 26 | 群組 end10 不等於 previous original end3，故 start4 不應判 gap。 |
| 27 | 亂序 [[5,6],[1,2]] 顯示同一公式失去 left 前提；未否定所有免 sort 演算法。 |
| 28 | n/k 與 bounded endpoints 的 elementary cost 模型，Big O 是上界，不是每次實測剛好翻倍。 |
| 29 | n visits、bounded comparison/read/write；append 的 nonconstant work 保留 p30 依賴。 |
| 30 | fixed r<1、S<=C/(1-r)、C=O(k) 加 k writes→aggregate O(k)；不聲稱每一次 worst-case constant。 |
| 31 | conceptual merge 指標只前進 O(a+b)，一層 O(n)、doubling 約 log n 層；不是 exact CPython event trace。 |
| 32 | natural-run level 的 item charges 有 logarithmic 界，cleanup pending 同樣受界；不是 runtime observation。 |
| 33 | key/run linear、短 run <=64、n boundaries × log subdivisions 與 scan 相加，保持 worst-case sort bound。 |
| 34 | 重新撰寫，只談 output O(k) 與 ordered references sharing；不在此段塞入未展開 workspace 結論。 |
| 35 | 重新撰寫，n keys+2m merge references+pending records；sequential reuse／release 支持 peak，非總 allocations。 |
| 36 | 重新撰寫，cleanup 在 scan 前、ordered 仍存活；phase maximum 與 output exclusion 俱全。 |
| 37 | list.sort 去掉 copy 但留下新 p35 workspace，仍不推出 O(1) auxiliary。 |
| 38 | selection 選最小未用 start 得 order；used markers 防重選，同起點仍用 max。 |
| 39 | n×n checks 或 n+(n-1)+…+1=n(n+1)/2，平方工作；markers O(n)，output 還是 p34/p30 的 O(k)。 |
| 40 | 新正文明確限定 shown implementation 的 fresh pairs；reliable producer order→去 sorting，n visits+append aggregate O(n)，output 外 state O(1)。 |
| 41 | interview 的 strict-gap permanence 仍依 nondecreasing starts，非每種演算法必 sort。 |
| 42 | interview 的 maximum end 代表全群組，contained interval 不能縮短 coverage。 |
| 43 | equality 的充分前提是 closed contract，不能套 half-open；checkpoint=null。 |
| 44 | cost interview 同時保留 CPython worst-case sort、aggregate append scan、output/auxiliary 區分，並連到新 p34–36 完整推導。 |
| 45 | reliable sorted-input guarantee 下去 ordering；O(1) 明確排除結果，cost 仍依 p28–30/p40。 |

反向重建：要 return 合法 result，先要 p25 termination 與 p21 invariant；維持 invariant 要 p4 order 及 p5/6 transitions；ownership 另需 p11 的 selected allocation pattern；time 需 p28 scalar model、p29 visit count、p30 aggregate 與 p31–33 sort schedule；space 不能再停在「workspace proportional n」，而依新 p35 數 live slots、p36 phase maximum。repeated selection 更改的是取得 order 的 work，不改 union rule；sorted-input 更改 order 的提供者並移除 sort allocations。沒有使用本次 source packet 外的結論填補 note。

## Active 與 reading projection 的實際審查

所有18項 Active 的 term/source_quote、primary index、sentence、cue/oracle 與 supporting chain 全部重綁並檢查，不把新增兩項算 learner performance。原有含成本的 Active 13 現在 anchored p36，source_quote=`auxiliary space` 在原段精確出現；oracle 具體說 ordered n refs、n key slots、2m<=n merge storage 與 cleanup 後的存活狀態。其 p34 supporting quote 說 output pair 計數。Active 14 的 in-place-sort 問題依新 p35 workspace 仍保持正確。

新 Active 17 `Peak scratch storage` 是 p35 的 exact phrase，完整 English sentence 只把 largest individual merge 與 sequential reuse 相連，oracle 明定釋放舊 buffer、2m<=n。它不說「scratch 是唯一 auxiliary」。新 Active 18 `different phases` 位於 p36，sentence 不把 allocation total 當 peak，oracle 限定 dynamic sort arrays 已釋放而 ordered 仍活著；n+k 化 n 連到 p28 的 k<=n。兩項都幫工程師解釋當前 source 的 peak-storage 決策，不是無關詞彙。

42 個 unchanged speed projections 已按目前 source identity 再核對；p34/35/36/40 的 phrase boundaries 是逐段 authored。p35 保持 `2m <= a+b <= n`、`m = min(a,b)` 完整，不按字數切公式；capacity／merge-count 條件不被分成無條件口號。p36 先看 cleanup，再看 scan，問句要求辨認 live allocations。major 表示既有 renderer 應加 `//` 及換行；bundle 是 source 中的 lexical phrase。未新增 stress，因 pronunciation authority 不在可讀 packet；全部使用 plain-word fallback。沒有宣稱 verified prosody、讀速或 human comprehension 提升。

## 結果範圍

最終本地 verifier `errors=[]`：46/46 paragraphs，18 decisions、18 Active items；tokens concatenate 精確還原 supplied English、每個 supporting quote 精確存在、所有 primary terms 綁定、roles 與 decision IDs、<=15-word reading questions、Git blobs 均核對。它是本 Owner 的補充機械檢查，不是 repository CLI admission、browser verification 或獨立 Reader。

本次完整 source-bound annotation review 沒有發現新的 unresolved body argument；原 necessity-scope 只在 v2 新正文的明確局部敘述下解除。這是 annotation Owner 的有限 self-review，非對原外部 CPython sources 的獨立事實審查。模板 `semantic_verification=OWNER_REVIEW_REQUIRED` 欄位保持原契約，沒有發明新的 renderer/admission 狀態。

source Markdown bytes 未修改；沒有 Git、CI、provider、publication 或新 agent 操作。flat output.json 只記錄實際動作。Independent Reader/learner attempts 未執行，learner evidence=NOT_OBSERVED；沒有速度、鞏固或真人學習效益主張。
