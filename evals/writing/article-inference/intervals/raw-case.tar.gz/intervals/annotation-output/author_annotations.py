from pathlib import Path
import json, hashlib, os, datetime
OUT=Path(__file__).parent
IN=OUT.parent/'annotation-input'
P=json.loads((IN/'paragraphs.json').read_text())
M=json.loads((IN/'manifest-template.json').read_text())
# Authored notes, premises, checkpoint, dependencies, and reading questions. No generated lexical quota.
rows=[
('依 left endpoints 排序後，遇到 gap 就能讓前一段定案，因為未來 start 不會往回。','這是依起點排序後的單次 scan；定案依賴 future starts 不遞減。','先取得排序順序，再比較與更新最後一段。',[4,6,7],'What makes a gap permanent?','order'),
('closed interval 包含兩端點；答案要保留 exact coverage，不能為了合成大區間而填滿 gap。','輸入是合法雙端點 closed intervals；回傳需保持原本覆蓋位置。',None,[],'Which coverage must the result preserve?','coverage'),
('相接的 closed intervals 共享端點而合併；整數端點不代表只覆蓋整數點，[12,12] 也有覆蓋。','使用包含端點的連續區間語意，不能以整數相鄰取代是否重疊。',None,[1],'When does touching count as overlap?','coverage'),
('輸入可能晚到連接段；此實作選擇回傳 start order 並保留 caller input，後者不是題目要求。','題目不保證輸入順序；保留輸入是本文實作選擇。',None,[1],'Which guarantees come from the implementation?','ownership'),
('start order 給出 left <= start，輸入合法性給出 start <= end；再依 start 與 right 分支。','目前群組是 [left,right]，下一段是 [start,end]，且起點依序不遞減。','在比較下一區間、更新目前群組之前使用這些不等式。',[1,8],'Which inequalities permit the two cases?','order'),
('有 left <= start 且 start <= right 時，union 保留 left 並取 max(right,end)；內含段不能縮短群組。','合併公式以已排序起點為前提；此處只處理 start <= right 的 overlap。','完成 max 更新後，群組覆蓋不縮短。',[4,15],'Why keep the farther right endpoint?','max-end'),
('strict gap 後所有 future starts 都在更右側，無法回接目前群組；因此可以另開新段。','起點不遞減，且本次比較得到 start > right。','確認 strict gap 後，舊群組定案，再以新段繼續。',[4,8],'Why can later intervals not bridge this gap?','gap'),
('只查最後一段，是因為較早各段已被跨過的 gap 隔開；延伸 right 不會讓 left 往回。','merged 由已排序 scan 產生，前面各段與最後一段間已有嚴格 gap。','已完成前一段的分支更新，才以目前最後一段比較下一個 start。',[5,6,9],'Why inspect only the last result interval?','gap'),
('sort 是取得 nondecreasing starts 的一種機制；正確性需要這個順序保證，不要求所有演算法都 sort。','討論的是本文保留 left 的 scan，所需前提是未來 start 不會更小。',None,[4,6,38],'Is sorting the only way to obtain order?','order'),
('merged 的 pair 代表整個 connected group；merged[-1][1] 是群組最遠端，不一定是上一個原始 pair 的 end。','ordered 已依起點排序；merged 記錄已處理群組的 exact coverage。','每次更新結束後，前面各 pair 定案，最後一對仍可能延伸。',[7,21,26],'What does the last pair represent?','state'),
('key=lambda interval: interval[0] 取 start；sorted 回傳新 outer list。equal starts 仍可用 max end 得到相同 union。','key 比較左端點；同起點的順序不影響本文 max-end 合併規則。','每個輸入 pair 計算一次 key，排序完成後才進入 scan。',[5],'How do keys and equal starts affect the union?','order'),
('新 outer list 仍共享 input pairs；本文 append fresh pair，讓後續 endpoint mutation 只改答案。','Python list 持有 references；本文選擇更新 answer pair 的 end slot。','先建立 fresh answer pair，再對它更新端點，避免改到共享 input pair。',[3,10],'Which object receives the endpoint mutation?','ownership'),
('這句引入 constructed input；它是待追蹤的例子，並不是實際執行證據。','此處標示的是文章自行構造的 Program Movie 輸入。',None,[],'Which constructed input will the trace follow?','trace'),
('sorted 產生 ordered 而不重排 intervals；scan 逐 pair 把兩個數字綁給 start、end。','沿用 sorted 的新 outer list 與共享 inner pairs 語意。','排序先完成；之後每次 loop 從 ordered 解包一對端點。',[10,11],'What is produced before scanning begins?','trace'),
('空答案先 append fresh [1,4]，得到 [[1,4]]；此分支不需要讀取既有 last endpoint。','Program Movie 的第一個 pair 是 [1,4]，merged 起初為空。','先辨識空答案，再 append；空時不做 last endpoint lookup。',[19],'How is the first pair stored safely?','trace'),
('containment 時 max(4,3)=4，所以 merged 維持 [[1,4]]；改成 3 會縮掉原本覆蓋。','處理 [2,3] 前，最後群組是 [1,4]，且起點已排序。','比較 overlap 並寫回 max 後觀察 merged。',[14,5],'Why does containment leave the answer unchanged?','max-end'),
('處理 [3,6] 時 max(4,6)=6，得到 [[1,6]]；排序前提讓 left 保持 1。','本次前態是 [[1,4]]，新段為 [3,6]，且 left <= start。','將 max 結果寫入最後 pair 的 end slot 後得到 [[1,6]]。',[15,4,5],'Which slot changes during extension?','trace'),
('closed intervals 的 equality 也 overlap：[6,8] 與 [8,10] 連續把答案延伸至 [[1,10]]。','前態是 [[1,6]]；端點相接表示共享位置，不是 strict gap。','先完成 [6,8] 更新至 [[1,8]]，再處理 [8,10]。',[16,2],'Why do both touching intervals extend the group?','coverage'),
('12 > 10 形成 gap，append [12,12] 後得到兩段；最後一段早已存在 merged，不需額外 flush。','前態是 [[1,10]]，下一段 [12,12] 是合法 zero-length closed interval。','先 append 得到 [[1,10],[12,12]]，再於輸入耗盡時回傳。',[17,2,6],'Why is no final flush needed?','trace'),
('or 的 short-circuit 先保護空 list；非空時用 start > last end 分 gap，因此 else 包含 equality。','條件的左側是 not merged，右側才讀 merged[-1][1]；max 用於 overlap 分支。','先評估空 list 判斷，必要時才評估 endpoint lookup。',[14,2,5],'Which operand prevents an empty-list lookup?','short-circuit'),
('type hints 不驗證每組長度；兩端點來自 problem contract。[] 回傳可行，但 empty input 不在題目限制內。','問題規定每組兩端點且至少一組；type hints 與 runtime validation 不同。','空輸入沒有 loop iteration，直接回傳初始化的空答案。',[1,22,25],'What do type hints leave unenforced?','contract'),
('loop invariant 在每次 iteration 結束後成立：merged 是 processed union，start-ordered 且不重疊，只有最後一段仍可能變。','processed 指已完成本次更新的輸入前綴；final 針對尚未處理的 future intervals。','立即在每次 iteration 完成後檢查 invariant，不在更新中途套用。',[4,6,9],'When does the invariant describe the partial answer?','invariant'),
('初始化時 empty result 精確覆蓋 empty processed set；第一輪存入一段後，它本身就是 exact union。','此處先沒有已處理 pair，再進入第一個合法 pair 的 iteration。','分別觀察 loop 前空狀態與第一輪 append 完成後。',[14,21],'How does initialization establish the invariant?','invariant'),
('overlap 分支以保留 left、取 max end 維持 exact union；start <= right 排除新增內部 gap，舊 gap 也仍分隔較早結果。','沿用已排序起點與分支前 invariant；本次是 overlap。','替換最後 pair 完成後檢查 union 與 earlier-pair separation。',[4,5,7,21],'Which boundaries preserve the invariant during overlap?','invariant'),
('strict gap 時 append 只加入新段；future starts >= start 使舊 last pair 定案，新 pair 接手未定案角色。','分支前已有 start-ordered、互不重疊的 merged，且 start > right。','append 完成後，舊 last 已 final，新 last 是唯一仍可能延伸者。',[6,21],'Which pair becomes final after a gap?','invariant'),
('每輪消耗一對有限輸入，終止時 processed 等於全部輸入；因此 exact union 與 non-overlap 變成完整答案性質。','前提是每次 iteration 後 invariant 保持，且 loop 走完 n 對。','輸入耗盡後才把 processed-union 結論用於整個輸入。',[21,22,23,24],'What changes at termination?','invariant'),
('不能拿 previous original end 當群組 end；[[1,10],[2,3],[4,5]] 中，群組早已到 10，不應在 4 與 3 間判 gap。','比較對象應是整個 connected group 的最遠右端，而不是上一對輸入。','完成 [2,3] containment 更新後，群組 end 仍是 10。',[5,9,15],'Which endpoint prevents the false gap?','max-end'),
('對任意輸入直接套同一 scan 會失去左側覆蓋；[[5,6],[1,2]] 違反 stored left 較早的前提。','這個失敗針對省略排序且沒有其他順序保證的同一份程式，不是否定所有免排序方法。','先存 [5,6]，再誤把 [1,2] 送入保留 left 的 overlap 分支。',[4,5,8],'Which missing order premise loses coverage?','order'),
('成本模型定義 n、k，並將有界端點比較、reference 讀寫、固定 pair 建立視為常數；Big O 描述上界成長。','n 是輸入數、k 是結果數且 k <= n；模型排除任意長整數成本。',None,[1],'Which operations are constant in this cost model?','cost-model'),
('scan 每輪固定上限次數操作，不搜尋 merged；直接選 last slot，最多建立 n 對，結果留 k 對。','沿用有界端點與 reference 操作模型；本段計數尚需另外合計 append 擴容。','走訪全部 n 對後，統計保留的 k 組結果。',[28,30],'What work repeats once per input pair?','scan-cost'),
('append 的擴容複製要合計：固定 r<1 使幾何和 <= C/(1-r)，再用 C=O(k) 加上 k 次寫入得 O(k)；單次仍可能昂貴。','這是 CPython list 的 append-only 增長序列；k 次 append，容量比例界為固定常數，doubling 只是示意。','合計整個 k 次 append 的寫入與擴容，不將 aggregate 界套成每一次 worst-case。',[28],'Why is total append work linear?','append-cost'),
('概念 balanced merge 中，兩個指標只前進使 merge 為 O(a+b)；每層 O(n)、約 log n 層，得到 O(n log n)。','此處是用有界比較與移動成本解釋 balanced merge plan，不宣稱實際排序每層都等分。',None,[28],'How do merge work and level count combine?','sort-cost'),
('Powersort 的細分層級約以 log n 為界，路徑層級下降避免同層重複計費；按參與 items 分攤 merge work 得總界。','本文指定 CPython 3.14 natural runs 與 Powersort schedule；沿用每次 merge 的 O(a+b) 計數。','按每個 item 經過的 merge 路徑及最後 cleanup 合計；這不是 Program Movie 的內部事件觀察。',[28,31],'Why can an item avoid repeated charges at one level?','sort-cost'),
('keys、runs 與有界短 run insertion 加線性工作；至多 n 邊界各用 log n 細分，與 merge、scan 合計仍為 O(n log n)。','CPython 的目標 run 長度 <=64；沿用 Powersort 層級界與已推導 scan/append 成本。','合計 key extraction、run handling、schedule、merge，再加 interval scan。',[28,29,30,31,32],'Which extra sorting operations preserve the bound?','sort-cost'),
('output 是 O(k)；ordered 的 n references 與 sort workspace 給 O(n) auxiliary。共享 input pair 不等於新配置 pair。','n、k 與 output-excluded auxiliary 定義固定；fresh output pairs 和排序暫存分開計。','以同時存活的額外狀態估 peak；O(n+k) 由 k<=n 化為 O(n)。',[11,28,30],'Which storage belongs to output and auxiliary state?','space'),
('intervals.sort 省掉 sorted outer list 但會重排 caller list；sort workspace 仍可能成長，不能推成 constant auxiliary。','只改是否允許 input mutation，並沒有移除 sorting 或它的 workspace。',None,[34],'Does in-place sorting remove all auxiliary storage?','space'),
('repeated selection 用 used markers 反覆選最小剩餘 start，再送入相同 merge rule；同起點仍由 max end 處理。','保留輸入與每對一個 Boolean used marker，每次只保留 selected index 和 best start。','每次找到最小剩餘 start 後，先標為 used，再送入 merge。',[5,8],'How can selection construct the required order?','alternative'),
('repeated selection 保留順序正確性，但 n 次選擇各查 n 標記為 n²；即使只掃剩餘也有 n(n+1)/2。markers O(n)，output O(k)。','沿用相同 fresh-pair merge 與 append-only 結果；計數的是每次重新找下一對的工作。','完成 n 次 selection 後合計所有檢查，而不是只看一次搜尋。',[28,30,34,36],'Why does repeated selection cost quadratic work?','alternative'),
('若契約保證 nondecreasing starts，可移除 ordering；沿用 max-end/gap 規則與 fresh answer pairs，scan O(n)，output 外 state O(1)。','排序保證必須來自 input producer；此處沿用本文更新 answer end 的實作及 output-excluded 空間慣例。','直接依保證的順序逐對處理；合計 n visits 與 append 序列，並保留 O(k) output。',[5,6,11,28,29,30,34],'What guarantee permits removing the ordering step?','sorted-input'),
('面試回答把 sort 連到 future starts 不遞減；strict gap 後的定案來自這個前提。','只對已取得 nondecreasing starts 的本文 merge scan 作答。','確認 strict gap 後，前一群組對所有 future intervals 定案。',[4,6,8],'Which premise should the sorting answer mention?','order'),
('maximum end 保留整個 overlapping group 的覆蓋；contained interval 不能把群組終點往回拉。','last answer pair 代表群組，並依 left<=start 的 overlap 規則更新。','每次 overlap 更新後仍保留群組已到達的最遠端。',[4,5,9,26],'What group information must an interview answer retain?','max-end'),
('equality overlap 的原因是 closed intervals 同時包含共享端點。','使用本文 closed-interval contract，而不是不含右端點的表示法。',None,[1,2],'What makes equality count as overlap?','coverage'),
('成本回答要同時保留 worst-case sort、含 amortized appends 的 scan，以及 O(n) auxiliary 加 O(k) output 的區別。','沿用本文 CPython、有界端點模型及 output-excluded auxiliary 定義。','對完整輸入合計排序與 scan，append 以整段序列計費。',[28,29,30,31,32,33,34],'Which qualifications belong in the cost answer?','cost-summary'),
('sorted-input 回答需以契約保證為前提；去掉 ordering 後保留同一 merge，O(1) 僅指 output 外 state。','input producer 可靠保證 nondecreasing starts；結果仍保留 O(k) output。','直接 scan 完 n 對，整體 append 成本沿用既有合計。',[28,29,30,38],'Which sorted-input guarantee and space exclusion matter?','sorted-input'),
]
assert len(rows)==len(P)==44
# Reviewed clause/phrase starts. A listed boundary inserts a marker only; all source bytes are sliced unchanged.
B={
0:['Walk through that order','keeping the merged result','A new interval','The reason this works','once a gap appears'],
1:['each input pair','every position','including both endpoints.','There are between','and their integer endpoints','Return non-overlapping','The returned intervals','Keeping everything'],
2:['so their replacement','But [1,4]','Integer endpoints','A zero-length interval','The problem\'s examples','Original problem'],
3:['An interval','We will return','although preserving it'],
4:['and the next interval','If starts arrive','then left <= start.','Because each input','two cases remain.'],
5:['the new interval','Their union','keep the earlier','An interval contained','Assigning right'],
6:['there is a gap.','Every later interval','so none can overlap','The current interval','Start a new interval'],
7:['Earlier result intervals','The current start','A growing last interval','but its left endpoint'],
8:['it is not a claim','The important permission','that future starts'],
9:['A pair in merged','not necessarily','merged[-1] selects','and merged[-1][1] selects','The earlier pairs'],
10:['The lambda','give it a pair','The sort uses','Thus [8,10]','while [1,4]','Python evaluates','and returns a new','Equal starts','retaining the larger','Python sorting documentation.'],
11:['Its elements','When adding an answer interval','merged.append([start, end])','and places a reference','Later endpoint updates','Appending an original pair','Python assignment','list elements','Python lists and assignment.'],
12:[],
13:['it does not rearrange','The scan visits','binding its two numbers'],
14:['there is no last','Create [1,4]','The answer is now','No endpoint lookup'],
15:['compare 2','They overlap','but max(4,3)','Writing that value back','This is the containment case','moving the endpoint'],
16:['so write max(4,6)','which is 6','into the last pair','merged becomes','The stored left endpoint','because sorting'],
17:['the start equals','The closed intervals','write max(6,8)','The answer becomes','For [8,10]'],
18:['There is a gap','so append a fresh','without changing','merged becomes','The loop then','The last interval','so no final flush'],
19:['Python\'s or stops','so the first iteration','After that first append','The else therefore','and max returns','Python truth testing'],
20:['they do not validate','That two-endpoint requirement','It also returns','although that input'],
21:['at the checkpoint','"merged contains','all but its last interval','Here, union means','The union property','the invariant also states'],
22:['the empty result','There are no finalized','The first iteration','which is its own'],
23:['replacing [left,right]','adds exactly','There is no gap','because start <= right.','Its left boundary','so it remains separated','No earlier pair','The invariant survives.'],
24:['appending [start,end]','and adds exactly','It is separate','hence also','Future starts','so the old last pair','The newly appended pair'],
25:['At termination','Exact coverage','so merged is','"Unfinished" describes'],
26:['With [[1,10]','that compares 4','The current group','so all three','The answer must retain','which the max update'],
27:['For [[5,6]','the same code','losing [1,2].','Its merge formula','Neither the formula'],
28:['with k <= n.','Count a bounded','Endpoints are bounded','so arbitrary-length','Big O gives','O(n) means'],
29:['Each iteration','It never searches','selecting its last slot','At most n new pairs','and exactly k'],
30:['A Python list','Most appends','When full','growth may allocate','CPython reserves','rather than copying','Looking backward','earlier large capacities','For a doubling illustration','The total copied references','Subtract rS:','all middle terms cancel','leaving S - rS','Therefore S <=','The fixed ratio','and proportional spare capacity','The few smallest allocations','Adding the k ordinary','though one particular append','This is the meaning','CPython\'s actual growth','CPython 3.14 list growth'],
31:['For this analysis','it recognizes','and combines neighboring runs.','To understand','consider a conceptual','Combining sorted stretches','compare their front items','move the smaller','and advance its position','Neither position','Across one level','giving O(n) work.','Stretch sizes grow','after h doublings','The number needed','so O(n) work'],
32:['CPython 3.14 actually','Its schedule also','Picture the n input','Assign each boundary','Nonempty neighboring runs','Once cell width','those midpoints','so boundary levels','The schedule merges','Along an item\'s path','levels decrease','the item cannot','The final cleanup','Charging each merge\'s','therefore gives','This is cost accounting','not a claim'],
33:['CPython also extends','but the target run length','so each inserted item','this adds linear work too.','Calculating each boundary','on at most n boundaries.','Thus the ordering step','existing order can reduce work.','Adding the O(n)','CPython sorting design'],
34:['one outer list','including proportional spare capacity.','Excluding that output','ordered holds','and sorting can retain','Loop variables','The objects shared','merely because ordered','Peak extra storage','hence O(n)'],
35:['but rearrange','It would not establish','Python\'s sorting workspace','Changing mutation permission','Python sorting behavior'],
36:['Keep the input','Scan all unused pairs','mark that pair used','then feed its endpoints','Retain only','Choosing equal starts','because the end update'],
37:['so the earlier correctness proof','But finding the next pair','With n markers','there are n*n marker checks.','Even a version','Pair the first and last counts:','each pair totals','yielding n(n+1)/2','This alternative takes','with the same fresh-pair','It avoids relying','but does not improve'],
38:['the useful adaptation','Feed each arriving pair','The ordering premise','the gap proof','There are still n visits','so the scan takes','With no ordered list','it needs O(1)','beyond the retained O(k) result.','Preserving the caller\'s pairs','This is preferable','merely observing'],
39:['"It makes future starts','After a strict gap','no future interval'],
40:['"The last answer pair','A contained interval'],
41:['"The intervals are closed.','If a start equals','both intervals'],
42:['"For this Python implementation','sorting costs worst-case','and the scan costs','including amortized appends.','Auxiliary space','plus O(k) output space.'],
43:['"I would remove','keep the same merge rule','and obtain O(n) time','with O(1) auxiliary state','excluding the output.'],
}
# Bundle choices are genuine recurrent engineering phrases, not every visual chunk.
bundles={0:['left endpoints'],1:['closed interval'],3:["implementation choice"],6:['at least as far right'],8:['one way'],9:['partial answer'],11:['two-item list'],15:['containment case'],19:['short-circuit evaluation'],21:['loop invariant'],28:['constant work'],30:['amortized cost'],31:['worst-case time','adaptive merge-based sort'],32:['Powersort merge schedule'],34:['auxiliary space'],36:['repeated selection'],37:['worst-case resource bounds'],38:['nondecreasing start order']}
# Full primary paragraph binds every asserted detail; selected additional paragraphs expose dependency chains.
def src(i): return {'paragraph_index':i,'english_quote':P[i]['english_source']}
def context_stmt(text,inds):return {'text':text,'supporting_sources':[src(i) for i in dict.fromkeys(inds)]}
def projection(i):
 s=P[i]['english_source']; cuts={0:None}
 for phrase in B[i]:
  start=s.index(phrase)
  if start:
   prefix=s[:start].rstrip()
   cuts[start]='major' if prefix.endswith(('.', '?', ';', ':')) else 'minor'
 spans=[]
 for phrase in bundles.get(i,[]):
  start=s.index(phrase);end=start+len(phrase)
  cuts.setdefault(start,None);cuts.setdefault(end,None);spans.append((start,end))
 keys=sorted(cuts);ts=[]
 for j,a in enumerate(keys):
  b=keys[j+1] if j+1<len(keys) else len(s)
  t={'text':s[a:b],'break_before':cuts[a]}
  if (a,b) in spans:t['bundle']=True
  ts.append(t)
 return {'tokens':ts,'skeleton':rows[i][4]}
# Source-derived decisions: conditions and competing actions are retained in passive explanations.
def dec(id,title,passive,indices,cue=None,oracle=None):
 d={'id':id,'title':title,'passive':passive,'source_paragraph_indices':indices}
 if cue:d.update(active_cue=cue,oracle=oracle)
 return d
M['decisions']=[
 dec('coverage','保留 exact closed-interval coverage','端點相接應合併，strict gap 應保留；比較覆蓋位置，而不是只比較整數端點是否相鄰。',[1,2,17,41],'Explain why equality counts as overlap.','Closed intervals include both endpoints, so a start equal to the current end shares that position.'),
 dec('ownership','選定 fresh answer pairs 保留輸入','sorted 只新建外層 list；本文在更新 end slot 前新建 answer pair，避免與 input 共用 mutation。',[3,11],'Explain how this implementation preserves input pairs.','It creates a fresh two-item answer list before later endpoint updates, so those updates do not modify an input pair.'),
 dec('order','取得非遞減 starts 再套 merge rule','sort 是其中一種取得順序的機制；保留 left 的規則依賴 left<=start，未保證順序時不能直接省略。',[0,4,8,10,27,39],'Is sorting necessary for every correct algorithm?','No. This merge scan needs nondecreasing starts; sorting obtains that order, while a reliable sorted-input contract can supply it directly.'),
 dec('max-end','保留群組最遠 right endpoint','對已排序且重疊的下一段保留 left、取 max right；只記 previous original end 或直接指定 end 可能縮掉覆蓋。',[5,15,26,40],'Why retain the maximum end of the whole group?','A contained interval must not shrink existing coverage, and the next gap test needs the entire group\'s farthest endpoint.'),
 dec('gap','strict gap 使前段定案','nondecreasing starts 讓 gap 後的 future starts 都在右側；前面已定案各段不需重查。',[6,7],'Why does a strict gap finalize the previous group?','With nondecreasing starts, every later start is beyond that group\'s right endpoint, so none can bridge the gap.'),
 dec('state','merged pair 表示 processed connected group','last pair 是群組 union，不必等於任何一組 input pair；end 更新只作用於群組右界。',[9]),
 dec('trace','依分支追蹤已儲存的答案','Program Movie 依序展示空答案、內含、延伸、相接與 gap；最後 pair 在 loop 結束前已存入 merged。',[12,13,14,16,18],'Why is no final flush needed?','The last interval is already stored in merged when the loop runs out of input.'),
 dec('short-circuit','先判空再讀 last endpoint','not merged 作為 or 左側先求值；非空才測 strict gap，因此 else 含 equality。',[19],'Why is the first endpoint lookup safe?','When merged is empty, not merged is true and or does not evaluate merged[-1][1].'),
 dec('contract','type hints 與輸入契約分工','兩端點與非空要求來自 problem contract，type hints 不做 runtime validation；empty-input 行為是額外程式行為。',[20]),
 dec('invariant','在 iteration 完成後檢查 processed union','初始化、overlap、gap 維持 exact union 與互不重疊；只有輸入耗盡才把 processed 性質用於全部輸入。',[21,22,23,24,25],'State the invariant checkpoint and what is final.','Immediately after each iteration, merged is the exact processed union in start order without overlaps; all but its last interval are final against unprocessed intervals.'),
 dec('cost-model','先固定 n、k 與 elementary costs','有界端點與固定 pair 允許常數比較、reference 讀寫與 pair 建立；Big O 是成長上界。',[28]),
 dec('scan-cost','分開 scan 計數與 append aggregate','n 次 scan 各有固定上限的讀寫比較；append 擴容另外合計，不能由一行 append 推出單次常數。',[29,30]),
 dec('append-cost','按 append 序列合計複製','固定比例的過去容量形成幾何上界，C=O(k) 加 k 次寫入推出總 O(k)，不保證個別 append worst-case constant。',[30],'Explain the aggregate append bound.','For k appends, the copied references are bounded by C/(1-r) with fixed r<1 and C=O(k); adding k slot writes gives O(k) total work.'),
 dec('sort-cost','區分概念 merge 與 CPython schedule','balanced plan 解釋每層線性乘對數層數；本文另用 Powersort 層級計費與有界 run extension 連到 CPython 最壞界。',[31,32,33],'Why does the balanced merge model yield n log n work?','A merge advances through its a+b items once; one level totals O(n), and O(log n) doubling levels give O(n log n).'),
 dec('space','分開 output、ordered 與 sorting workspace','fresh result pairs 占 O(k)；ordered 與 workspace 占 O(n) auxiliary，改用 list.sort 只移除外層副本。',[34,35],'Why does in-place sorting not establish constant auxiliary space?','Removing the separate outer list leaves Python\'s sorting workspace, which can still grow with n.'),
 dec('alternative','repeated selection 用重新搜尋換順序','used markers 選剩餘最小 start 保留 merge 正確性，但每輪重掃造成平方工作且仍留 n 個 markers。',[36,37],'Derive the repeated-selection work.','Checking n markers on each of n selections gives n squared checks; scanning only remaining candidates still sums to n(n+1)/2.'),
 dec('sorted-input','可靠 sorted-input contract 才移除 ordering','去除 ordered 與 sort workspace，沿用同一 merge 與 append aggregate：O(n) time、O(1) auxiliary，另外保留 O(k) output。',[38,43],'What permits the sorted-input adaptation and what storage remains?','A reliable nondecreasing-start guarantee permits skipping ordering; the same scan takes O(n) time with O(1) auxiliary state excluding its O(k) result.'),
 dec('cost-summary','面試成本回答保留模型與空間邊界','用已推導的 CPython sort、scan/append 與 output-excluded auxiliary 成本作簡短回答，不把它當新證明。',[42]),
]
# Carefully selected productive contexts; phrases are copied from their primary paragraphs.
active_specs=[
(2,'coverage','touching endpoints','Closed intervals count touching endpoints as overlap.','Explain what touching endpoints share.','They share the endpoint position, so their union is one closed interval.',[1]),
(5,'max-end','whichever right endpoint reaches farther','For ordered starts with start <= right, keep the earlier left endpoint and whichever right endpoint reaches farther.','State both the overlap condition and endpoint update.','With left <= start and start <= right, the union is [left, max(right,end)].',[4]),
(6,'gap','bridge that gap','When starts are nondecreasing and start > right, no later interval can bridge that gap.','Why can the previous interval be finalized?','Every later start is at least start, which is already greater than right.',[4,8]),
(8,'order','one way','Sorting is one way to obtain the nondecreasing starts needed by this merge scan.','Does this argument require every correct algorithm to sort?','No; it requires nondecreasing starts for this scan, and a reliable sorted-input contract can supply them.',[38]),
(9,'state','connected group','A pair in merged represents the coverage of one connected group of processed intervals.','Does the last answer pair necessarily represent the previous original pair?','No; it represents an entire connected group, including its farthest right endpoint.',[5,26]),
(11,'ownership','fresh two-item list','This implementation creates a fresh two-item list for an answer interval before later endpoint updates.','Which mutation does the fresh list isolate?','Later end-slot writes modify the answer pair rather than the original input pair.',[]),
(18,'trace','no final flush','No final flush is needed because the last interval is already stored in merged.','Where is the last interval when input ends?','It is already in merged, which the loop returns.',[]),
(19,'short-circuit','short-circuit evaluation','Short-circuit evaluation prevents the first iteration from reading merged[-1][1] on an empty list.','Which operand must be evaluated first?','not merged is evaluated first; if true, or stops before the endpoint lookup.',[]),
(21,'invariant','immediately after each iteration','Immediately after each iteration, merged contains the exact union of the processed intervals.','What additional invariant properties and checkpoint apply?','At that post-iteration checkpoint, the pairs are start-ordered and non-overlapping, and all but the last are final against unprocessed intervals.',[6,23,24]),
(26,'max-end','largest reached endpoint','The next gap test needs the largest reached endpoint of the whole group.','Use the containment counterexample to explain the false gap.','For [[1,10],[2,3],[4,5]], comparing 4 with the previous original end 3 is wrong; the group still reaches 10.',[5,9]),
(30,'append-cost','amortized cost','Amortized cost describes the O(k) total work of k appends here, even though one append can cost more than constant time.','Give the capacity argument and its assumptions.','With fixed r<1, copied references total at most C/(1-r); proportional capacity gives C=O(k), and k slot writes preserve O(k).',[28]),
(31,'sort-cost','conceptual balanced merge plan','A conceptual balanced merge plan has O(n) work per level across O(log n) levels.','Explain both factors without claiming this is the exact CPython schedule.','A merge advances through a+b items once; each item belongs to one merge per level, and repeated doubling reaches n after about log2(n) levels.',[28]),
(34,'space','auxiliary space','This implementation uses O(n) auxiliary space excluding its O(k) output.','Identify the retained and temporary allocations.','ordered retains n references; sort keys and temporary reference storage can scale with n; the result contains k fresh two-slot pairs.',[11,28,30]),
(35,'space','sorting workspace','In-place sorting removes the separate sorted outer list but does not remove sorting workspace.','What follows from allowing input mutation?','The caller\'s list may be rearranged and the outer copy omitted; constant auxiliary space does not follow.',[34]),
(37,'alternative','grows quadratically','Repeated selection grows quadratically because it repeatedly searches for the next smallest start.','Derive work and identify storage.','n selections checking n markers yield n squared checks; there are n used markers and k output pairs.',[28,30,36]),
(38,'sorted-input','nondecreasing start order','A reliable nondecreasing start order lets this scan skip ordering and use O(1) auxiliary state excluding output.','Derive the time and state after ordering is removed.','n visits plus aggregate O(n) append work give O(n) time; no ordered list or sort workspace remains, while the O(k) result is retained.',[28,29,30,34]),
]
M['active_items']=[]
for num,(i,d,term,sentence,cue,oracle,deps) in enumerate(active_specs,1):
 assert term in P[i]['english_source']
 M['active_items'].append({'id':f'intervals-active-{num:02}','paragraph_index':i,'decision_id':d,'term':term,'source_quote':term,'english_sentence':sentence,'active_cue':cue,'oracle':oracle,'supporting_sources':[src(x) for x in deps]})
for i,(note,premise,checkpoint,deps,cue,d) in enumerate(rows):
 a={'paragraph_index':i,'kind':'PASSIVE_AND_ACTIVE' if any(x['paragraph_index']==i for x in M['active_items']) else 'PASSIVE','decision_ids':[d],'english_source':P[i]['english_source'],'zh_note':note,'reading_context':{'premises':[context_stmt(premise,[i]+deps)],'checkpoint':context_stmt(checkpoint,[i]+deps) if checkpoint else None},'speed_reading':projection(i)}
 M['paragraph_annotations'].append(a)
# First completed authored edition is preserved before final semantic review.
(OUT/'first-draft-manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2)+'\n')
(OUT/'manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2)+'\n')
records=[]
for p in sorted(IN.rglob('*')):
 if p.is_file():records.append({'path':str(p.relative_to(IN)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'scope':'supplied annotation input only'})
record={'schema':1,'input_root':str(IN),'read_files':records,'actual_input_reads':'Approved bilingual bodies, exact paragraph projection, template, field-shape, metadata, consumer request, and frozen relevant contracts; no source docs, author reviews, other outputs, expected answers or Readers accessed. Some broad instruction concatenations were truncated; targeted re-reads recovered the relevant owner/claim/annotation contracts.','pronunciation_external_reads':'NOT_RUN','independent_reader':'NOT_RUN','learner_evidence':'NOT_OBSERVED'}
if os.environ.get('CODEX_THREAD_ID'):record['CODEX_THREAD_ID']=os.environ['CODEX_THREAD_ID']
(OUT/'read-records.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
(OUT/'output.json').write_text(json.dumps({'annotation_content_created':True,'publication_performed':False,'source_body_changed':False},indent=2)+'\n')
print(json.dumps({'paragraphs':len(M['paragraph_annotations']),'decisions':len(M['decisions']),'active_items':len(M['active_items']),'first_draft_preserved':True}))
