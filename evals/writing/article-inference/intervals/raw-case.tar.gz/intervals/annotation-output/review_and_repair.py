from pathlib import Path
import json,hashlib
O=Path(__file__).parent
m=json.loads((O/'manifest.json').read_text())
d=next(d for d in m['decisions'] if d['id']=='state')
d['active_cue']='What does one pair in merged represent?'
d['oracle']='It represents all coverage in one connected group of processed intervals, not necessarily one original input pair.'
(O/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
r=json.loads((O/'read-records.json').read_text())
r['instruction_read_scope']={'AGENTS.md':'Complete relevant root entry; initial concatenation truncated, tail 220–247 subsequently read.','writing-contract.md':'Initial concatenation plus targeted 1–210; its owner/assembly boundaries applied; no body-writing route executed.','speed-reading/SKILL.md':'complete','alg-four/SKILL.md':'complete','alg-four/references/lesson-contract.md':'complete','leetcode-mental/references/article-construction.md':'complete','leetcode-mental/references/article-content-profile.md':'complete','medium-writing/SKILL.md':'lines 1–175; semantic writing and CLI continuation sections were not selected for this annotation-only task.'}
r['draft_identities']={name:hashlib.sha256((O/name).read_bytes()).hexdigest() for name in ['first-draft-manifest.json','manifest.json']}
r['note']='Input inventories and hashes identify files; they do not prove semantic completeness or filesystem isolation. Review is annotation-Owner self-review, not a fresh Reader.'
(O/'read-records.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(r['draft_identities'],indent=2))
