## CLI fixture 1

Stage order control.

## CLI fixture 2

Stage order control.

## CLI fixture 3

Stage order control.

## CLI fixture 4

Stage order control.

## CLI fixture 5

Stage order control.
