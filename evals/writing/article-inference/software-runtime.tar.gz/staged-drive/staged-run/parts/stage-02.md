## CLI fixture 2

Stage order control.
