## CLI fixture 3

Stage order control.
