## CLI fixture 1

Stage order control.
