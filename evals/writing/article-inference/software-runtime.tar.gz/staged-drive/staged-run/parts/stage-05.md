## CLI fixture 5

Stage order control.
