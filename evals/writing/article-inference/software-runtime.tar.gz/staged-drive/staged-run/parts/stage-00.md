## CLI fixture 0

Stage order control.
