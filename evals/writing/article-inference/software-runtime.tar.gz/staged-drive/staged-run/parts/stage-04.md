## CLI fixture 4

Stage order control.
