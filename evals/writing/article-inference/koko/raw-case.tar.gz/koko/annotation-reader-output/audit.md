# Koko 完整註解獨立 Reader 稽核

判定：**NEEDS_REVISION**。35/35 已審，兩頁註解內容一致；33 段有界通過，2 段需修正可見措辭。未作學習效果或語意分數宣稱。

CODEX_THREAD_ID: `01a15ce9-12db-7083-9ee6-72984c330110`

實際輸入讀取路徑：

- `/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko/annotation-reader-input/task.json`
- `/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko/annotation-reader-input/article.en.md`
- `/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko/annotation-reader-input/article.zh-TW.md`
- `/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko/annotation-reader-input/page.en.html`
- `/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko/annotation-reader-input/page.zh-TW.html`

Locally parsed complete HTML without output truncation; 35 indexed body paragraphs and 35 complete annotations per page; all annotation fields identical between pages. Read full English, zh_note, premises/checkpoints, cues, Active sentences/cues/oracles and each linked body paragraph. HTML text quotes normalize whitespace only; /, // and [] reading markers retained.

範圍限制：

- No semantic score, learner benefit, mastery, reading speed or pronunciation verdict.
- Citation provenance was compared to supplied body only; external linked documents were not opened.
- Findings concern visible wording, not a demonstrated Python algorithm defect.
- PASS_BOUNDED means no further unsupported technical assertion found within this supplied packet; not a universal correctness or learning claim.

## 發現

### KOKO-ANNOTATION-01：第 11 段（index 10）

可見原文：> 答案是正整數 speed，因此至少為 1，並在 M 前已有可行值。

「M 前」通常是嚴格小於 M；正文只證明到 M 為止（含 M）存在可行值，且明給答案等於 M 的合法邊界。旁邊 inclusive/Active 正確並不能消除這個 premise 的端點歧義。

授權推論：minimum <= M，M 可行。
不合法加強：存在可行 k < M。

建議：答案是正整數 speed，因此至少為 1；M 本身可行，所以在不大於 M 的速度中已有可行值。

正文精確引文：

- `alg-p-10` EN: No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M].
  ZH: 正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。
- `alg-p-21` EN: If h = n, each pile must fit into its one hour, so the largest pile forces the answer to be M.
  ZH: 若 h = n，每堆都必須在分配給自己的一小時內吃完，因此最大那堆迫使答案為 M。

### KOKO-ANNOTATION-02：第 28 段（index 27）

可見原文：> 只有改成一小時內可跨堆用滿容量，h * k >= S 才既必要又充分，答案為 ceiling(S / h)。

正文提出一個足以確保容量可達的改題條件；「只有…才」卻把它變成總量判準成立的必要條件，未限定是在兩種一般題目規則之間比較。對正文的原題單堆 [2], h=1，沒有可換的第二堆；按正文 ceiling 定義，原題可行恰為 k>=2，也恰為 h*k>=S，完全不用改規則。

授權推論：在允許同小時跨堆用滿容量的改題中，h*k>=S 對所有合法輸入是必要且充分；原題不能一般套用，正文 [4,4],h=3 是失敗例。
不合法加強：只要某個實例的 h*k>=S 是必要且充分，就一定已改成允許跨堆規則。

建議：在這個改成一小時內可跨堆用滿容量的題目中，h * k >= S 既必要又充分，答案為 ceiling(S / h)；原題不能一般套用這個公式。

正文精確引文：

- `alg-p-27` EN: Suppose Koko could switch piles within an hour and use the entire capacity k across them.
  ZH: 假設 Koko 能在一小時內切換香蕉堆，把完整容量 k 用在多堆之間。
- `alg-p-27` EN: Therefore h * k >= S is sufficient as well as necessary, and the minimum integer speed is (S + h - 1) // h.
  ZH: 因此，h * k >= S 既是必要條件，也是充分條件，最小整數速度便是 (S + h - 1) // h。
- `alg-p-20` EN: For piles = [2], h = 1, the interval is [1, 2] and mid = 1 fails.
  ZH: 對 piles = [2]、h = 1，interval 是 [1, 2]，而 mid = 1 失敗。
- `alg-p-4` EN: If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer at least as large as that quotient.
  ZH: 若還有剩餘香蕉，就需要額外一個完整小時。這個數量是 p / k 的 ceiling，也就是不小於該商的最小整數。

## 逐段完整稽核

### 第 1 段 / alg-p-0 — PASS_BOUNDED

精確 hours test 本身不足以授權刪除整段；context 明列原題判準及提高 speed 不增加 T(k)，連結正文給出每堆到總和的原因。

相鄰不合法推論：不把成功的 probe 當最小值；不把未排序的 piles 當搜尋順序。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 為何可跳過未逐一測試的速度？
- `alg-four-zh` [PASS_BOUNDED]: 先精確計算某個 speed 的 hours，再用 monotonicity 排除較慢的失敗候選；成功後仍要找更小答案。binary search 的對象是 speeds，所以不用排序 piles。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: For Koko, /finding the slowest acceptable eating speed starts with an easier question: how many hours would a particular speed require? //Once that calculation is exact, a failed speed rules out every slower speed. A successful speed lets us keep searching below it. This is [binary search] /over possible answers, and it does not require sorting the banana piles.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：原題求最小正整數 speed；逐堆小時數的總和才是可行性判準。 第 2 段 · 第 5 段 · 第 7 段適用前提：提高 speed 不會增加 T(k)，因此失敗速度以下也失敗；成功只給上界。 第 9 段 · 第 10 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why does one failed speed exclude slower speeds?

正文支撐及連結論證（完整精確段落）：

- `alg-p-0` EN: For Koko, finding the slowest acceptable eating speed starts with an easier question: how many hours would a particular speed require? Once that calculation is exact, a failed speed rules out every slower speed. A successful speed lets us keep searching below it. This is binary search over possible answers, and it does not require sorting the banana piles.
  ZH: 替 Koko 找出可接受的最慢進食速度，可以先問一個較容易的問題：某個速度需要多少小時？只要這個計算準確，一個失敗的速度就能排除所有更慢的速度。一個成功的速度則讓我們繼續往下找。這是對可能答案進行 binary search，不需要先把香蕉堆排序。
- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-4` EN: For a pile of size p at speed k, count complete groups of k bananas. If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer at least as large as that quotient. For p = 11 and k = 4, the groups are 4, 4, 3, so the pile takes three hours.
  ZH: 對大小為 p 的一堆香蕉，以速度 k 進食，先數出完整的 k 根一組有幾組。若還有剩餘香蕉，就需要額外一個完整小時。這個數量是 p / k 的 ceiling，也就是不小於該商的最小整數。例如 p = 11、k = 4，會分成 4, 4, 3，因此需要三小時。
- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。
- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-9` EN: This property permits discarding whole ranges. If speed 6 fails, every speed from 1 through 6 fails. If speed 6 works, the minimum successful speed is at most 6, but might be smaller. Returning the first successful probe would ignore that distinction.
  ZH: 這個性質允許我們一次排除整段範圍。如果速度 6 失敗，從 1 到 6 的每個速度都失敗。如果速度 6 成功，最小成功速度至多是 6，但也可能更小。一遇到成功的 probe 就回傳，會忽略這個差別。

### 第 2 段 / alg-p-1 — PASS_BOUNDED

zh_note、英文全文與 premise 保留非空正數 piles、正整數 speed、至多 h，以及同一小時不能換堆。

相鄰不合法推論：不能把提早完成剩餘容量轉給另一堆；不是要求恰好用 h 小時。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 何時必須逐堆而不能共用容量？
- `alg-four-zh` [PASS_BOUNDED]: 每小時只能吃一堆；提早完成也不能把剩餘容量給另一堆。要求的是至多 h 小時內完成的最小正整數 speed。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, /measured in bananas per hour. //During each hour she eats from one pile. Finishing that pile early does not let her start another pile /during the same hour. Return the smallest speed that finishes all piles in at most h hours.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：piles 非空且每堆大小為正；同一小時不能換堆，目標是最小正整數 k。 第 2 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Which hourly restriction changes the required speed?

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。

### 第 3 段 / alg-p-2 — PASS_BOUNDED

每堆至少一小時提供必要條件；取最大堆 M 且每堆一小時提供 h>=n 下的可行構造。數值限制、只讀與排除範圍保留。

相鄰不合法推論：h<n 不得沿用可行 high；h>=n 的充分性有 M 構造而非單靠下界。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 何時必須逐堆而不能共用容量？
- `alg-four-zh` [PASS_BOUNDED]: n 是堆數，每堆至少一小時；h >= n 才保證某個 speed 可行。此解法只讀取 piles，空輸入與 h < n 不適用。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: The constraints are 1 <= n <= 10^4, n <= h <= 10^9, and 1 <= piles[i] <= 10^9, /where n is the number of piles. Every pile needs at least one hour, //so h >= n matters: the problem guarantees that a sufficiently large speed can work. The solution below only reads the input list; it neither sorts nor changes its elements. //Empty lists and h < n are outside this contract. Problem statement and constraints.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：本題 n、h、pile sizes 皆受列出的限制；正數堆各佔至少一小時。 第 2 段 · 第 3 段適用前提：取 M 為最大堆時，每堆一小時，所以 n <= h 給出可行上界。 第 11 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why does h >= n guarantee a feasible speed?

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-2` EN: The constraints are 1 <= n <= 10^4, n <= h <= 10^9, and 1 <= piles[i] <= 10^9, where n is the number of piles. Every pile needs at least one hour, so h >= n matters: the problem guarantees that a sufficiently large speed can work. The solution below only reads the input list; it neither sorts nor changes its elements. Empty lists and h < n are outside this contract. Problem statement and constraints.
  ZH: 限制是 1 <= n <= 10^4、n <= h <= 10^9，以及 1 <= piles[i] <= 10^9，其中 n 是香蕉堆數。每堆至少需要一小時，因此 h >= n 很重要：題目保證速度夠大就一定能完成。下面的解法只讀取輸入 list，不排序，也不改動其中的元素。空 list 和 h < n 不在這份 contract 內。題目敘述與限制。
- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。

### 第 4 段 / alg-p-3 — PASS_BOUNDED

固定 [4,4], h=3；四與兩小時及答案 4 均維持，pooling 的錯誤機制連到禁止換堆及逐堆 ceiling。

相鄰不合法推論：「k=4 才能完成」在最小速度語境是門檻，不授權聲稱 k>4 失敗。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 何時必須逐堆而不能共用容量？
- `alg-four-zh` [PASS_BOUNDED]: [4, 4]、h = 3 時，k = 3 要四小時，k = 4 才能完成。對總香蕉數一次取 ceiling 會錯把不同堆的容量合併。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: For a small example, take piles = [4, 4] and h = 3. Speed 3 takes two hours per pile, four hours total. Speed 4 takes one hour per pile, two hours total. The answer is 4, //even though dividing eight bananas by three hours and rounding up suggests 3. That shortcut spends spare capacity /from one pile on another, which the hourly rule forbids.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：原題不允許在同一小時換堆；例子的 deadline 為三小時。 第 2 段 · 第 4 段適用前提：每堆 ceiling 必須分別計算後相加。 第 5 段 · 第 7 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why does pooling suggest the wrong answer here?

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-3` EN: For a small example, take piles = [4, 4] and h = 3. Speed 3 takes two hours per pile, four hours total. Speed 4 takes one hour per pile, two hours total. The answer is 4, even though dividing eight bananas by three hours and rounding up suggests 3. That shortcut spends spare capacity from one pile on another, which the hourly rule forbids.
  ZH: 看一個小例子：piles = [4, 4]、h = 3。速度 3 讓每堆各花兩小時，總共四小時。速度 4 讓每堆各花一小時，總共兩小時。答案是 4，儘管把八根香蕉除以三小時再向上取整，會得到 3。這個捷徑把一堆剩下的處理容量挪給另一堆，違反每小時的規則。
- `alg-p-4` EN: For a pile of size p at speed k, count complete groups of k bananas. If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer at least as large as that quotient. For p = 11 and k = 4, the groups are 4, 4, 3, so the pile takes three hours.
  ZH: 對大小為 p 的一堆香蕉，以速度 k 進食，先數出完整的 k 根一組有幾組。若還有剩餘香蕉，就需要額外一個完整小時。這個數量是 p / k 的 ceiling，也就是不小於該商的最小整數。例如 p = 11、k = 4，會分成 4, 4, 3，因此需要三小時。
- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。

### 第 5 段 / alg-p-4 — PASS_BOUNDED

正 p,k 的完整群組加非零 remainder 的整小時，支撐 ceiling；Active sentence/cue/oracle 保留原題禁止 pooling。

相鄰不合法推論：remainder=0 不另加小時；不是把所有香蕉合併後一次 ceiling。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive + Active · 如何精確測試一個 speed？
- `alg-four-zh` [PASS_BOUNDED]: 一堆的完整 k 根群組各佔一小時，remainder 也要一整小時，所以需要 ceiling(p / k)；11 根、k = 4 得到 4、4、3 三組。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: For a pile of size p /at speed k, count complete groups of k bananas. //If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer [at least as large as] that quotient. //For p = 11 and k = 4, the groups are 4, 4, 3, so the pile takes three hours.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：p 與 k 都為正，且一小時只處理一堆，剩餘香蕉不能借用別堆時段。 第 2 段 · 第 5 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why does a remainder require another whole hour?
- `alg-active-word` [PASS_BOUNDED]: ceilingAn unfinished remainder needs another whole hour, so each pile uses the ceiling of its size divided by the speed.
- `alg-supporting-sources` [PASS_BOUNDED]: 推導前提：第 2 段 · 第 5 段 · 第 6 段
- `alg-four-recall` [PASS_BOUNDED]: Active · 自行表達後核對Explain why one pile needs upward rounding.Oracle · 嘗試後展開A correct explanation keeps p and k positive, counts full groups, and assigns a whole extra hour to a nonzero remainder; it does not pool spare capacity across piles.

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-4` EN: For a pile of size p at speed k, count complete groups of k bananas. If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer at least as large as that quotient. For p = 11 and k = 4, the groups are 4, 4, 3, so the pile takes three hours.
  ZH: 對大小為 p 的一堆香蕉，以速度 k 進食，先數出完整的 k 根一組有幾組。若還有剩餘香蕉，就需要額外一個完整小時。這個數量是 p / k 的 ceiling，也就是不小於該商的最小整數。例如 p = 11、k = 4，會分成 4, 4, 3，因此需要三小時。
- `alg-p-5` EN: Python's integer // operator rounds a quotient downward. For positive integers, (p + k - 1) // k instead gives the required upward rounding. To see why, write p = q * k + r, where q is the number of full groups and the remainder r satisfies 0 <= r < k. When r = 0, adding k - 1 still leaves the quotient at q. When r > 0, r + k - 1 lies between k and 2 * k - 2, so the quotient becomes q + 1. Both cases count exactly the hours needed. Python arithmetic semantics.
  ZH: Python 的整數 // 運算會把商向下取整。對正整數而言，(p + k - 1) // k 則能得到需要的向上取整結果。原因可以從 p = q * k + r 看出，其中 q 是完整組數，remainder r 滿足 0 <= r < k。當 r = 0，加上 k - 1 後，整數商仍是 q。當 r > 0，r + k - 1 落在 k 到 2 * k - 2 之間，整數商便成為 q + 1。兩種情況都恰好算出需要的小時數。Python 算術語意。

### 第 6 段 / alg-p-5 — PASS_BOUNDED

正整數、// 向下取整及 0<=r<k 都明列，兩分支提供 q 與 q+1 的完整算術解釋。

相鄰不合法推論：不能延用到任意負數或零 divisor；r=0 不能多加一小時。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何精確測試一個 speed？
- `alg-four-zh` [PASS_BOUNDED]: 正整數可用 (p + k - 1) // k 算 ceiling。把 p 拆成 q * k + r：r = 0 商仍為 q，r > 0 商增加為 q + 1。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Python's integer // operator rounds a quotient downward. //For positive integers, (p + k - 1) // k instead gives the required upward rounding. To see why, write p = q * k + r, /where q is the number of full groups and the remainder r satisfies 0 <= r < k. //When r = 0, adding k - 1 still leaves the quotient at q. //When r > 0, r + k - 1 lies between k and 2 * k - 2, so the quotient becomes q + 1. Both cases count exactly the hours needed. Python arithmetic semantics.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：p、k 為正整數；// 向下取整；0 <= r < k。這些條件讓兩個 r 分支覆蓋所有情況。 第 6 段適用前提：單堆需要完整群組數加上非零 remainder 所佔的一小時。 第 5 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：How do the two remainder cases produce the ceiling?

正文支撐及連結論證（完整精確段落）：

- `alg-p-5` EN: Python's integer // operator rounds a quotient downward. For positive integers, (p + k - 1) // k instead gives the required upward rounding. To see why, write p = q * k + r, where q is the number of full groups and the remainder r satisfies 0 <= r < k. When r = 0, adding k - 1 still leaves the quotient at q. When r > 0, r + k - 1 lies between k and 2 * k - 2, so the quotient becomes q + 1. Both cases count exactly the hours needed. Python arithmetic semantics.
  ZH: Python 的整數 // 運算會把商向下取整。對正整數而言，(p + k - 1) // k 則能得到需要的向上取整結果。原因可以從 p = q * k + r 看出，其中 q 是完整組數，remainder r 滿足 0 <= r < k。當 r = 0，加上 k - 1 後，整數商仍是 q。當 r > 0，r + k - 1 落在 k 到 2 * k - 2 之間，整數商便成為 q + 1。兩種情況都恰好算出需要的小時數。Python 算術語意。
- `alg-p-4` EN: For a pile of size p at speed k, count complete groups of k bananas. If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer at least as large as that quotient. For p = 11 and k = 4, the groups are 4, 4, 3, so the pile takes three hours.
  ZH: 對大小為 p 的一堆香蕉，以速度 k 進食，先數出完整的 k 根一組有幾組。若還有剩餘香蕉，就需要額外一個完整小時。這個數量是 p / k 的 ceiling，也就是不小於該商的最小整數。例如 p = 11、k = 4，會分成 4, 4, 3，因此需要三小時。

### 第 7 段 / alg-p-6 — PASS_BOUNDED

zh_note/context/Active 都給出合法 schedule 下界與逐堆完成的可達構造，必要且充分的兩方向都在正文。

相鄰不合法推論：必要性不等同充分性；原題的逐堆時段限制不可省略。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive + Active · 如何精確測試一個 speed？
- `alg-four-zh` [PASS_BOUNDED]: 每堆各需自己的 ceiling hours，所以 T(k) 是合法 schedule 的下界；逐堆吃完可恰好達到它，因此 T(k) <= h 既必要也充分，順序不影響總和。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Add that count separately /for every pile. Call the total T(k). Each pile requires its own hours, //so any valid schedule needs at least T(k) hours. //Eating one pile to completion and then the next achieves exactly that total. //Thus T(k) <= h is both [necessary and sufficient] for speed k to work. Pile order cannot change this sum.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：每小時只能處理一堆，單堆小時數是 ceiling(p / k)。 第 2 段 · 第 5 段適用前提：任一合法 schedule 至少需 T(k)，而逐堆完成的 schedule 恰用 T(k)。 第 7 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：What establishes both directions of the feasibility test?
- `alg-active-word` [PASS_BOUNDED]: necessary and sufficientFor the original hourly rule, T(k) <= h is necessary and sufficient for speed k to work.
- `alg-supporting-sources` [PASS_BOUNDED]: 推導前提：第 2 段 · 第 5 段 · 第 7 段
- `alg-four-recall` [PASS_BOUNDED]: Active · 自行表達後核對Explain both directions of the hours test.Oracle · 嘗試後展開Each pile needs its own ceiling hours, so every schedule requires at least their sum; finishing one pile and then the next achieves that sum. Keep the one-pile-per-hour restriction.

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-4` EN: For a pile of size p at speed k, count complete groups of k bananas. If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer at least as large as that quotient. For p = 11 and k = 4, the groups are 4, 4, 3, so the pile takes three hours.
  ZH: 對大小為 p 的一堆香蕉，以速度 k 進食，先數出完整的 k 根一組有幾組。若還有剩餘香蕉，就需要額外一個完整小時。這個數量是 p / k 的 ceiling，也就是不小於該商的最小整數。例如 p = 11、k = 4，會分成 4, 4, 3，因此需要三小時。
- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。

### 第 8 段 / alg-p-7 — PASS_BOUNDED

固定 k=4 與輸入，完整前綴總和 1,3,5,8；checkpoint 限定每堆完成後，Active oracle 指出 processed piles sum。

相鄰不合法推論：中途 hours 是已處理堆的總和，不是全部 piles 的總和，也未存 contribution list。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive + Active · 實作各階段的 scalar 表示什麼？
- `alg-four-zh` [PASS_BOUNDED]: 固定 k = 4 時，hours 依序累加為 1、3、5、8。只保留 running total，不建立貢獻值 list，也不修改 piles。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: At k = 4 on [3, 6, 7, 11], /an accumulator named hours starts at zero. The first pile contributes (3 + 3) // 4 = 1, /changing hours to 1. The next contributes 2, changing it to 3; the next contributes 2, changing it to 5; the last contributes 3, changing it to 8. //The calculation stores a [running total], without allocating a list of all four contributions or changing the piles.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：此 trace 使用 [3, 6, 7, 11]、k = 4；每堆貢獻由 ceiling 算出。 第 6 段 · 第 8 段判讀時點：hours 從零開始；每處理完一堆才把該貢獻加到累計值，全部完成後為 8。 第 8 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：What does hours contain after each pile?
- `alg-active-word` [PASS_BOUNDED]: running totalThe calculation keeps a running total of pile hours without storing a list of contributions.
- `alg-supporting-sources` [PASS_BOUNDED]: 推導前提：第 6 段 · 第 8 段 · 第 18 段
- `alg-four-recall` [PASS_BOUNDED]: Active · 自行表達後核對Describe what hours stores during the scan.Oracle · 嘗試後展開hours begins at zero for the proposed speed, adds one per-pile ceiling at a time, and equals the sum for processed piles; the supplied piles are unchanged.

正文支撐及連結論證（完整精確段落）：

- `alg-p-5` EN: Python's integer // operator rounds a quotient downward. For positive integers, (p + k - 1) // k instead gives the required upward rounding. To see why, write p = q * k + r, where q is the number of full groups and the remainder r satisfies 0 <= r < k. When r = 0, adding k - 1 still leaves the quotient at q. When r > 0, r + k - 1 lies between k and 2 * k - 2, so the quotient becomes q + 1. Both cases count exactly the hours needed. Python arithmetic semantics.
  ZH: Python 的整數 // 運算會把商向下取整。對正整數而言，(p + k - 1) // k 則能得到需要的向上取整結果。原因可以從 p = q * k + r 看出，其中 q 是完整組數，remainder r 滿足 0 <= r < k。當 r = 0，加上 k - 1 後，整數商仍是 q。當 r > 0，r + k - 1 落在 k 到 2 * k - 2 之間，整數商便成為 q + 1。兩種情況都恰好算出需要的小時數。Python 算術語意。
- `alg-p-7` EN: At k = 4 on [3, 6, 7, 11], an accumulator named hours starts at zero. The first pile contributes (3 + 3) // 4 = 1, changing hours to 1. The next contributes 2, changing it to 3; the next contributes 2, changing it to 5; the last contributes 3, changing it to 8. The calculation stores a running total, without allocating a list of all four contributions or changing the piles.
  ZH: 以 k = 4 處理 [3, 6, 7, 11] 時，名為 hours 的 accumulator 從零開始。第一堆貢獻 (3 + 3) // 4 = 1，讓 hours 變成 1。下一堆貢獻 2，讓它變成 3；再下一堆貢獻 2，讓它變成 5；最後一堆貢獻 3，讓它變成 8。計算只保留累計總和，不會為這四個貢獻值另建 list，也不會改動香蕉堆。
- `alg-p-17` EN: hours = 0 belongs inside the while loop because a new speed needs a new total. hours += ... adds to this scalar, not to the input list. The two assignments after the scan are the same two interval changes in the trace. All candidate speeds stay positive, so the division never has a zero divisor. There is no recursion, sorting, copied input, or saved history of probes.
  ZH: hours = 0 必須放在 while loop 裡，因為每個新速度都需要新的總和。hours += ... 加到這個 scalar，不是加到輸入 list。scan 後的兩個 assignment，就是前面 trace 中的兩種 interval 更新。所有候選速度都保持正值，所以不會出現零 divisor。這裡沒有 recursion、sorting、輸入副本，也不儲存歷次 probe。

### 第 9 段 / alg-p-8 — PASS_BOUNDED

每堆不增加再求和給出非增加方向，feasibility 的失敗前綴允許為空；oracle 用正文 4 與 5 同為八小時排除嚴格下降。

相鄰不合法推論：不增加不等於每次加速都省一小時，也不要求每次 k 增加都切換布林結果。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive + Active · 為何可跳過未逐一測試的速度？
- `alg-four-zh` [PASS_BOUNDED]: 提高 k 後，原本足夠的時數仍足夠處理每堆；相加後 T(k) 不增加。因此 feasible speeds 接在 failing speeds 之後，失敗前綴可能為空。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Increasing k cannot increase the hours /for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. //Adding the pile counts preserves that direction. //Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: [an initial run of] failing speeds, possibly empty, followed by successful speeds.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：T(k) 是各堆所需 hours 的總和，以 T(k) <= h 判定可行。 第 7 段適用前提：每堆都不因提高速度而需要更多小時，求和保留此方向。 第 9 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Does non-increasing mean every speed increase saves an hour?
- `alg-active-word` [PASS_BOUNDED]: monotoneThe feasibility test is monotone because increasing the speed cannot increase any pile’s required hours or their sum.
- `alg-supporting-sources` [PASS_BOUNDED]: 推導前提：第 7 段 · 第 9 段 · 第 10 段 · 第 15 段
- `alg-four-recall` [PASS_BOUNDED]: Active · 自行表達後核對Explain why a failed speed rules out slower speeds.Oracle · 嘗試後展開T(k) is a sum of non-increasing pile-hour counts. If T(k) > h, a slower speed cannot have a smaller total. Do not claim strict decrease: speeds 4 and 5 in the worked example both need eight hours.

正文支撐及連結論證（完整精確段落）：

- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。
- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-9` EN: This property permits discarding whole ranges. If speed 6 fails, every speed from 1 through 6 fails. If speed 6 works, the minimum successful speed is at most 6, but might be smaller. Returning the first successful probe would ignore that distinction.
  ZH: 這個性質允許我們一次排除整段範圍。如果速度 6 失敗，從 1 到 6 的每個速度都失敗。如果速度 6 成功，最小成功速度至多是 6，但也可能更小。一遇到成功的 probe 就回傳，會忽略這個差別。
- `alg-p-14` EN: The first probe succeeds at 6, yet the final answer is 4. The failed probe at 3 removes speeds 1, 2, 3 together. Speeds 4 and 5 both take eight hours, so an exact match to the deadline does not justify returning immediately either. The search needs the first successful speed, including when several speeds give the same total.
  ZH: 第一次 probe 在 6 就成功，但最後答案是 4。速度 3 的失敗，一次排除了 1, 2, 3。速度 4 和 5 都需要八小時，因此總時數恰好等於 deadline，也不能成為立即回傳的理由。即使數個速度給出相同總時數，搜尋仍須找出第一個成功速度。

### 第 10 段 / alg-p-9 — PASS_BOUNDED

context 固定同一 piles,h；失敗排除 <=6，成功只證明 minimum<=6，英文與 zh_note 都保留 may be smaller。

相鄰不合法推論：可行 probe 不是最小證明；不能由 6 成功排除更小 speed。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 為何可跳過未逐一測試的速度？
- `alg-four-zh` [PASS_BOUNDED]: 由 monotonicity，6 失敗可排除 1 到 6；6 成功只證明最小成功速度至多為 6，不能直接回傳第一次成功的 probe。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: This property permits discarding whole ranges. //If speed 6 fails, every speed from 1 through 6 fails. //If speed 6 works, the minimum successful speed is at most 6, //but might be smaller. Returning the first successful probe would ignore that distinction.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：同一個 piles、h 下，T(k) 隨 k 增加而不增加。 第 9 段適用前提：目標是最小可行速度；成功的 6 以下仍可能存在成功速度。 第 2 段 · 第 10 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：What does success prove, and what remains unknown?

正文支撐及連結論證（完整精確段落）：

- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-9` EN: This property permits discarding whole ranges. If speed 6 fails, every speed from 1 through 6 fails. If speed 6 works, the minimum successful speed is at most 6, but might be smaller. Returning the first successful probe would ignore that distinction.
  ZH: 這個性質允許我們一次排除整段範圍。如果速度 6 失敗，從 1 到 6 的每個速度都失敗。如果速度 6 成功，最小成功速度至多是 6，但也可能更小。一遇到成功的 probe 就回傳，會忽略這個差別。

### 第 11 段 / alg-p-10 — NEEDS_REVISION

inclusive interval、M 的可行構造與 Active sentence/oracle 正確；但 context 的「在 M 前」沒有保留 by M 的端點。

相鄰不合法推論：不允許從 M 可行推成存在嚴格小於 M 的可行 speed；h=n 時答案可以等於 M。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive + Active · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: M 是最大堆，k = M 讓每堆各需一小時，因 h >= n 而可行。以 [1, M] 儲存 inclusive speed interval，無須建立候選 list 或排序 piles。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Let M be the largest pile. Speed M clears every pile in one hour, /using exactly n hours, /which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, //so start with the [inclusive interval] [low, high] = [1, M]. //These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [NEEDS_REVISION]: 適用前提：每堆為正且 h >= n；speed M 足以在一小時完成任何一堆。 第 3 段 · 第 11 段適用前提：答案是正整數 speed，因此至少為 1，並在 M 前已有可行值。 第 2 段 · 第 11 段判讀時點：搜尋初始化為 [low, high] = [1, M] 時，答案在 interval 內且 high 可行。 第 11 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why is M a valid initial upper endpoint?
- `alg-active-word` [PASS_BOUNDED]: inclusive intervalThe inclusive interval [1, M] contains the minimum feasible speed because speeds are positive and speed M uses n hours, with h >= n.
- `alg-supporting-sources` [PASS_BOUNDED]: 推導前提：第 2 段 · 第 3 段 · 第 11 段
- `alg-four-recall` [PASS_BOUNDED]: Active · 自行表達後核對Justify both initial endpoints of the speed search.Oracle · 嘗試後展開The searched objects are positive integer speeds. M is the largest pile and finishes every pile in one hour; h >= n makes M feasible. Both endpoints are included.

正文支撐及連結論證（完整精確段落）：

- `alg-p-2` EN: The constraints are 1 <= n <= 10^4, n <= h <= 10^9, and 1 <= piles[i] <= 10^9, where n is the number of piles. Every pile needs at least one hour, so h >= n matters: the problem guarantees that a sufficiently large speed can work. The solution below only reads the input list; it neither sorts nor changes its elements. Empty lists and h < n are outside this contract. Problem statement and constraints.
  ZH: 限制是 1 <= n <= 10^4、n <= h <= 10^9，以及 1 <= piles[i] <= 10^9，其中 n 是香蕉堆數。每堆至少需要一小時，因此 h >= n 很重要：題目保證速度夠大就一定能完成。下面的解法只讀取輸入 list，不排序，也不改動其中的元素。空 list 和 h < n 不在這份 contract 內。題目敘述與限制。
- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。
- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。

### 第 12 段 / alg-p-11 — PASS_BOUNDED

兩條 invariant 與 iteration-start checkpoint 都明列，Active oracle 的兩分支由 linked proof 支持，終點 singleton 保證也有正文。

相鄰不合法推論：invariant 不是全體 speeds 的單調性；也不聲稱 interval 中每個 speed 都可行。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive + Active · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: iteration 開始時，invariant 同時保證最小 feasible speed 留在 [low, high] 且 high 可行；它描述當前搜尋狀態，monotonicity 則描述所有 speeds 的可行性方向。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: /At the start of every [search iteration], maintain this invariant: //The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. Here feasible means that the speed passes the hours test. //The monotone property describes the problem's answers across all speeds; the invariant describes what the current search state still guarantees.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：feasible 表示通過 T(k) <= h；inclusive interval 含兩端。 第 7 段 · 第 11 段 · 第 12 段適用前提：初始化已提供包含答案且 high 可行的狀態。 第 11 段判讀時點：每次 search iteration 開始時檢查兩項 invariant，不把單次 probe 成功當成最小值。 第 12 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Which two facts must the current interval preserve?
- `alg-active-word` [PASS_BOUNDED]: invariantAt each iteration’s start, the invariant keeps the minimum feasible speed in [low, high] and keeps high feasible.
- `alg-supporting-sources` [PASS_BOUNDED]: 推導前提：第 9 段 · 第 11 段 · 第 12 段 · 第 13 段 · 第 19 段 · 第 20 段
- `alg-four-recall` [PASS_BOUNDED]: Active · 自行表達後核對Explain how both branches preserve the invariant.Oracle · 嘗試後展開Failure excludes mid and all slower speeds, so low becomes mid + 1 while feasible high remains. Success keeps mid as feasible high and excludes only larger speeds. At one remaining candidate, the invariant identifies the minimum.

正文支撐及連結論證（完整精確段落）：

- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。
- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。
- `alg-p-11` EN: At the start of every search iteration, maintain this invariant: The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. Here feasible means that the speed passes the hours test. The monotone property describes the problem's answers across all speeds; the invariant describes what the current search state still guarantees.
  ZH: 在每次 search iteration 開始時，維持這個 invariant：The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. 意思是最小可行速度仍在包含兩端的 [low, high] 裡，而且 high 本身可行。這裡 feasible 指速度通過小時數檢查。monotone 性質描述所有速度的答案如何變化；invariant 描述目前搜尋狀態仍保證哪些事。
- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-12` EN: Choose mid = (low + high) // 2, the lower middle integer. When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
  ZH: 選擇 mid = (low + high) // 2，也就是偏下方的中間整數。當 T(mid) > h，設定 low = mid + 1：mid 和所有更小速度都已失敗。否則設定 high = mid：更大速度已無必要，但成功的 mid 仍須留作候選。當 low == high 時停止，回傳該數值。這種把有序候選範圍反覆減半的方法，就是 binary search。
- `alg-p-18` EN: Initially, the answer lies between 1 and M, and M is feasible. Suppose the invariant holds before an iteration. If mid fails, monotonicity excludes all speeds at most mid, so the answer remains in [mid + 1, high]; the unchanged high remains feasible. If mid succeeds, some feasible speed is now known at mid. The minimum therefore lies in [low, mid], and assigning high = mid keeps the upper endpoint feasible. Each branch preserves both parts of the invariant.
  ZH: 一開始，答案在 1 到 M 之間，而且 M 可行。假設某次 iteration 開始前 invariant 成立。如果 mid 失敗，monotonicity 排除所有至多為 mid 的速度，因此答案仍在 [mid + 1, high]；未變動的 high 仍然可行。如果 mid 成功，我們便知道 mid 是一個可行速度。最小值因此落在 [low, mid]，設定 high = mid 也讓 upper endpoint 保持可行。兩個 branch 都保留 invariant 的兩項保證。
- `alg-p-19` EN: When low < high, the lower middle satisfies low <= mid < high. In the failure branch the lower endpoint strictly increases; in the success branch the upper endpoint strictly decreases. The interval stays nonempty and has fewer integer candidates, so it must eventually contain one candidate. The invariant then says that this sole candidate is the minimum feasible speed. Returning low is justified even if that exact speed was not separately tested after the final update.
  ZH: 當 low < high，偏下方的中間值滿足 low <= mid < high。失敗 branch 嚴格提高 lower endpoint；成功 branch 嚴格降低 upper endpoint。interval 維持非空，整數候選卻變少，因此最後一定只剩一個候選。invariant 此時保證這個唯一候選就是最小可行速度。即使最後一次更新後沒有另外測試那個確切速度，回傳 low 仍有根據。

### 第 13 段 / alg-p-12 — PASS_BOUNDED

完整 hours test 後以 >h 作失敗分支，low=mid+1 與 high=mid 的非對稱保留、停止條件均未改。

相鄰不合法推論：成功不能 high=mid-1；失敗不能保留已否定的 mid；equality 屬成功分支。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: lower middle 失敗就設 low = mid + 1，排除 mid 及更慢者；成功則設 high = mid，保留仍可能最小的 mid。兩端相等才回傳。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Choose mid = (low + high) // 2, /the lower middle integer. //When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. //Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. //Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：monotonicity 允許排除失敗速度以下，成功速度仍可能就是最小值。 第 9 段 · 第 10 段適用前提：開始 iteration 時答案在 inclusive interval 且 high 可行。 第 12 段判讀時點：先算完整 T(mid) 再依 > h 分支更新；low == high 時由 invariant 得到答案。 第 13 段 · 第 19 段 · 第 20 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why do the two branches treat mid differently?

正文支撐及連結論證（完整精確段落）：

- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-9` EN: This property permits discarding whole ranges. If speed 6 fails, every speed from 1 through 6 fails. If speed 6 works, the minimum successful speed is at most 6, but might be smaller. Returning the first successful probe would ignore that distinction.
  ZH: 這個性質允許我們一次排除整段範圍。如果速度 6 失敗，從 1 到 6 的每個速度都失敗。如果速度 6 成功，最小成功速度至多是 6，但也可能更小。一遇到成功的 probe 就回傳，會忽略這個差別。
- `alg-p-11` EN: At the start of every search iteration, maintain this invariant: The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. Here feasible means that the speed passes the hours test. The monotone property describes the problem's answers across all speeds; the invariant describes what the current search state still guarantees.
  ZH: 在每次 search iteration 開始時，維持這個 invariant：The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. 意思是最小可行速度仍在包含兩端的 [low, high] 裡，而且 high 本身可行。這裡 feasible 指速度通過小時數檢查。monotone 性質描述所有速度的答案如何變化；invariant 描述目前搜尋狀態仍保證哪些事。
- `alg-p-12` EN: Choose mid = (low + high) // 2, the lower middle integer. When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
  ZH: 選擇 mid = (low + high) // 2，也就是偏下方的中間整數。當 T(mid) > h，設定 low = mid + 1：mid 和所有更小速度都已失敗。否則設定 high = mid：更大速度已無必要，但成功的 mid 仍須留作候選。當 low == high 時停止，回傳該數值。這種把有序候選範圍反覆減半的方法，就是 binary search。
- `alg-p-18` EN: Initially, the answer lies between 1 and M, and M is feasible. Suppose the invariant holds before an iteration. If mid fails, monotonicity excludes all speeds at most mid, so the answer remains in [mid + 1, high]; the unchanged high remains feasible. If mid succeeds, some feasible speed is now known at mid. The minimum therefore lies in [low, mid], and assigning high = mid keeps the upper endpoint feasible. Each branch preserves both parts of the invariant.
  ZH: 一開始，答案在 1 到 M 之間，而且 M 可行。假設某次 iteration 開始前 invariant 成立。如果 mid 失敗，monotonicity 排除所有至多為 mid 的速度，因此答案仍在 [mid + 1, high]；未變動的 high 仍然可行。如果 mid 成功，我們便知道 mid 是一個可行速度。最小值因此落在 [low, mid]，設定 high = mid 也讓 upper endpoint 保持可行。兩個 branch 都保留 invariant 的兩項保證。
- `alg-p-19` EN: When low < high, the lower middle satisfies low <= mid < high. In the failure branch the lower endpoint strictly increases; in the success branch the upper endpoint strictly decreases. The interval stays nonempty and has fewer integer candidates, so it must eventually contain one candidate. The invariant then says that this sole candidate is the minimum feasible speed. Returning low is justified even if that exact speed was not separately tested after the final update.
  ZH: 當 low < high，偏下方的中間值滿足 low <= mid < high。失敗 branch 嚴格提高 lower endpoint；成功 branch 嚴格降低 upper endpoint。interval 維持非空，整數候選卻變少，因此最後一定只剩一個候選。invariant 此時保證這個唯一候選就是最小可行速度。即使最後一次更新後沒有另外測試那個確切速度，回傳 low 仍有根據。

### 第 14 段 / alg-p-13 — PASS_BOUNDED

scan 前 low=high=1 與結束 high=11 的時點清楚，每個新 speed 的 hours 重設有 code 與正文理由。

相鄰不合法推論：未把初始最大值 scan 中的 high 當成已證可行的 search high；也未沿用上一 probe 的 total。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 實作各階段的 scalar 表示什麼？
- `alg-four-zh` [PASS_BOUNDED]: trace 先以 high = 1 掃描 [3, 6, 7, 11]，high 逐步成為 3、6、7、11；每次測試新 speed 都重新把 hours 設為零。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Use piles = [3, 6, 7, 11] and h = 8. Initialize low = 1 and high = 1. //The largest-pile scan reads 3, 6, 7, 11; each exceeds the stored upper bound, //so high becomes 3, then 6, then 7, then 11. //Each hours calculation starts again at zero.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：本例 piles = [3, 6, 7, 11]、h = 8，scan 前 low、high 都為 1。 第 14 段適用前提：每個新 speed 需要自己的總時數，不能沿用前一次的 hours。 第 18 段判讀時點：找最大堆的 scan 完成後 high = 11；每次 hours 計算開始時重新為零。 第 14 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：When must the hours total restart?

正文支撐及連結論證（完整精確段落）：

- `alg-p-13` EN: Use piles = [3, 6, 7, 11] and h = 8. Initialize low = 1 and high = 1. The largest-pile scan reads 3, 6, 7, 11; each exceeds the stored upper bound, so high becomes 3, then 6, then 7, then 11. Each hours calculation starts again at zero.
  ZH: 使用 piles = [3, 6, 7, 11]、h = 8。先初始化 low = 1 和 high = 1。尋找最大香蕉堆的 scan 依序讀取 3, 6, 7, 11；每個值都超過當時儲存的 upper bound，因此 high 依序變成 3、6、7、11。每次計算 hours 都重新從零開始。
- `alg-p-17` EN: hours = 0 belongs inside the while loop because a new speed needs a new total. hours += ... adds to this scalar, not to the input list. The two assignments after the scan are the same two interval changes in the trace. All candidate speeds stay positive, so the division never has a zero divisor. There is no recursion, sorting, copied input, or saved history of probes.
  ZH: hours = 0 必須放在 while loop 裡，因為每個新速度都需要新的總和。hours += ... 加到這個 scalar，不是加到輸入 list。scan 後的兩個 assignment，就是前面 trace 中的兩種 interval 更新。所有候選速度都保持正值，所以不會出現零 divisor。這裡沒有 recursion、sorting、輸入副本，也不儲存歷次 probe。

### 第 15 段 / alg-p-14 — PASS_BOUNDED

固定例子與 h=8 保留；6 可行但答案4，以及4、5同八小時，由 generated trace 完整驗證。

相鄰不合法推論：第一次成功或恰等於 deadline 都不能單獨證最小；不是禁止 singleton 時回傳。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 實作各階段的 scalar 表示什麼？
- `alg-four-zh` [PASS_BOUNDED]: 這個 trace 的 6 已可行但答案為 4；4、5 都恰用八小時，顯示 equality 與首次 probe 成功都不能證明最小值。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: The first probe succeeds at 6, //yet the final answer is 4. The failed probe at 3 removes speeds 1, 2, 3 together. Speeds 4 and 5 both take eight hours, //so an exact match to the deadline does not justify returning immediately either. The search needs the first successful speed, /including when several speeds give the same total.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：本例使用 [3, 6, 7, 11]、h = 8；每堆單獨取 ceiling。 第 8 段 · 第 14 段 · 第 15 段適用前提：找的是最小可行 speed，成功的 probe 只能提供上界。 第 2 段 · 第 10 段判讀時點：probe 6 成功後仍縮小上界；3 失敗排除 1、2、3；最後 interval 留下 4。 第 13 段 · 第 15 段 · 第 20 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why is an exact deadline match insufficient to return?

正文支撐及連結論證（完整精確段落）：

- `alg-p-7` EN: At k = 4 on [3, 6, 7, 11], an accumulator named hours starts at zero. The first pile contributes (3 + 3) // 4 = 1, changing hours to 1. The next contributes 2, changing it to 3; the next contributes 2, changing it to 5; the last contributes 3, changing it to 8. The calculation stores a running total, without allocating a list of all four contributions or changing the piles.
  ZH: 以 k = 4 處理 [3, 6, 7, 11] 時，名為 hours 的 accumulator 從零開始。第一堆貢獻 (3 + 3) // 4 = 1，讓 hours 變成 1。下一堆貢獻 2，讓它變成 3；再下一堆貢獻 2，讓它變成 5；最後一堆貢獻 3，讓它變成 8。計算只保留累計總和，不會為這四個貢獻值另建 list，也不會改動香蕉堆。
- `alg-p-13` EN: Use piles = [3, 6, 7, 11] and h = 8. Initialize low = 1 and high = 1. The largest-pile scan reads 3, 6, 7, 11; each exceeds the stored upper bound, so high becomes 3, then 6, then 7, then 11. Each hours calculation starts again at zero.
  ZH: 使用 piles = [3, 6, 7, 11]、h = 8。先初始化 low = 1 和 high = 1。尋找最大香蕉堆的 scan 依序讀取 3, 6, 7, 11；每個值都超過當時儲存的 upper bound，因此 high 依序變成 3、6、7、11。每次計算 hours 都重新從零開始。
- `alg-p-14` EN: The first probe succeeds at 6, yet the final answer is 4. The failed probe at 3 removes speeds 1, 2, 3 together. Speeds 4 and 5 both take eight hours, so an exact match to the deadline does not justify returning immediately either. The search needs the first successful speed, including when several speeds give the same total.
  ZH: 第一次 probe 在 6 就成功，但最後答案是 4。速度 3 的失敗，一次排除了 1, 2, 3。速度 4 和 5 都需要八小時，因此總時數恰好等於 deadline，也不能成為立即回傳的理由。即使數個速度給出相同總時數，搜尋仍須找出第一個成功速度。
- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-9` EN: This property permits discarding whole ranges. If speed 6 fails, every speed from 1 through 6 fails. If speed 6 works, the minimum successful speed is at most 6, but might be smaller. Returning the first successful probe would ignore that distinction.
  ZH: 這個性質允許我們一次排除整段範圍。如果速度 6 失敗，從 1 到 6 的每個速度都失敗。如果速度 6 成功，最小成功速度至多是 6，但也可能更小。一遇到成功的 probe 就回傳，會忽略這個差別。
- `alg-p-12` EN: Choose mid = (low + high) // 2, the lower middle integer. When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
  ZH: 選擇 mid = (low + high) // 2，也就是偏下方的中間整數。當 T(mid) > h，設定 low = mid + 1：mid 和所有更小速度都已失敗。否則設定 high = mid：更大速度已無必要，但成功的 mid 仍須留作候選。當 low == high 時停止，回傳該數值。這種把有序候選範圍反覆減半的方法，就是 binary search。
- `alg-p-19` EN: When low < high, the lower middle satisfies low <= mid < high. In the failure branch the lower endpoint strictly increases; in the success branch the upper endpoint strictly decreases. The interval stays nonempty and has fewer integer candidates, so it must eventually contain one candidate. The invariant then says that this sole candidate is the minimum feasible speed. Returning low is justified even if that exact speed was not separately tested after the final update.
  ZH: 當 low < high，偏下方的中間值滿足 low <= mid < high。失敗 branch 嚴格提高 lower endpoint；成功 branch 嚴格降低 upper endpoint。interval 維持非空，整數候選卻變少，因此最後一定只剩一個候選。invariant 此時保證這個唯一候選就是最小可行速度。即使最後一次更新後沒有另外測試那個確切速度，回傳 low 仍有根據。

### 第 16 段 / alg-p-15 — PASS_BOUNDED

p=11,k=4 的4,4,3與最後時段的歸屬保留，正文每小時規則支撐 pooling 錯誤機制。

相鄰不合法推論：不能把最後一小時餘量移到其他堆；未聲稱最後一定吃滿 k。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何精確測試一個 speed？
- `alg-four-zh` [PASS_BOUNDED]: 11 根以 speed 4 分成 4、4、3 三小時；最後未用滿容量的時段仍屬於該堆。這正是 scalar ceiling 計算不能改成 pooling 的原因。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: At speed 4, the pile of 11 uses hours /for 4, 4, and 3 bananas. //That last partially used hour still belongs to this pile. The scalar calculation and the physical eating rule agree /at the place where pooling would give the wrong model.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：固定 p = 11、k = 4，原題不允許同小時換堆。 第 2 段 · 第 5 段 · 第 16 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Who owns the unused capacity in the last hour?

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-4` EN: For a pile of size p at speed k, count complete groups of k bananas. If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer at least as large as that quotient. For p = 11 and k = 4, the groups are 4, 4, 3, so the pile takes three hours.
  ZH: 對大小為 p 的一堆香蕉，以速度 k 進食，先數出完整的 k 根一組有幾組。若還有剩餘香蕉，就需要額外一個完整小時。這個數量是 p / k 的 ceiling，也就是不小於該商的最小整數。例如 p = 11、k = 4，會分成 4, 4, 3，因此需要三小時。
- `alg-p-15` EN: At speed 4, the pile of 11 uses hours for 4, 4, and 3 bananas. That last partially used hour still belongs to this pile. The scalar calculation and the physical eating rule agree at the place where pooling would give the wrong model.
  ZH: 速度 4 處理大小為 11 的那堆時，三個小時分別吃 4、4、3 根。最後那個未用滿容量的小時，仍只屬於這一堆。這正是 pooling 會建立錯誤模型的位置，而 scalar 計算仍符合實際進食規則。

### 第 17 段 / alg-p-16 — PASS_BOUNDED

high 的「已讀最大值」限於每讀一個元素後；正 pile 令 high=1 初始化合法。wrapper/self 與同一 list 的 scope 符合 code。

相鄰不合法推論：不能在尚未讀任何元素時說 high 等於已讀最大值；不能把 loop scalar 說成 instance state。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 實作各階段的 scalar 表示什麼？
- `alg-four-zh` [PASS_BOUNDED]: 最大堆 scan 的 high 表示已讀元素的最大值；之後每個 search iteration 都讀同一 list 算總時數。Solution 是 wrapper，演算法沒有把狀態存到 self。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: The first loop finds the largest pile explicitly: /after each item, high holds the largest value [seen so far], /with initial value 1 valid because every pile is positive. //Each search iteration then traverses the same list to calculate its proposed speed's total. The Solution class is the submission wrapper; self refers to its instance, //and the algorithm stores no state on that instance.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：每堆大小至少為 1，使初始 high = 1 有效；此段描述文中指定實作。 第 3 段 · 第 17 段判讀時點：初始 scan 每處理完一個元素後 high 是目前最大值；之後才進入 speed search。 第 17 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：What does high mean during the initial scan?

正文支撐及連結論證（完整精確段落）：

- `alg-p-2` EN: The constraints are 1 <= n <= 10^4, n <= h <= 10^9, and 1 <= piles[i] <= 10^9, where n is the number of piles. Every pile needs at least one hour, so h >= n matters: the problem guarantees that a sufficiently large speed can work. The solution below only reads the input list; it neither sorts nor changes its elements. Empty lists and h < n are outside this contract. Problem statement and constraints.
  ZH: 限制是 1 <= n <= 10^4、n <= h <= 10^9，以及 1 <= piles[i] <= 10^9，其中 n 是香蕉堆數。每堆至少需要一小時，因此 h >= n 很重要：題目保證速度夠大就一定能完成。下面的解法只讀取輸入 list，不排序，也不改動其中的元素。空 list 和 h < n 不在這份 contract 內。題目敘述與限制。
- `alg-p-16` EN: The first loop finds the largest pile explicitly: after each item, high holds the largest value seen so far, with initial value 1 valid because every pile is positive. Each search iteration then traverses the same list to calculate its proposed speed's total. The Solution class is the submission wrapper; self refers to its instance, and the algorithm stores no state on that instance.
  ZH: 第一個 loop 明確找出最大香蕉堆：每讀取一個元素後，high 就保留目前看過的最大值；因為所有香蕉堆都是正整數，初始值 1 合法。之後每次 search iteration 都走訪同一份 list，計算候選速度所需的總時數。Solution class 是提交程式的 wrapper；self 指向它的 instance，演算法不會在該 instance 上儲存狀態。

### 第 18 段 / alg-p-17 — PASS_BOUNDED

本文指定 code 把 reset 放 while 內、總和存 scalar、scan 後才更新端點；正 endpoints 保證正 mid，沒有 state/history 副作用。

相鄰不合法推論：不能把 += 當 list append；不能把每個新 test 當累積先前 probes 的 hours。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 實作各階段的 scalar 表示什麼？
- `alg-four-zh` [PASS_BOUNDED]: hours = 0 在 while 內讓每個 speed 使用獨立總和；+= 更新 scalar。候選 speed 保持正值，division 無零 divisor；此實作不留 probe history。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: hours = 0 belongs inside the while loop //because a new speed needs a new total. hours += ... adds to this scalar, /not to the input list. The two assignments after the scan are the same two interval changes in the trace. All candidate speeds stay positive, //so the division never has a zero divisor. There is no recursion, sorting, copied input, or saved history of probes.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：本文實作以 [1, M] 起始，且依兩種 interval 更新保留正數候選。 第 11 段 · 第 13 段適用前提：此段描述本文指定實作：總和放在 hours scalar，輸入與 instance 不儲存新的演算法狀態。 第 17 段 · 第 18 段判讀時點：每次 while iteration 先將 hours 歸零，scan 完才更新 endpoint。 第 18 段 · 第 13 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why must a new probe reset hours?

正文支撐及連結論證（完整精確段落）：

- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。
- `alg-p-12` EN: Choose mid = (low + high) // 2, the lower middle integer. When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
  ZH: 選擇 mid = (low + high) // 2，也就是偏下方的中間整數。當 T(mid) > h，設定 low = mid + 1：mid 和所有更小速度都已失敗。否則設定 high = mid：更大速度已無必要，但成功的 mid 仍須留作候選。當 low == high 時停止，回傳該數值。這種把有序候選範圍反覆減半的方法，就是 binary search。
- `alg-p-16` EN: The first loop finds the largest pile explicitly: after each item, high holds the largest value seen so far, with initial value 1 valid because every pile is positive. Each search iteration then traverses the same list to calculate its proposed speed's total. The Solution class is the submission wrapper; self refers to its instance, and the algorithm stores no state on that instance.
  ZH: 第一個 loop 明確找出最大香蕉堆：每讀取一個元素後，high 就保留目前看過的最大值；因為所有香蕉堆都是正整數，初始值 1 合法。之後每次 search iteration 都走訪同一份 list，計算候選速度所需的總時數。Solution class 是提交程式的 wrapper；self 指向它的 instance，演算法不會在該 instance 上儲存狀態。
- `alg-p-17` EN: hours = 0 belongs inside the while loop because a new speed needs a new total. hours += ... adds to this scalar, not to the input list. The two assignments after the scan are the same two interval changes in the trace. All candidate speeds stay positive, so the division never has a zero divisor. There is no recursion, sorting, copied input, or saved history of probes.
  ZH: hours = 0 必須放在 while loop 裡，因為每個新速度都需要新的總和。hours += ... 加到這個 scalar，不是加到輸入 list。scan 後的兩個 assignment，就是前面 trace 中的兩種 interval 更新。所有候選速度都保持正值，所以不會出現零 divisor。這裡沒有 recursion、sorting、輸入副本，也不儲存歷次 probe。

### 第 19 段 / alg-p-18 — PASS_BOUNDED

先假設 invariant，再由 monotonicity 分別保留答案及可行 high；context 逐項交代前後狀態。

相鄰不合法推論：失敗不保留 mid；成功保留 mid 但不保證 mid 已最小；不是只用單調性便宣告搜尋狀態正確。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: 初始 M 可行。mid 失敗時排除所有 <= mid 的速度，high 不變；成功時保留 [low, mid] 並讓新 high = mid 可行，所以兩個 branch 都維持 invariant。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Initially, the answer lies between 1 and M, and M is feasible. //Suppose the invariant holds before an iteration. //If mid fails, monotonicity excludes all speeds at most mid, //so the answer remains in [mid + 1, high]; the unchanged high remains feasible. //If mid succeeds, some feasible speed is now known at mid. The minimum therefore lies in [low, mid], and assigning high = mid keeps the upper endpoint feasible. //Each branch preserves [both parts of the invariant].
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：初始 [1, M] 包含答案；當前 inclusive interval 包含最小 feasible speed，且 high 可行。 第 11 段 · 第 12 段適用前提：T(k) 不增加，故失敗排除更慢者、成功提供可行上界。 第 9 段 · 第 10 段判讀時點：假設 iteration 前 invariant 成立，完成對應 endpoint 更新後再檢查兩項保證。 第 19 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：How does each branch preserve both invariant clauses?

正文支撐及連結論證（完整精確段落）：

- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。
- `alg-p-11` EN: At the start of every search iteration, maintain this invariant: The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. Here feasible means that the speed passes the hours test. The monotone property describes the problem's answers across all speeds; the invariant describes what the current search state still guarantees.
  ZH: 在每次 search iteration 開始時，維持這個 invariant：The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. 意思是最小可行速度仍在包含兩端的 [low, high] 裡，而且 high 本身可行。這裡 feasible 指速度通過小時數檢查。monotone 性質描述所有速度的答案如何變化；invariant 描述目前搜尋狀態仍保證哪些事。
- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-9` EN: This property permits discarding whole ranges. If speed 6 fails, every speed from 1 through 6 fails. If speed 6 works, the minimum successful speed is at most 6, but might be smaller. Returning the first successful probe would ignore that distinction.
  ZH: 這個性質允許我們一次排除整段範圍。如果速度 6 失敗，從 1 到 6 的每個速度都失敗。如果速度 6 成功，最小成功速度至多是 6，但也可能更小。一遇到成功的 probe 就回傳，會忽略這個差別。
- `alg-p-18` EN: Initially, the answer lies between 1 and M, and M is feasible. Suppose the invariant holds before an iteration. If mid fails, monotonicity excludes all speeds at most mid, so the answer remains in [mid + 1, high]; the unchanged high remains feasible. If mid succeeds, some feasible speed is now known at mid. The minimum therefore lies in [low, mid], and assigning high = mid keeps the upper endpoint feasible. Each branch preserves both parts of the invariant.
  ZH: 一開始，答案在 1 到 M 之間，而且 M 可行。假設某次 iteration 開始前 invariant 成立。如果 mid 失敗，monotonicity 排除所有至多為 mid 的速度，因此答案仍在 [mid + 1, high]；未變動的 high 仍然可行。如果 mid 成功，我們便知道 mid 是一個可行速度。最小值因此落在 [low, mid]，設定 high = mid 也讓 upper endpoint 保持可行。兩個 branch 都保留 invariant 的兩項保證。

### 第 20 段 / alg-p-19 — PASS_BOUNDED

low<high 下 lower middle 的界線、端點嚴格移動、interval 非空與有限整數候選形成停止論證；singleton 套 invariant。

相鄰不合法推論：不需再測試最後值不等於可以省略 invariant；也未聲稱 interval 能變空再回傳。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: low < high 時 lower middle 小於 high；失敗提高 low，成功降低 high，候選數嚴格減少又不空。只剩一個時，invariant 已保證它是最小 feasible speed，無須額外 probe。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: When low < high, /the lower middle satisfies low <= mid < high. //In the failure branch the lower endpoint strictly increases; in the success branch the upper endpoint strictly decreases. The interval stays nonempty and has fewer integer candidates, //so it must eventually contain one candidate. The invariant then says that this sole candidate is the minimum feasible speed. Returning low is justified /even if that exact speed was not separately tested after the final update.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：這個 lower-middle 與兩種更新保留答案和可行 high。 第 13 段 · 第 19 段適用前提：low < high 時有 low <= mid < high，且每次更新減少整數候選數。 第 20 段判讀時點：停止時 low == high，將一直維持的 invariant 套到唯一剩餘候選。 第 12 段 · 第 20 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why can the final candidate be returned without another test?

正文支撐及連結論證（完整精確段落）：

- `alg-p-12` EN: Choose mid = (low + high) // 2, the lower middle integer. When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
  ZH: 選擇 mid = (low + high) // 2，也就是偏下方的中間整數。當 T(mid) > h，設定 low = mid + 1：mid 和所有更小速度都已失敗。否則設定 high = mid：更大速度已無必要，但成功的 mid 仍須留作候選。當 low == high 時停止，回傳該數值。這種把有序候選範圍反覆減半的方法，就是 binary search。
- `alg-p-18` EN: Initially, the answer lies between 1 and M, and M is feasible. Suppose the invariant holds before an iteration. If mid fails, monotonicity excludes all speeds at most mid, so the answer remains in [mid + 1, high]; the unchanged high remains feasible. If mid succeeds, some feasible speed is now known at mid. The minimum therefore lies in [low, mid], and assigning high = mid keeps the upper endpoint feasible. Each branch preserves both parts of the invariant.
  ZH: 一開始，答案在 1 到 M 之間，而且 M 可行。假設某次 iteration 開始前 invariant 成立。如果 mid 失敗，monotonicity 排除所有至多為 mid 的速度，因此答案仍在 [mid + 1, high]；未變動的 high 仍然可行。如果 mid 成功，我們便知道 mid 是一個可行速度。最小值因此落在 [low, mid]，設定 high = mid 也讓 upper endpoint 保持可行。兩個 branch 都保留 invariant 的兩項保證。
- `alg-p-19` EN: When low < high, the lower middle satisfies low <= mid < high. In the failure branch the lower endpoint strictly increases; in the success branch the upper endpoint strictly decreases. The interval stays nonempty and has fewer integer candidates, so it must eventually contain one candidate. The invariant then says that this sole candidate is the minimum feasible speed. Returning low is justified even if that exact speed was not separately tested after the final update.
  ZH: 當 low < high，偏下方的中間值滿足 low <= mid < high。失敗 branch 嚴格提高 lower endpoint；成功 branch 嚴格降低 upper endpoint。interval 維持非空，整數候選卻變少，因此最後一定只剩一個候選。invariant 此時保證這個唯一候選就是最小可行速度。即使最後一次更新後沒有另外測試那個確切速度，回傳 low 仍有根據。
- `alg-p-11` EN: At the start of every search iteration, maintain this invariant: The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. Here feasible means that the speed passes the hours test. The monotone property describes the problem's answers across all speeds; the invariant describes what the current search state still guarantees.
  ZH: 在每次 search iteration 開始時，維持這個 invariant：The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. 意思是最小可行速度仍在包含兩端的 [low, high] 裡，而且 high 本身可行。這裡 feasible 指速度通過小時數檢查。monotone 性質描述所有速度的答案如何變化；invariant 描述目前搜尋狀態仍保證哪些事。

### 第 21 段 / alg-p-20 — PASS_BOUNDED

以指定 [2],h=1,[1,2] 反例顯示 low=mid 可能完全不前進，checkpoint 明確是錯誤 assignment 後狀態。

相鄰不合法推論：是存在卡住反例，並未聲稱每個 failure 都卡住；+1 必須移除已否定候選。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: 錯把 failure 更新寫成 low = mid，可能完全不縮小 interval。[2]、h = 1 時 [1, 2] 的 mid = 1 失敗，卻反覆保留同一狀態；+ 1 才移除失敗候選。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Updating low = mid on failure would break progress. //For piles = [2], h = 1, the interval is [1, 2] and mid = 1 fails. //That incorrect assignment leaves [1, 2] unchanged forever. The + 1 removes a candidate /that the hours test has already disproved.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：反例使用 lower middle，piles = [2]、h = 1、interval = [1, 2]。 第 21 段適用前提：正確規則是在 mid 失敗後設 low = mid + 1。 第 13 段判讀時點：錯誤 assignment 執行後 interval 仍是 [1, 2]，下一輪重複同一失敗 probe。 第 21 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Which candidate must the failure branch actually remove?

正文支撐及連結論證（完整精確段落）：

- `alg-p-20` EN: Updating low = mid on failure would break progress. For piles = [2], h = 1, the interval is [1, 2] and mid = 1 fails. That incorrect assignment leaves [1, 2] unchanged forever. The + 1 removes a candidate that the hours test has already disproved.
  ZH: 若失敗時改成更新 low = mid，就會破壞前進的保證。對 piles = [2]、h = 1，interval 是 [1, 2]，而 mid = 1 失敗。錯誤的 assignment 會讓 [1, 2] 永遠不變。+ 1 是為了移除小時數檢查已經否定的候選。
- `alg-p-12` EN: Choose mid = (low + high) // 2, the lower middle integer. When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
  ZH: 選擇 mid = (low + high) // 2，也就是偏下方的中間整數。當 T(mid) > h，設定 low = mid + 1：mid 和所有更小速度都已失敗。否則設定 high = mid：更大速度已無必要，但成功的 mid 仍須留作候選。當 low == high 時停止，回傳該數值。這種把有序候選範圍反覆減半的方法，就是 binary search。

### 第 22 段 / alg-p-21 — PASS_BOUNDED

四個邊界及原題限制保持；M=1 不進 search、h=n 的最大堆、h>=香蕉總數的1及h<n無解都有正文因果。

相鄰不合法推論：M=1 不進 search 不等於整個算法不掃描；h<n 不因速度加大而可解。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: 全為 1 時 M = 1，免進 search；h = n 時最大堆迫使答案為 M；h 足夠容納每根一小時時答案為 1。h < n 則在原題規則下根本無解。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Boundary inputs also follow the same reasoning. //With all piles of size 1, M = 1 and the search loop never runs; speed 1 is already the answer. //If h = n, each pile must fit into its one hour, so the largest pile forces the answer to be M. //If h is [at least] the total number of bananas, speed 1 works and the search converges to 1. The guarantee h >= n is essential: /outside it, even unlimited speed cannot fit all the positive piles into the deadline.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：每堆為正且各佔至少一小時；speed 為正整數。 第 2 段 · 第 3 段適用前提：M 可行的證明使用 h >= n，不能延用到 h < n。 第 11 段 · 第 22 段判讀時點：M = 1 初始化後 low == high，search loop 不執行就回傳 1。 第 22 段 · 第 20 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Which boundary inputs make the answer known immediately?

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-2` EN: The constraints are 1 <= n <= 10^4, n <= h <= 10^9, and 1 <= piles[i] <= 10^9, where n is the number of piles. Every pile needs at least one hour, so h >= n matters: the problem guarantees that a sufficiently large speed can work. The solution below only reads the input list; it neither sorts nor changes its elements. Empty lists and h < n are outside this contract. Problem statement and constraints.
  ZH: 限制是 1 <= n <= 10^4、n <= h <= 10^9，以及 1 <= piles[i] <= 10^9，其中 n 是香蕉堆數。每堆至少需要一小時，因此 h >= n 很重要：題目保證速度夠大就一定能完成。下面的解法只讀取輸入 list，不排序，也不改動其中的元素。空 list 和 h < n 不在這份 contract 內。題目敘述與限制。
- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。
- `alg-p-21` EN: Boundary inputs also follow the same reasoning. With all piles of size 1, M = 1 and the search loop never runs; speed 1 is already the answer. If h = n, each pile must fit into its one hour, so the largest pile forces the answer to be M. If h is at least the total number of bananas, speed 1 works and the search converges to 1. The guarantee h >= n is essential: outside it, even unlimited speed cannot fit all the positive piles into the deadline.
  ZH: 邊界輸入也遵循同一套推理。若每堆大小都是 1，則 M = 1，search loop 完全不執行；速度 1 已是答案。若 h = n，每堆都必須在分配給自己的一小時內吃完，因此最大那堆迫使答案為 M。若 h 至少等於香蕉總數，速度 1 可行，搜尋便收斂到 1。h >= n 這項保證不可省略：在它不成立時，即使速度無限大，也無法在 deadline 內處理所有正數香蕉堆。
- `alg-p-19` EN: When low < high, the lower middle satisfies low <= mid < high. In the failure branch the lower endpoint strictly increases; in the success branch the upper endpoint strictly decreases. The interval stays nonempty and has fewer integer candidates, so it must eventually contain one candidate. The invariant then says that this sole candidate is the minimum feasible speed. Returning low is justified even if that exact speed was not separately tested after the final update.
  ZH: 當 low < high，偏下方的中間值滿足 low <= mid < high。失敗 branch 嚴格提高 lower endpoint；成功 branch 嚴格降低 upper endpoint。interval 維持非空，整數候選卻變少，因此最後一定只剩一個候選。invariant 此時保證這個唯一候選就是最小可行速度。即使最後一次更新後沒有另外測試那個確切速度，回傳 low 仍有根據。

### 第 23 段 / alg-p-22 — PASS_BOUNDED

numeric range 與 operation-count model 明列，Active 另外連到掃描、halving、fixed live state 的完整正文論證；oracle 排除任意長整數。

相鄰不合法推論：常數成本是宣告模型，不是所有 Python 指令 wall-clock 相同；O(1) 不延伸到無界 bit-size。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive + Active · 何種 cost model 支持時間與空間界線？
- `alg-four-zh` [PASS_BOUNDED]: 這裡把限制內的 list read、整數比較與算術各算 constant work；numeric range 有界且 Python integers 精確。這是 operation-count model，不是相同 wall-clock 耗時的宣稱。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Use a [bounded-integer cost model]: /reading a list element, comparing these integers, and doing arithmetic on values within this problem's limits each count as constant work. This compares growth in operation counts, /not equal wall-clock time for every Python instruction. Pile sizes and speeds are at most 10^9, and an hours total is at most n * M <= 10^13, //so their required numeric range is bounded. Python integers remain exact at these values; they do not wrap at a fixed machine limit. Python numeric types.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：n <= 10^4、pile sizes 與 speeds <= 10^9，總 hours <= n * M <= 10^13。 第 3 段 · 第 11 段 · 第 23 段適用前提：本文明確宣告 bounded-integer cost model；不涵蓋任意長整數的 bit-size 成本。 第 23 段 · 第 26 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Which assumptions make arithmetic constant work in this analysis?
- `alg-active-word` [PASS_BOUNDED]: bounded-integer cost modelUnder the bounded-integer cost model, n-element scans and repeated halving give O(n * (1 + log M)) time and fixed live scalar state gives O(1) auxiliary space.
- `alg-supporting-sources` [PASS_BOUNDED]: 推導前提：第 3 段 · 第 11 段 · 第 23 段 · 第 24 段 · 第 25 段 · 第 26 段
- `alg-four-recall` [PASS_BOUNDED]: Active · 自行表達後核對Derive time and auxiliary space under the stated model.Oracle · 嘗試後展開Define n as pile count and M as largest pile. Bounded reads, comparisons and arithmetic count as constant work. One initial n scan plus at most ceil(log2 M) complete n scans yields n + n * ceil(log2 M). Fixed scalars and transient bounded values remain live, excluding input; arbitrary-length integers need separate bit-size analysis.

正文支撐及連結論證（完整精確段落）：

- `alg-p-2` EN: The constraints are 1 <= n <= 10^4, n <= h <= 10^9, and 1 <= piles[i] <= 10^9, where n is the number of piles. Every pile needs at least one hour, so h >= n matters: the problem guarantees that a sufficiently large speed can work. The solution below only reads the input list; it neither sorts nor changes its elements. Empty lists and h < n are outside this contract. Problem statement and constraints.
  ZH: 限制是 1 <= n <= 10^4、n <= h <= 10^9，以及 1 <= piles[i] <= 10^9，其中 n 是香蕉堆數。每堆至少需要一小時，因此 h >= n 很重要：題目保證速度夠大就一定能完成。下面的解法只讀取輸入 list，不排序，也不改動其中的元素。空 list 和 h < n 不在這份 contract 內。題目敘述與限制。
- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。
- `alg-p-22` EN: Use a bounded-integer cost model: reading a list element, comparing these integers, and doing arithmetic on values within this problem's limits each count as constant work. This compares growth in operation counts, not equal wall-clock time for every Python instruction. Pile sizes and speeds are at most 10^9, and an hours total is at most n * M <= 10^13, so their required numeric range is bounded. Python integers remain exact at these values; they do not wrap at a fixed machine limit. Python numeric types.
  ZH: 採用 bounded-integer cost model：讀取一個 list 元素、比較這些整數，以及對本題限制內的值做算術，都各算 constant work。這是在比較 operation count 的成長，不是宣稱每個 Python instruction 的實際耗時相同。香蕉堆大小和速度至多是 10^9，總時數至多是 n * M <= 10^13，因此需要的數值範圍有界。Python 的整數在這些值上保持精確，不會在固定的 machine limit 發生 wraparound。Python numeric types。
- `alg-p-25` EN: Only a fixed number of scalars and a loop's traversal state remain live. Reassigning hours or an endpoint replaces its previous value; it does not retain one entry per pile or per iteration. Auxiliary space is therefore O(1) in the same bounded-integer model, excluding the supplied input list. Temporary arithmetic results add only a fixed number of bounded values. The returned output is one integer, also O(1) space under this model. If arbitrary-length integer inputs replaced the stated limits, arithmetic and integer storage would need a separate bit-size analysis; the scalar model here does not claim otherwise.
  ZH: 同時存活的只有固定數量的 scalar 和 loop 的 traversal state。重新賦值給 hours 或 endpoint，會取代前一個值，不會為每堆或每次 iteration 保留一筆紀錄。因此，在相同 bounded-integer model 下，auxiliary space 是 O(1)，不計入呼叫者提供的輸入 list。暫時算術結果也只增加固定數量的有界數值。回傳 output 是一個整數，在此模型下同樣使用 O(1) 空間。如果把題目限制換成任意長度的整數輸入，算術和整數儲存就需要另做 bit-size analysis；這裡的 scalar model 並未宣稱涵蓋那種情況。
- `alg-p-23` EN: The largest-pile loop visits n elements. A proposed speed also visits all n piles, performing a fixed number of arithmetic and update operations for each, so one test costs proportional to n. The code deliberately computes the complete total even when it already exceeds h.
  ZH: 尋找最大香蕉堆的 loop 走訪 n 個元素。測試一個候選速度也會走訪全部 n 堆，每堆執行固定數量的算術與更新，因此一次檢查的成本與 n 成正比。這份程式即使累計總和已超過 h，仍會刻意把總時數算完。
- `alg-p-24` EN: The lower middle splits an interval into a lower group including mid and an upper group excluding it. With an even number L of candidates, each group has L / 2 members; with an odd L, the lower group has one more member than the upper. Success keeps the lower group and failure keeps the upper, so either update leaves at most ceil(L / 2) candidates. For example, an initial M = 11 gives worst-case size bounds 11 -> 6 -> 3 -> 2 -> 1. After t halvings, at most ceil(M / 2^t) candidates remain. It suffices for 2^t to reach M; ceil(log2 M) is the smallest such whole number of halvings. Thus the total work is at most a constant times n + n * ceil(log2 M), written O(n * (1 + log M)). For M >= 2, the common shorthand is O(n log M). Keeping the initial n term explains the M = 1 case too. Since 2^30 > 10^9, the stated limits need at most thirty proposed-speed scans.
  ZH: 偏下方的中間值把 interval 分成兩組：包含 mid 的下半組，以及不包含它的上半組。候選數 L 為偶數時，每組都有 L / 2 個；L 為奇數時，下半組比上半組多一個。成功保留下半組，失敗保留上半組，因此任一更新後都至多剩下 ceil(L / 2) 個候選。例如初始 M = 11 時，候選數的 worst-case 上界依序是 11 -> 6 -> 3 -> 2 -> 1。減半 t 次後，至多剩下 ceil(M / 2^t) 個候選。只要 2^t 達到 M 就足夠；ceil(log2 M) 就是滿足此條件的最小整數減半次數。因此，總工作量至多是某個常數乘上 n + n * ceil(log2 M)，記為 O(n * (1 + log M))。當 M >= 2，常見簡寫是 O(n log M)。保留起初的 n 這一項，也能說明 M = 1 的情況。因為 2^30 > 10^9，在題目限制內至多需要三十次候選速度的 scan。

### 第 24 段 / alg-p-23 — PASS_BOUNDED

指定 code 每次完整掃 n 堆，固定有界工作支持 proportional n；英文、zh_note及 context 限定無 early exit。

相鄰不合法推論：不能把超過 h 後提前停止當成這份 code 的行為；也不能把一個 test 當常數總成本。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 何種 cost model 支持時間與空間界線？
- `alg-four-zh` [PASS_BOUNDED]: 最大堆 scan 與每次 proposed-speed test 都讀 n 個元素；每堆固定數量的有界算術與更新，因此單次 test 成本與 n 成正比，即使 hours 已超過 h 仍繼續算完。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: The largest-pile loop visits n elements. A proposed speed also visits all n piles, /performing [a fixed number of] arithmetic and update operations for each, //so one test costs proportional to n. The code deliberately computes the complete total /even when it already exceeds h.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：此實作每個 test 完整走訪 n 堆，每堆工作數固定。 第 18 段 · 第 24 段適用前提：在 bounded-integer model 下，每次讀取、比較、算術與更新算 constant work。 第 23 段 · 第 24 段判讀時點：此處計數的是完成整個 pile-hours scan 的 test；沒有超過 h 就提前結束。 第 24 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why does one proposed-speed test cost proportional to n?

正文支撐及連結論證（完整精確段落）：

- `alg-p-17` EN: hours = 0 belongs inside the while loop because a new speed needs a new total. hours += ... adds to this scalar, not to the input list. The two assignments after the scan are the same two interval changes in the trace. All candidate speeds stay positive, so the division never has a zero divisor. There is no recursion, sorting, copied input, or saved history of probes.
  ZH: hours = 0 必須放在 while loop 裡，因為每個新速度都需要新的總和。hours += ... 加到這個 scalar，不是加到輸入 list。scan 後的兩個 assignment，就是前面 trace 中的兩種 interval 更新。所有候選速度都保持正值，所以不會出現零 divisor。這裡沒有 recursion、sorting、輸入副本，也不儲存歷次 probe。
- `alg-p-23` EN: The largest-pile loop visits n elements. A proposed speed also visits all n piles, performing a fixed number of arithmetic and update operations for each, so one test costs proportional to n. The code deliberately computes the complete total even when it already exceeds h.
  ZH: 尋找最大香蕉堆的 loop 走訪 n 個元素。測試一個候選速度也會走訪全部 n 堆，每堆執行固定數量的算術與更新，因此一次檢查的成本與 n 成正比。這份程式即使累計總和已超過 h，仍會刻意把總時數算完。
- `alg-p-22` EN: Use a bounded-integer cost model: reading a list element, comparing these integers, and doing arithmetic on values within this problem's limits each count as constant work. This compares growth in operation counts, not equal wall-clock time for every Python instruction. Pile sizes and speeds are at most 10^9, and an hours total is at most n * M <= 10^13, so their required numeric range is bounded. Python integers remain exact at these values; they do not wrap at a fixed machine limit. Python numeric types.
  ZH: 採用 bounded-integer cost model：讀取一個 list 元素、比較這些整數，以及對本題限制內的值做算術，都各算 constant work。這是在比較 operation count 的成長，不是宣稱每個 Python instruction 的實際耗時相同。香蕉堆大小和速度至多是 10^9，總時數至多是 n * M <= 10^13，因此需要的數值範圍有界。Python 的整數在這些值上保持精確，不會在固定的 machine limit 發生 wraparound。Python numeric types。

### 第 25 段 / alg-p-24 — PASS_BOUNDED

兩組大小、ceil(L/2)、11->6->3->2->1、t 次更新上界與初始 n scan 全保留，M=1 特例亦未刪。

相鄰不合法推論：ceil(log2 M) 是至多次數，不是每個輸入精確次數；O(n log M) 簡寫限 M>=2。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 何種 cost model 支持時間與空間界線？
- `alg-four-zh` [PASS_BOUNDED]: 任一更新後至多剩 ceil(L / 2) 候選，故至多 ceil(log2 M) 次 test；加上初始 n-element scan，總成本為 O(n * (1 + log M))。M = 1 仍需初始 scan。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: The lower middle splits an interval into a lower group /including mid and an upper group /excluding it. //With an even number L of candidates, each group has L / 2 members; //with an odd L, the lower group has one more member than the upper. Success keeps the lower group and failure keeps the upper, //so either update leaves at most ceil(L / 2) candidates. For example, an initial M = 11 gives worst-case size bounds 11 -> 6 -> 3 -> 2 -> 1. //After t halvings, at most ceil(M / 2^t) candidates remain. It suffices for 2^t to reach M; ceil(log2 M) is the smallest such whole number of halvings. //Thus the total work is at most a constant times n + n * ceil(log2 M), written O(n * (1 + log M)). //For M >= 2, the common shorthand is O(n log M). Keeping the initial n term explains the M = 1 case too. Since 2^30 > 10^9, the stated limits need at most thirty proposed-speed scans.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：初始有 M 個整數候選，更新分別保留下半組或上半組，最多 ceil(L / 2) 個。 第 11 段 · 第 13 段 · 第 25 段適用前提：初始 scan 有 n 次訪問；每次 proposed-speed scan 也有 n 次固定有界工作。 第 23 段 · 第 24 段判讀時點：完成 t 次 interval 更新後，候選數至多 ceil(M / 2^t)；降到 1 時停止。 第 25 段 · 第 20 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：How do scan cost and interval halving combine?

正文支撐及連結論證（完整精確段落）：

- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。
- `alg-p-12` EN: Choose mid = (low + high) // 2, the lower middle integer. When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
  ZH: 選擇 mid = (low + high) // 2，也就是偏下方的中間整數。當 T(mid) > h，設定 low = mid + 1：mid 和所有更小速度都已失敗。否則設定 high = mid：更大速度已無必要，但成功的 mid 仍須留作候選。當 low == high 時停止，回傳該數值。這種把有序候選範圍反覆減半的方法，就是 binary search。
- `alg-p-24` EN: The lower middle splits an interval into a lower group including mid and an upper group excluding it. With an even number L of candidates, each group has L / 2 members; with an odd L, the lower group has one more member than the upper. Success keeps the lower group and failure keeps the upper, so either update leaves at most ceil(L / 2) candidates. For example, an initial M = 11 gives worst-case size bounds 11 -> 6 -> 3 -> 2 -> 1. After t halvings, at most ceil(M / 2^t) candidates remain. It suffices for 2^t to reach M; ceil(log2 M) is the smallest such whole number of halvings. Thus the total work is at most a constant times n + n * ceil(log2 M), written O(n * (1 + log M)). For M >= 2, the common shorthand is O(n log M). Keeping the initial n term explains the M = 1 case too. Since 2^30 > 10^9, the stated limits need at most thirty proposed-speed scans.
  ZH: 偏下方的中間值把 interval 分成兩組：包含 mid 的下半組，以及不包含它的上半組。候選數 L 為偶數時，每組都有 L / 2 個；L 為奇數時，下半組比上半組多一個。成功保留下半組，失敗保留上半組，因此任一更新後都至多剩下 ceil(L / 2) 個候選。例如初始 M = 11 時，候選數的 worst-case 上界依序是 11 -> 6 -> 3 -> 2 -> 1。減半 t 次後，至多剩下 ceil(M / 2^t) 個候選。只要 2^t 達到 M 就足夠；ceil(log2 M) 就是滿足此條件的最小整數減半次數。因此，總工作量至多是某個常數乘上 n + n * ceil(log2 M)，記為 O(n * (1 + log M))。當 M >= 2，常見簡寫是 O(n log M)。保留起初的 n 這一項，也能說明 M = 1 的情況。因為 2^30 > 10^9，在題目限制內至多需要三十次候選速度的 scan。
- `alg-p-22` EN: Use a bounded-integer cost model: reading a list element, comparing these integers, and doing arithmetic on values within this problem's limits each count as constant work. This compares growth in operation counts, not equal wall-clock time for every Python instruction. Pile sizes and speeds are at most 10^9, and an hours total is at most n * M <= 10^13, so their required numeric range is bounded. Python integers remain exact at these values; they do not wrap at a fixed machine limit. Python numeric types.
  ZH: 採用 bounded-integer cost model：讀取一個 list 元素、比較這些整數，以及對本題限制內的值做算術，都各算 constant work。這是在比較 operation count 的成長，不是宣稱每個 Python instruction 的實際耗時相同。香蕉堆大小和速度至多是 10^9，總時數至多是 n * M <= 10^13，因此需要的數值範圍有界。Python 的整數在這些值上保持精確，不會在固定的 machine limit 發生 wraparound。Python numeric types。
- `alg-p-23` EN: The largest-pile loop visits n elements. A proposed speed also visits all n piles, performing a fixed number of arithmetic and update operations for each, so one test costs proportional to n. The code deliberately computes the complete total even when it already exceeds h.
  ZH: 尋找最大香蕉堆的 loop 走訪 n 個元素。測試一個候選速度也會走訪全部 n 堆，每堆執行固定數量的算術與更新，因此一次檢查的成本與 n 成正比。這份程式即使累計總和已超過 h，仍會刻意把總時數算完。
- `alg-p-19` EN: When low < high, the lower middle satisfies low <= mid < high. In the failure branch the lower endpoint strictly increases; in the success branch the upper endpoint strictly decreases. The interval stays nonempty and has fewer integer candidates, so it must eventually contain one candidate. The invariant then says that this sole candidate is the minimum feasible speed. Returning low is justified even if that exact speed was not separately tested after the final update.
  ZH: 當 low < high，偏下方的中間值滿足 low <= mid < high。失敗 branch 嚴格提高 lower endpoint；成功 branch 嚴格降低 upper endpoint。interval 維持非空，整數候選卻變少，因此最後一定只剩一個候選。invariant 此時保證這個唯一候選就是最小可行速度。即使最後一次更新後沒有另外測試那個確切速度，回傳 low 仍有根據。

### 第 26 段 / alg-p-25 — PASS_BOUNDED

固定 live scalar、traversal state、暫時 bounded values，排除 caller input；單整數 output 與任意長整數例外都有。

相鄰不合法推論：固定變數數量不單獨授權無界整數 O(1) bytes；未把輸入大小或 history 算成不存在。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 何種 cost model 支持時間與空間界線？
- `alg-four-zh` [PASS_BOUNDED]: 此實作只保留固定數量 scalar 與 traversal state，更新取代舊值；bounded-integer model 下 auxiliary 與單整數 output 都是 O(1)，排除輸入 list。任意長整數需另算 bit-size。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Only a fixed number of scalars and a loop's traversal state [remain live]. Reassigning hours or an endpoint replaces its previous value; //it does not retain one entry per pile or per iteration. Auxiliary space is therefore O(1) in the same bounded-integer model, /excluding the supplied input list. Temporary arithmetic results add only a fixed number of bounded values. The returned output is one integer, also O(1) space /under this model. //If arbitrary-length integer inputs replaced the stated limits, arithmetic and integer storage would need a separate bit-size analysis; the scalar model here does not claim otherwise.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：本文程式不複製輸入、不存 probes 或逐堆貢獻 list。 第 8 段 · 第 18 段適用前提：整數大小受本題限制，auxiliary space 不包含呼叫者提供的 input list。 第 23 段 · 第 26 段判讀時點：任一時點只計仍存活的固定數量 scalar、traversal state 與暫時 bounded values；舊值不保留成 history。 第 26 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：What remains live, and which storage convention is used?

正文支撐及連結論證（完整精確段落）：

- `alg-p-7` EN: At k = 4 on [3, 6, 7, 11], an accumulator named hours starts at zero. The first pile contributes (3 + 3) // 4 = 1, changing hours to 1. The next contributes 2, changing it to 3; the next contributes 2, changing it to 5; the last contributes 3, changing it to 8. The calculation stores a running total, without allocating a list of all four contributions or changing the piles.
  ZH: 以 k = 4 處理 [3, 6, 7, 11] 時，名為 hours 的 accumulator 從零開始。第一堆貢獻 (3 + 3) // 4 = 1，讓 hours 變成 1。下一堆貢獻 2，讓它變成 3；再下一堆貢獻 2，讓它變成 5；最後一堆貢獻 3，讓它變成 8。計算只保留累計總和，不會為這四個貢獻值另建 list，也不會改動香蕉堆。
- `alg-p-17` EN: hours = 0 belongs inside the while loop because a new speed needs a new total. hours += ... adds to this scalar, not to the input list. The two assignments after the scan are the same two interval changes in the trace. All candidate speeds stay positive, so the division never has a zero divisor. There is no recursion, sorting, copied input, or saved history of probes.
  ZH: hours = 0 必須放在 while loop 裡，因為每個新速度都需要新的總和。hours += ... 加到這個 scalar，不是加到輸入 list。scan 後的兩個 assignment，就是前面 trace 中的兩種 interval 更新。所有候選速度都保持正值，所以不會出現零 divisor。這裡沒有 recursion、sorting、輸入副本，也不儲存歷次 probe。
- `alg-p-22` EN: Use a bounded-integer cost model: reading a list element, comparing these integers, and doing arithmetic on values within this problem's limits each count as constant work. This compares growth in operation counts, not equal wall-clock time for every Python instruction. Pile sizes and speeds are at most 10^9, and an hours total is at most n * M <= 10^13, so their required numeric range is bounded. Python integers remain exact at these values; they do not wrap at a fixed machine limit. Python numeric types.
  ZH: 採用 bounded-integer cost model：讀取一個 list 元素、比較這些整數，以及對本題限制內的值做算術，都各算 constant work。這是在比較 operation count 的成長，不是宣稱每個 Python instruction 的實際耗時相同。香蕉堆大小和速度至多是 10^9，總時數至多是 n * M <= 10^13，因此需要的數值範圍有界。Python 的整數在這些值上保持精確，不會在固定的 machine limit 發生 wraparound。Python numeric types。
- `alg-p-25` EN: Only a fixed number of scalars and a loop's traversal state remain live. Reassigning hours or an endpoint replaces its previous value; it does not retain one entry per pile or per iteration. Auxiliary space is therefore O(1) in the same bounded-integer model, excluding the supplied input list. Temporary arithmetic results add only a fixed number of bounded values. The returned output is one integer, also O(1) space under this model. If arbitrary-length integer inputs replaced the stated limits, arithmetic and integer storage would need a separate bit-size analysis; the scalar model here does not claim otherwise.
  ZH: 同時存活的只有固定數量的 scalar 和 loop 的 traversal state。重新賦值給 hours 或 endpoint，會取代前一個值，不會為每堆或每次 iteration 保留一筆紀錄。因此，在相同 bounded-integer model 下，auxiliary space 是 O(1)，不計入呼叫者提供的輸入 list。暫時算術結果也只增加固定數量的有界數值。回傳 output 是一個整數，在此模型下同樣使用 O(1) 空間。如果把題目限制換成任意長度的整數輸入，算術和整數儲存就需要另做 bit-size analysis；這裡的 scalar model 並未宣稱涵蓋那種情況。

### 第 27 段 / alg-p-26 — PASS_BOUNDED

按1到a逐一完整test提供首成功最小；n*a 計數、a<=M及一堆 M,h=1 的反例支撐所述上界；tiny fixed M 與無 speed 保證都保留。

相鄰不合法推論：小 M 支持簡單 control flow，不能推出速度必優於 binary search；沒有用對數 scan 數替代 a。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive + Active · 何時逐一測 speed 是合理簡化？
- `alg-four-zh` [PASS_BOUNDED]: Ascending search 逐一拒絕 1 到 a - 1，故首個成功 a 最小；共 a 次完整 scan，即 n * a visits，worst case O(nM)。重用 accumulator 保持 O(1) space；M 很小時 control flow 較簡單，但未保證較快。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: An ascending search can try k = 1, 2, 3, ... and return the first speed /whose complete pile-hours scan passes. It keeps only the current speed and running total, plus the largest-pile bound if used. All earlier speeds have been explicitly rejected, //so its first success is minimal. //If the answer is a, it performs a scans of n elements, or n * a pile visits; //since a <= M, its worst-case time is O(nM). A single pile of size M with h = 1 forces it to test every speed through M. Reusing the accumulator on each scan keeps auxiliary and output space O(1) /under the same numeric model. //If a changed task guaranteed that M was a tiny fixed value, ascending search would be a reasonable choice for its simpler [control flow]; it has no speed advantage promised here. At M up to a billion, skipping ranges is the useful difference.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：沿用原題的 per-pile hours test 與可行上界 a <= M。 第 2 段 · 第 7 段 · 第 11 段適用前提：一個完整 scan 有 n 次固定有界工作；ascending search 不儲存歷次結果。 第 23 段 · 第 24 段 · 第 27 段適用前提：M 為很小固定值是本段替代選擇的改題條件；單堆 M、h = 1 可迫使測試到 M。 第 27 段判讀時點：從 k = 1 依序測試到第一次成功 a；停止前所有更小 speed 已明確失敗。 第 27 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：When is ascending search a reasonable simpler alternative?
- `alg-active-word` [PASS_BOUNDED]: ascending searchAscending search performs a complete n-pile scan for each speed through the first successful speed a, for n * a pile visits.
- `alg-supporting-sources` [PASS_BOUNDED]: 推導前提：第 7 段 · 第 11 段 · 第 23 段 · 第 24 段 · 第 27 段
- `alg-four-recall` [PASS_BOUNDED]: Active · 自行表達後核對Compare ascending search with range skipping.Oracle · 嘗試後展開All earlier speeds are explicitly rejected, so first success is minimal. Since a <= M, worst-case time is O(nM), reached by one pile M with h = 1. It reuses scalar state under the same bounded model. Tiny fixed M can justify simpler control flow, without a speed guarantee.

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。
- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。
- `alg-p-22` EN: Use a bounded-integer cost model: reading a list element, comparing these integers, and doing arithmetic on values within this problem's limits each count as constant work. This compares growth in operation counts, not equal wall-clock time for every Python instruction. Pile sizes and speeds are at most 10^9, and an hours total is at most n * M <= 10^13, so their required numeric range is bounded. Python integers remain exact at these values; they do not wrap at a fixed machine limit. Python numeric types.
  ZH: 採用 bounded-integer cost model：讀取一個 list 元素、比較這些整數，以及對本題限制內的值做算術，都各算 constant work。這是在比較 operation count 的成長，不是宣稱每個 Python instruction 的實際耗時相同。香蕉堆大小和速度至多是 10^9，總時數至多是 n * M <= 10^13，因此需要的數值範圍有界。Python 的整數在這些值上保持精確，不會在固定的 machine limit 發生 wraparound。Python numeric types。
- `alg-p-23` EN: The largest-pile loop visits n elements. A proposed speed also visits all n piles, performing a fixed number of arithmetic and update operations for each, so one test costs proportional to n. The code deliberately computes the complete total even when it already exceeds h.
  ZH: 尋找最大香蕉堆的 loop 走訪 n 個元素。測試一個候選速度也會走訪全部 n 堆，每堆執行固定數量的算術與更新，因此一次檢查的成本與 n 成正比。這份程式即使累計總和已超過 h，仍會刻意把總時數算完。
- `alg-p-26` EN: An ascending search can try k = 1, 2, 3, ... and return the first speed whose complete pile-hours scan passes. It keeps only the current speed and running total, plus the largest-pile bound if used. All earlier speeds have been explicitly rejected, so its first success is minimal. If the answer is a, it performs a scans of n elements, or n * a pile visits; since a <= M, its worst-case time is O(nM). A single pile of size M with h = 1 forces it to test every speed through M. Reusing the accumulator on each scan keeps auxiliary and output space O(1) under the same numeric model. If a changed task guaranteed that M was a tiny fixed value, ascending search would be a reasonable choice for its simpler control flow; it has no speed advantage promised here. At M up to a billion, skipping ranges is the useful difference.
  ZH: Ascending search 可以依序嘗試 k = 1, 2, 3, ...，每次完整 scan 各堆的小時數，遇到第一個成功速度就回傳。它只保留當前速度、累計總和，以及選擇使用時的最大香蕉堆上界。之前所有速度都已明確被拒絕，因此第一次成功就是最小值。如果答案是 a，它會對 n 個元素 scan 共 a 次，也就是走訪 n * a 堆；因為 a <= M，worst-case time 是 O(nM)。單獨一堆大小為 M 的香蕉、h = 1，就會迫使它測試從 1 到 M 的每個速度。每次 scan 重用 accumulator，讓 auxiliary 和 output space 在相同 numeric model 下維持 O(1)。若改題後保證 M 是很小的固定值，ascending search 因為 control flow 較簡單，會是合理選擇；這裡沒有承諾它比較快。當 M 可達十億時，跳過整段候選才是有用的差別。

### 第 28 段 / alg-p-27 — NEEDS_REVISION

跨堆可達容量機制、positive h、S定義與 bounded pass 成本都完整；但 zh_note 的「只有…才」新增必要規則變更，超出正文 conditional。

相鄰不合法推論：改題規則使總量公式對該改題普遍成立，不等於原題每一個實例都必須先改規則才可能有同一判準。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive + Active · 哪個規則改變讓總量公式成立？
- `alg-four-zh` [NEEDS_REVISION]: 只有改成一小時內可跨堆用滿容量，h * k >= S 才既必要又充分，答案為 ceiling(S / h)。單次累加 S 加固定算術為 O(n) time、O(1) auxiliary；原題 [4,4] 不允許這種 pooling。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: A different hourly rule changes the calculation more substantially. //Suppose Koko could switch piles within an hour /and use the entire capacity k across them. Let S be the total banana count. In that changed task, h hours can consume at most h * k bananas, //and continuously taking bananas across pile boundaries can achieve that capacity until the supply ends. //Therefore h * k >= S is [sufficient as well as necessary], and the minimum integer speed is (S + h - 1) // h. A single pass adds each pile to S, followed by a fixed amount of arithmetic: O(n) time, O(1) auxiliary space, and one integer output /under the same bounded model. No per-pile hours or candidate searches remain. This formula fails for the original [4, 4], h = 3 //precisely because that original task does not allow switching piles mid-hour.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：此段另假設同小時可換堆並把容量 k 用在多堆，與原題規則不同。 第 2 段 · 第 28 段適用前提：跨堆連續取香蕉可達 h * k 容量直到供應用盡；S 為總數，h 為正。 第 3 段 · 第 28 段適用前提：單次 pass 各堆加到 S、再做固定算術；沿用 bounded-integer model。 第 23 段 · 第 28 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Which changed rule makes the total-capacity formula sufficient?
- `alg-active-word` [PASS_BOUNDED]: capacityIf Koko may switch piles within an hour and use the entire capacity across them, h * k >= S is sufficient as well as necessary.
- `alg-supporting-sources` [PASS_BOUNDED]: 推導前提：第 2 段 · 第 3 段 · 第 4 段 · 第 6 段 · 第 23 段 · 第 28 段
- `alg-four-recall` [PASS_BOUNDED]: Active · 自行表達後核對State the changed rule and derive the new minimum speed.Oracle · 嘗試後展開Only the changed task permits mid-hour pile switches. Its h * k capacity bounds total consumption and can be attained across pile boundaries until bananas run out, so the minimum integer k is (S + h - 1) // h. One n-pile sum and fixed bounded arithmetic cost O(n) time and O(1) auxiliary space. Original [4, 4], h = 3 forbids pooling.

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-27` EN: A different hourly rule changes the calculation more substantially. Suppose Koko could switch piles within an hour and use the entire capacity k across them. Let S be the total banana count. In that changed task, h hours can consume at most h * k bananas, and continuously taking bananas across pile boundaries can achieve that capacity until the supply ends. Therefore h * k >= S is sufficient as well as necessary, and the minimum integer speed is (S + h - 1) // h. A single pass adds each pile to S, followed by a fixed amount of arithmetic: O(n) time, O(1) auxiliary space, and one integer output under the same bounded model. No per-pile hours or candidate searches remain. This formula fails for the original [4, 4], h = 3 precisely because that original task does not allow switching piles mid-hour.
  ZH: 另一種每小時規則，會更大幅地改變計算。假設 Koko 能在一小時內切換香蕉堆，把完整容量 k 用在多堆之間。令 S 是香蕉總數。在這個改題版本中，h 小時至多能吃 h * k 根；持續跨堆取香蕉，也能在香蕉吃完前用滿這個容量。因此，h * k >= S 既是必要條件，也是充分條件，最小整數速度便是 (S + h - 1) // h。只需一次 pass 把每堆加到 S，再做固定數量的算術：在相同 bounded model 下，time 是 O(n)、auxiliary space 是 O(1)，output 是一個整數。不再需要逐堆的小時數或候選搜尋。這個公式套在原題的 [4, 4], h = 3 會失敗，正是因為原題不允許在一小時中途換堆。
- `alg-p-2` EN: The constraints are 1 <= n <= 10^4, n <= h <= 10^9, and 1 <= piles[i] <= 10^9, where n is the number of piles. Every pile needs at least one hour, so h >= n matters: the problem guarantees that a sufficiently large speed can work. The solution below only reads the input list; it neither sorts nor changes its elements. Empty lists and h < n are outside this contract. Problem statement and constraints.
  ZH: 限制是 1 <= n <= 10^4、n <= h <= 10^9，以及 1 <= piles[i] <= 10^9，其中 n 是香蕉堆數。每堆至少需要一小時，因此 h >= n 很重要：題目保證速度夠大就一定能完成。下面的解法只讀取輸入 list，不排序，也不改動其中的元素。空 list 和 h < n 不在這份 contract 內。題目敘述與限制。
- `alg-p-22` EN: Use a bounded-integer cost model: reading a list element, comparing these integers, and doing arithmetic on values within this problem's limits each count as constant work. This compares growth in operation counts, not equal wall-clock time for every Python instruction. Pile sizes and speeds are at most 10^9, and an hours total is at most n * M <= 10^13, so their required numeric range is bounded. Python integers remain exact at these values; they do not wrap at a fixed machine limit. Python numeric types.
  ZH: 採用 bounded-integer cost model：讀取一個 list 元素、比較這些整數，以及對本題限制內的值做算術，都各算 constant work。這是在比較 operation count 的成長，不是宣稱每個 Python instruction 的實際耗時相同。香蕉堆大小和速度至多是 10^9，總時數至多是 n * M <= 10^13，因此需要的數值範圍有界。Python 的整數在這些值上保持精確，不會在固定的 machine limit 發生 wraparound。Python numeric types。
- `alg-p-3` EN: For a small example, take piles = [4, 4] and h = 3. Speed 3 takes two hours per pile, four hours total. Speed 4 takes one hour per pile, two hours total. The answer is 4, even though dividing eight bananas by three hours and rounding up suggests 3. That shortcut spends spare capacity from one pile on another, which the hourly rule forbids.
  ZH: 看一個小例子：piles = [4, 4]、h = 3。速度 3 讓每堆各花兩小時，總共四小時。速度 4 讓每堆各花一小時，總共兩小時。答案是 4，儘管把八根香蕉除以三小時再向上取整，會得到 3。這個捷徑把一堆剩下的處理容量挪給另一堆，違反每小時的規則。
- `alg-p-5` EN: Python's integer // operator rounds a quotient downward. For positive integers, (p + k - 1) // k instead gives the required upward rounding. To see why, write p = q * k + r, where q is the number of full groups and the remainder r satisfies 0 <= r < k. When r = 0, adding k - 1 still leaves the quotient at q. When r > 0, r + k - 1 lies between k and 2 * k - 2, so the quotient becomes q + 1. Both cases count exactly the hours needed. Python arithmetic semantics.
  ZH: Python 的整數 // 運算會把商向下取整。對正整數而言，(p + k - 1) // k 則能得到需要的向上取整結果。原因可以從 p = q * k + r 看出，其中 q 是完整組數，remainder r 滿足 0 <= r < k。當 r = 0，加上 k - 1 後，整數商仍是 q。當 r > 0，r + k - 1 落在 k 到 2 * k - 2 之間，整數商便成為 q + 1。兩種情況都恰好算出需要的小時數。Python 算術語意。

### 第 29 段 / alg-p-28 — PASS_BOUNDED

練習輸入及起始範圍固定；linked monotonicity/interval 更新支撐對未逐測候選的排除理由，cue 是問題。

相鄰不合法推論：未把練習的要求等同學習者已具備能力；不能只背 assignment 形式便省略排除理由。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: 練習用 [2,5]、h = 4 從 [1,5] 重建每次 speed、總 hours 與 endpoints；重點是用 monotonicity 解釋為何可排除未逐一測試的速度。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: For piles = [2, 5] and h = 4, start from [1, 5]. //Before checking the result, reconstruct the proposed speeds, each hours total, and both endpoint updates. Ask what makes removing the untested smaller speeds valid, /[rather than] only remembering an assignment pattern.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：本練習固定 piles = [2, 5]、h = 4，使用原題的逐堆 hours test。 第 29 段 · 第 2 段 · 第 7 段適用前提：排除範圍需依 monotonicity 與既有 interval 更新，不只是記 assignment。 第 9 段 · 第 13 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：What justifies discarding an untested smaller speed?

正文支撐及連結論證（完整精確段落）：

- `alg-p-28` EN: For piles = [2, 5] and h = 4, start from [1, 5]. Before checking the result, reconstruct the proposed speeds, each hours total, and both endpoint updates. Ask what makes removing the untested smaller speeds valid, rather than only remembering an assignment pattern.
  ZH: 對 piles = [2, 5]、h = 4，從 [1, 5] 開始。在看答案前，試著重建候選速度、每次總時數，以及兩個 endpoint 的更新。問自己：為什麼能移除那些未逐一測試的更小速度，而不是只記住 assignment 的形式？
- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。
- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-12` EN: Choose mid = (low + high) // 2, the lower middle integer. When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
  ZH: 選擇 mid = (low + high) // 2，也就是偏下方的中間整數。當 T(mid) > h，設定 low = mid + 1：mid 和所有更小速度都已失敗。否則設定 high = mid：更大速度已無必要，但成功的 mid 仍須留作候選。當 low == high 時停止，回傳該數值。這種把有序候選範圍反覆減半的方法，就是 binary search。

### 第 30 段 / alg-p-29 — PASS_BOUNDED

generated/source trace 的 mid 3,2,1、hours 3,4,7、端點 [1,3],[1,2],[2,2] 全保留；最後移除1有 invariant 支持最小2。

相鄰不合法推論：最後一次失敗不是證明2可行的唯一依據；可行性由一直維持的 high/invariant 保留。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: 本例依序測 mid 3、2、1，hours 為 3、4、7；interval 由 [1,5] 經 [1,3]、[1,2] 到 [2,2]，由最後一次失敗排除 1，回傳 2。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: The reconstruction is [1, 5] -> mid 3 -> 1 + 2 = 3 -> [1, 3]; //then mid 2 -> 1 + 3 = 4 -> [1, 2]; //then mid 1 -> 2 + 5 = 7 -> [2, 2], returning 2. //[The last failure] removes 1, and the maintained interval leaves only 2.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：輸入固定為 [2, 5]、h = 4；每堆分別取 ceiling 並相加。 第 29 段 · 第 5 段 · 第 7 段適用前提：成功保留 mid，失敗排除 mid 以下；invariant 保留最小 feasible speed。 第 12 段 · 第 13 段判讀時點：依原文 trace 完成三次 endpoint 更新後 [2,2] 只剩候選 2。 第 30 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：How does the final failed probe leave a minimum of 2?

正文支撐及連結論證（完整精確段落）：

- `alg-p-28` EN: For piles = [2, 5] and h = 4, start from [1, 5]. Before checking the result, reconstruct the proposed speeds, each hours total, and both endpoint updates. Ask what makes removing the untested smaller speeds valid, rather than only remembering an assignment pattern.
  ZH: 對 piles = [2, 5]、h = 4，從 [1, 5] 開始。在看答案前，試著重建候選速度、每次總時數，以及兩個 endpoint 的更新。問自己：為什麼能移除那些未逐一測試的更小速度，而不是只記住 assignment 的形式？
- `alg-p-4` EN: For a pile of size p at speed k, count complete groups of k bananas. If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer at least as large as that quotient. For p = 11 and k = 4, the groups are 4, 4, 3, so the pile takes three hours.
  ZH: 對大小為 p 的一堆香蕉，以速度 k 進食，先數出完整的 k 根一組有幾組。若還有剩餘香蕉，就需要額外一個完整小時。這個數量是 p / k 的 ceiling，也就是不小於該商的最小整數。例如 p = 11、k = 4，會分成 4, 4, 3，因此需要三小時。
- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。
- `alg-p-11` EN: At the start of every search iteration, maintain this invariant: The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. Here feasible means that the speed passes the hours test. The monotone property describes the problem's answers across all speeds; the invariant describes what the current search state still guarantees.
  ZH: 在每次 search iteration 開始時，維持這個 invariant：The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. 意思是最小可行速度仍在包含兩端的 [low, high] 裡，而且 high 本身可行。這裡 feasible 指速度通過小時數檢查。monotone 性質描述所有速度的答案如何變化；invariant 描述目前搜尋狀態仍保證哪些事。
- `alg-p-12` EN: Choose mid = (low + high) // 2, the lower middle integer. When T(mid) > h, set low = mid + 1: mid and every smaller speed have failed. Otherwise set high = mid: larger speeds are unnecessary, but the successful mid must remain a candidate. Stop when low == high and return that value. This repeated halving of an ordered candidate range is binary search.
  ZH: 選擇 mid = (low + high) // 2，也就是偏下方的中間整數。當 T(mid) > h，設定 low = mid + 1：mid 和所有更小速度都已失敗。否則設定 high = mid：更大速度已無必要，但成功的 mid 仍須留作候選。當 low == high 時停止，回傳該數值。這種把有序候選範圍反覆減半的方法，就是 binary search。
- `alg-p-29` EN: The reconstruction is [1, 5] -> mid 3 -> 1 + 2 = 3 -> [1, 3]; then mid 2 -> 1 + 3 = 4 -> [1, 2]; then mid 1 -> 2 + 5 = 7 -> [2, 2], returning 2. The last failure removes 1, and the maintained interval leaves only 2.
  ZH: 重建結果是 [1, 5] -> mid 3 -> 1 + 2 = 3 -> [1, 3]；接著 mid 2 -> 1 + 3 = 4 -> [1, 2]；再來 mid 1 -> 2 + 5 = 7 -> [2, 2]，回傳 2。最後一次失敗排除 1，而一直維持的 interval 只剩 2。

### 第 31 段 / alg-p-30 — PASS_BOUNDED

ordered 物件為正整數 speeds，原題 per-pile hours 判準與 T 非增加充分給出 feasibility 方向；context 特別排除每次切換。

相鄰不合法推論：false-to-true 是允許的變化方向，不主張必須存在 failing prefix 或每步都轉換；不要求 piles 已排序。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 為何可跳過未逐一測試的速度？
- `alg-four-zh` [PASS_BOUNDED]: 面試回答要把搜尋對象說清楚：有序的是正整數 speeds，並非 piles 位置；T(k) 不增加讓 feasibility 不會由 true 回到 false，所以不需先排序 piles。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Why can we use binary search /without sorting the piles? "We search [integer speeds], /not pile positions. Increasing the speed cannot increase the required hours, //so feasibility changes only from false to true."
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：speed 為正整數；每個 speed 的判準是 T(k) <= h。 第 2 段 · 第 7 段適用前提：T(k) 不增加，失敗前綴可能為空；不必每次增加 k 都切換 feasibility。 第 9 段 · 第 31 段適用前提：interval 的 endpoints 是 speeds，非 piles indices。 第 11 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：What is ordered when the piles are unsorted?

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。
- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-30` EN: Why can we use binary search without sorting the piles? "We search integer speeds, not pile positions. Increasing the speed cannot increase the required hours, so feasibility changes only from false to true."
  ZH: Why can we use binary search without sorting the piles? "We search integer speeds, not pile positions. Increasing the speed cannot increase the required hours, so feasibility changes only from false to true."
- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。

### 第 32 段 / alg-p-31 — PASS_BOUNDED

whole-hour remainder、不能跨堆移容量，另有 linked 下界與可達性，支撐所需時間恰為 per-pile ceilings 和。

相鄰不合法推論：不是 ceiling(sum/k)；只有下界不足以稱 exact required time，但正文已給逐堆構造。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何精確測試一個 speed？
- `alg-four-zh` [PASS_BOUNDED]: 面試回答把 remainder 與小時歸屬連起來：未完成的一堆要再佔完整小時，不能把剩餘容量挪走，所以總時數是 per-pile ceilings 的和。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: Why do we round each pile upward? "An unfinished remainder takes a whole hour, //and unused capacity cannot move to another pile /in that hour. The required time is the sum of the [per-pile ceilings]."
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：原題每小時只處理一堆；單堆 remainder 要額外完整小時。 第 2 段 · 第 5 段適用前提：逐堆小時下界可由逐堆完成達到，故總和是正確所需時間。 第 7 段 · 第 32 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Why sum per-pile ceilings instead of pooling all bananas?

正文支撐及連結論證（完整精確段落）：

- `alg-p-1` EN: In LeetCode 875, piles is a nonempty list of positive pile sizes. Koko chooses one positive integer speed k, measured in bananas per hour. During each hour she eats from one pile. Finishing that pile early does not let her start another pile during the same hour. Return the smallest speed that finishes all piles in at most h hours.
  ZH: 在 LeetCode 875 中，piles 是非空 list，裡面每個正整數代表一堆香蕉的數量。Koko 選定一個正整數速度 k，單位是每小時吃掉幾根香蕉。每小時她只能吃其中一堆；提早吃完那堆，也不能在同一小時開始吃另一堆。要求回傳能在至多 h 小時內吃完所有香蕉的最小速度。
- `alg-p-4` EN: For a pile of size p at speed k, count complete groups of k bananas. If some bananas remain, they need another whole hour. This count is the ceiling of p / k: the smallest integer at least as large as that quotient. For p = 11 and k = 4, the groups are 4, 4, 3, so the pile takes three hours.
  ZH: 對大小為 p 的一堆香蕉，以速度 k 進食，先數出完整的 k 根一組有幾組。若還有剩餘香蕉，就需要額外一個完整小時。這個數量是 p / k 的 ceiling，也就是不小於該商的最小整數。例如 p = 11、k = 4，會分成 4, 4, 3，因此需要三小時。
- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。
- `alg-p-31` EN: Why do we round each pile upward? "An unfinished remainder takes a whole hour, and unused capacity cannot move to another pile in that hour. The required time is the sum of the per-pile ceilings."
  ZH: Why do we round each pile upward? "An unfinished remainder takes a whole hour, and unused capacity cannot move to another pile in that hour. The required time is the sum of the per-pile ceilings."

### 第 33 段 / alg-p-32 — PASS_BOUNDED

兩個 invariant clauses、失敗移除方向與成功保留 mid 均正確；context 對每 branch 更新到 singleton 的時點有正文 proof。

相鄰不合法推論：成功並不讓整個 interval 每個候選都可行；沒有由單次成功就推出最小。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 如何保留最小答案並確保終止？
- `alg-four-zh` [PASS_BOUNDED]: 面試回答要同時保留「最小值仍在 inclusive interval」與「high 可行」。失敗 mid 及更小者被移除；成功 mid 留下，避免丟掉可能的最小值。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: What does the search invariant guarantee? "The minimum feasible speed remains in the inclusive interval, //and the [upper endpoint] is feasible. A failed midpoint removes itself and all smaller speeds; //a feasible midpoint stays in the interval."
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：當前 iteration 開始時最小 feasible speed 在 interval，且 high 可行。 第 12 段適用前提：monotonicity 支持兩分支的排除方向；不是只憑某次 probe 結果宣稱最小。 第 9 段 · 第 19 段 · 第 33 段判讀時點：每個 branch 更新完成後兩項 invariant 都成立，直到 low == high。 第 19 段 · 第 20 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Which success candidate must remain after the interval update?

正文支撐及連結論證（完整精確段落）：

- `alg-p-11` EN: At the start of every search iteration, maintain this invariant: The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. Here feasible means that the speed passes the hours test. The monotone property describes the problem's answers across all speeds; the invariant describes what the current search state still guarantees.
  ZH: 在每次 search iteration 開始時，維持這個 invariant：The minimum feasible speed lies in the inclusive interval [low, high], and high is feasible. 意思是最小可行速度仍在包含兩端的 [low, high] 裡，而且 high 本身可行。這裡 feasible 指速度通過小時數檢查。monotone 性質描述所有速度的答案如何變化；invariant 描述目前搜尋狀態仍保證哪些事。
- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-18` EN: Initially, the answer lies between 1 and M, and M is feasible. Suppose the invariant holds before an iteration. If mid fails, monotonicity excludes all speeds at most mid, so the answer remains in [mid + 1, high]; the unchanged high remains feasible. If mid succeeds, some feasible speed is now known at mid. The minimum therefore lies in [low, mid], and assigning high = mid keeps the upper endpoint feasible. Each branch preserves both parts of the invariant.
  ZH: 一開始，答案在 1 到 M 之間，而且 M 可行。假設某次 iteration 開始前 invariant 成立。如果 mid 失敗，monotonicity 排除所有至多為 mid 的速度，因此答案仍在 [mid + 1, high]；未變動的 high 仍然可行。如果 mid 成功，我們便知道 mid 是一個可行速度。最小值因此落在 [low, mid]，設定 high = mid 也讓 upper endpoint 保持可行。兩個 branch 都保留 invariant 的兩項保證。
- `alg-p-32` EN: What does the search invariant guarantee? "The minimum feasible speed remains in the inclusive interval, and the upper endpoint is feasible. A failed midpoint removes itself and all smaller speeds; a feasible midpoint stays in the interval."
  ZH: What does the search invariant guarantee? "The minimum feasible speed remains in the inclusive interval, and the upper endpoint is feasible. A failed midpoint removes itself and all smaller speeds; a feasible midpoint stays in the interval."
- `alg-p-19` EN: When low < high, the lower middle satisfies low <= mid < high. In the failure branch the lower endpoint strictly increases; in the success branch the upper endpoint strictly decreases. The interval stays nonempty and has fewer integer candidates, so it must eventually contain one candidate. The invariant then says that this sole candidate is the minimum feasible speed. Returning low is justified even if that exact speed was not separately tested after the final update.
  ZH: 當 low < high，偏下方的中間值滿足 low <= mid < high。失敗 branch 嚴格提高 lower endpoint；成功 branch 嚴格降低 upper endpoint。interval 維持非空，整數候選卻變少，因此最後一定只剩一個候選。invariant 此時保證這個唯一候選就是最小可行速度。即使最後一次更新後沒有另外測試那個確切速度，回傳 low 仍有根據。

### 第 34 段 / alg-p-33 — PASS_BOUNDED

n/M 定義、有界算術、initial/probe 全scan、halving及live state 證據都在 context links；英文成本包括1+log M。

相鄰不合法推論：不是只報O記號而無計數，也未去掉 M=1 的初始scan或把input列為auxiliary。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 何種 cost model 支持時間與空間界線？
- `alg-four-zh` [PASS_BOUNDED]: 面試成本回答需連上推導：初始 scan、每次 n 堆 test、至多 ceil(log2 M) 次減半，得到 O(n * (1 + log M))；固定 scalar 在 bounded-integer model 下用 O(1) auxiliary。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: What is the cost? "Finding the maximum takes one scan. //Each midpoint takes another scan, //and halving the candidate range needs at most ceiling log base two of the largest pile. The total is O(n times (1 plus log M)), /with [constant auxiliary space] /under the bounded-integer model."
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：n 是堆數，M 是最大堆；每次有界算術算 constant work。 第 3 段 · 第 11 段 · 第 23 段適用前提：初始與每個 probe 都完整 scan n 堆，候選反覆減半至一個。 第 24 段 · 第 25 段適用前提：固定 scalar 與 traversal state 不保留 history；input 不算 auxiliary。 第 26 段 · 第 34 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Which three counts support the stated time bound?

正文支撐及連結論證（完整精確段落）：

- `alg-p-2` EN: The constraints are 1 <= n <= 10^4, n <= h <= 10^9, and 1 <= piles[i] <= 10^9, where n is the number of piles. Every pile needs at least one hour, so h >= n matters: the problem guarantees that a sufficiently large speed can work. The solution below only reads the input list; it neither sorts nor changes its elements. Empty lists and h < n are outside this contract. Problem statement and constraints.
  ZH: 限制是 1 <= n <= 10^4、n <= h <= 10^9，以及 1 <= piles[i] <= 10^9，其中 n 是香蕉堆數。每堆至少需要一小時，因此 h >= n 很重要：題目保證速度夠大就一定能完成。下面的解法只讀取輸入 list，不排序，也不改動其中的元素。空 list 和 h < n 不在這份 contract 內。題目敘述與限制。
- `alg-p-10` EN: Let M be the largest pile. Speed M clears every pile in one hour, using exactly n hours, which fits the guaranteed h >= n. No positive answer lies below 1, and an answer exists by M, so start with the inclusive interval [low, high] = [1, M]. These numbers are speeds, not indices into piles; no sorted pile list or stored list of candidates is needed.
  ZH: 令 M 是最大那堆的大小。速度 M 能在一小時內吃完任一堆，總共恰好需要 n 小時，符合題目保證的 h >= n。正整數答案不可能低於 1，而最遲在 M 就有答案，所以從 inclusive interval [low, high] = [1, M] 開始。這兩個數字表示速度，不是 piles 的 index；不需要已排序的香蕉堆 list，也不需要儲存所有候選速度的 list。
- `alg-p-22` EN: Use a bounded-integer cost model: reading a list element, comparing these integers, and doing arithmetic on values within this problem's limits each count as constant work. This compares growth in operation counts, not equal wall-clock time for every Python instruction. Pile sizes and speeds are at most 10^9, and an hours total is at most n * M <= 10^13, so their required numeric range is bounded. Python integers remain exact at these values; they do not wrap at a fixed machine limit. Python numeric types.
  ZH: 採用 bounded-integer cost model：讀取一個 list 元素、比較這些整數，以及對本題限制內的值做算術，都各算 constant work。這是在比較 operation count 的成長，不是宣稱每個 Python instruction 的實際耗時相同。香蕉堆大小和速度至多是 10^9，總時數至多是 n * M <= 10^13，因此需要的數值範圍有界。Python 的整數在這些值上保持精確，不會在固定的 machine limit 發生 wraparound。Python numeric types。
- `alg-p-23` EN: The largest-pile loop visits n elements. A proposed speed also visits all n piles, performing a fixed number of arithmetic and update operations for each, so one test costs proportional to n. The code deliberately computes the complete total even when it already exceeds h.
  ZH: 尋找最大香蕉堆的 loop 走訪 n 個元素。測試一個候選速度也會走訪全部 n 堆，每堆執行固定數量的算術與更新，因此一次檢查的成本與 n 成正比。這份程式即使累計總和已超過 h，仍會刻意把總時數算完。
- `alg-p-24` EN: The lower middle splits an interval into a lower group including mid and an upper group excluding it. With an even number L of candidates, each group has L / 2 members; with an odd L, the lower group has one more member than the upper. Success keeps the lower group and failure keeps the upper, so either update leaves at most ceil(L / 2) candidates. For example, an initial M = 11 gives worst-case size bounds 11 -> 6 -> 3 -> 2 -> 1. After t halvings, at most ceil(M / 2^t) candidates remain. It suffices for 2^t to reach M; ceil(log2 M) is the smallest such whole number of halvings. Thus the total work is at most a constant times n + n * ceil(log2 M), written O(n * (1 + log M)). For M >= 2, the common shorthand is O(n log M). Keeping the initial n term explains the M = 1 case too. Since 2^30 > 10^9, the stated limits need at most thirty proposed-speed scans.
  ZH: 偏下方的中間值把 interval 分成兩組：包含 mid 的下半組，以及不包含它的上半組。候選數 L 為偶數時，每組都有 L / 2 個；L 為奇數時，下半組比上半組多一個。成功保留下半組，失敗保留上半組，因此任一更新後都至多剩下 ceil(L / 2) 個候選。例如初始 M = 11 時，候選數的 worst-case 上界依序是 11 -> 6 -> 3 -> 2 -> 1。減半 t 次後，至多剩下 ceil(M / 2^t) 個候選。只要 2^t 達到 M 就足夠；ceil(log2 M) 就是滿足此條件的最小整數減半次數。因此，總工作量至多是某個常數乘上 n + n * ceil(log2 M)，記為 O(n * (1 + log M))。當 M >= 2，常見簡寫是 O(n log M)。保留起初的 n 這一項，也能說明 M = 1 的情況。因為 2^30 > 10^9，在題目限制內至多需要三十次候選速度的 scan。
- `alg-p-25` EN: Only a fixed number of scalars and a loop's traversal state remain live. Reassigning hours or an endpoint replaces its previous value; it does not retain one entry per pile or per iteration. Auxiliary space is therefore O(1) in the same bounded-integer model, excluding the supplied input list. Temporary arithmetic results add only a fixed number of bounded values. The returned output is one integer, also O(1) space under this model. If arbitrary-length integer inputs replaced the stated limits, arithmetic and integer storage would need a separate bit-size analysis; the scalar model here does not claim otherwise.
  ZH: 同時存活的只有固定數量的 scalar 和 loop 的 traversal state。重新賦值給 hours 或 endpoint，會取代前一個值，不會為每堆或每次 iteration 保留一筆紀錄。因此，在相同 bounded-integer model 下，auxiliary space 是 O(1)，不計入呼叫者提供的輸入 list。暫時算術結果也只增加固定數量的有界數值。回傳 output 是一個整數，在此模型下同樣使用 O(1) 空間。如果把題目限制換成任意長度的整數輸入，算術和整數儲存就需要另做 bit-size analysis；這裡的 scalar model 並未宣稱涵蓋那種情況。
- `alg-p-33` EN: What is the cost? "Finding the maximum takes one scan. Each midpoint takes another scan, and halving the candidate range needs at most ceiling log base two of the largest pile. The total is O(n times (1 plus log M)), with constant auxiliary space under the bounded-integer model."
  ZH: What is the cost? "Finding the maximum takes one scan. Each midpoint takes another scan, and halving the candidate range needs at most ceiling log base two of the largest pile. The total is O(n times (1 plus log M)), with constant auxiliary space under the bounded-integer model."

### 第 35 段 / alg-p-34 — PASS_BOUNDED

註解只重述本文引用分工且明確未外讀引用；context 連到正文實際 rounding、schedule、monotonicity、proof及成本論證。

相鄰不合法推論：引用不是推導完成或外部來源已核實；本稽核不能聲稱驗證了未開啟的來源內容。

本段 reading cue 為問題；Active cue 如存在亦為解釋／比較任務。未把短提示當獨立 theorem。

完整可見註解欄位（兩頁一致）：

- `alg-four-label` [PASS_BOUNDED]: Passive · 哪些依據是引用、哪些是本文推導？
- `alg-four-zh` [PASS_BOUNDED]: 這段區分引用與推導：LeetCode 提供規則，Python documentation 提供取整與整數語意；本文由這些規則推導 interval、trace、alternatives 與 proof。
- `alg-reading-label` [NOT_ASSESSED_PROSODY_OR_LEARNING]: Passive · 【極速流暢標註文本】
- `alg-reading-text` [PASS_BOUNDED]: The problem rules come from the linked LeetCode statement; //the rounding and integer guarantees come from the linked Python documentation. The interval reasoning, worked traces, alternatives, and proof above derive /from those rules.
- `alg-source-explain` [NOT_ASSESSED_PROSODY_OR_LEARNING]: 衍生閱讀示例，並非改寫左側原文；重音只標記已核對的字詞。
- `alg-reading-context` [PASS_BOUNDED]: 適用前提：本段只陳述文章的來源分工；annotation 未另讀取外部頁面核驗引用。 第 35 段適用前提：正文已給逐堆計算、monotonicity、interval proof 與成本推導，來源連結不能取代它們。 第 6 段 · 第 7 段 · 第 9 段 · 第 19 段 · 第 25 段 · 第 27 段 · 第 28 段
- `alg-skeleton` [PASS_BOUNDED]: 閱讀提示（非獨立結論）：Which claims are rules, and which are derived here?

正文支撐及連結論證（完整精確段落）：

- `alg-p-34` EN: The problem rules come from the linked LeetCode statement; the rounding and integer guarantees come from the linked Python documentation. The interval reasoning, worked traces, alternatives, and proof above derive from those rules.
  ZH: 題目規則來自連結中的 LeetCode statement；取整與整數保證來自連結中的 Python documentation。上面的 interval 推理、具體 trace、替代方法與 proof，則由那些規則推導而來。
- `alg-p-5` EN: Python's integer // operator rounds a quotient downward. For positive integers, (p + k - 1) // k instead gives the required upward rounding. To see why, write p = q * k + r, where q is the number of full groups and the remainder r satisfies 0 <= r < k. When r = 0, adding k - 1 still leaves the quotient at q. When r > 0, r + k - 1 lies between k and 2 * k - 2, so the quotient becomes q + 1. Both cases count exactly the hours needed. Python arithmetic semantics.
  ZH: Python 的整數 // 運算會把商向下取整。對正整數而言，(p + k - 1) // k 則能得到需要的向上取整結果。原因可以從 p = q * k + r 看出，其中 q 是完整組數，remainder r 滿足 0 <= r < k。當 r = 0，加上 k - 1 後，整數商仍是 q。當 r > 0，r + k - 1 落在 k 到 2 * k - 2 之間，整數商便成為 q + 1。兩種情況都恰好算出需要的小時數。Python 算術語意。
- `alg-p-6` EN: Add that count separately for every pile. Call the total T(k). Each pile requires its own hours, so any valid schedule needs at least T(k) hours. Eating one pile to completion and then the next achieves exactly that total. Thus T(k) <= h is both necessary and sufficient for speed k to work. Pile order cannot change this sum.
  ZH: 逐堆算出這個數量，再分別加起來，把總和稱為 T(k)。每堆都需要自己的時段，因此任何合法 schedule 至少需要 T(k) 小時。而先吃完一堆、再吃下一堆，就能恰好達到這個總時數。因此，T(k) <= h 是速度 k 能完成任務的必要且充分條件。調換香蕉堆的順序，不會改變這個總和。
- `alg-p-8` EN: Increasing k cannot increase the hours for any individual pile: a speed that clears it in a given number of hours can still clear it within those hours when increased. Adding the pile counts preserves that direction. Therefore T(k) never increases as k increases. The test T(k) <= h has a monotone shape: an initial run of failing speeds, possibly empty, followed by successful speeds.
  ZH: 增加 k 不會讓任何一堆需要更多小時：某個速度若能在指定時數內吃完一堆，提高速度後仍能在那些時數內吃完。把各堆的小時數相加，也會保留這個方向。因此，T(k) 不會隨著 k 增加而增加。檢查式 T(k) <= h 呈現 monotone 的形狀：前面是一段失敗的速度，這段可能為空，後面則都是成功的速度。
- `alg-p-18` EN: Initially, the answer lies between 1 and M, and M is feasible. Suppose the invariant holds before an iteration. If mid fails, monotonicity excludes all speeds at most mid, so the answer remains in [mid + 1, high]; the unchanged high remains feasible. If mid succeeds, some feasible speed is now known at mid. The minimum therefore lies in [low, mid], and assigning high = mid keeps the upper endpoint feasible. Each branch preserves both parts of the invariant.
  ZH: 一開始，答案在 1 到 M 之間，而且 M 可行。假設某次 iteration 開始前 invariant 成立。如果 mid 失敗，monotonicity 排除所有至多為 mid 的速度，因此答案仍在 [mid + 1, high]；未變動的 high 仍然可行。如果 mid 成功，我們便知道 mid 是一個可行速度。最小值因此落在 [low, mid]，設定 high = mid 也讓 upper endpoint 保持可行。兩個 branch 都保留 invariant 的兩項保證。
- `alg-p-24` EN: The lower middle splits an interval into a lower group including mid and an upper group excluding it. With an even number L of candidates, each group has L / 2 members; with an odd L, the lower group has one more member than the upper. Success keeps the lower group and failure keeps the upper, so either update leaves at most ceil(L / 2) candidates. For example, an initial M = 11 gives worst-case size bounds 11 -> 6 -> 3 -> 2 -> 1. After t halvings, at most ceil(M / 2^t) candidates remain. It suffices for 2^t to reach M; ceil(log2 M) is the smallest such whole number of halvings. Thus the total work is at most a constant times n + n * ceil(log2 M), written O(n * (1 + log M)). For M >= 2, the common shorthand is O(n log M). Keeping the initial n term explains the M = 1 case too. Since 2^30 > 10^9, the stated limits need at most thirty proposed-speed scans.
  ZH: 偏下方的中間值把 interval 分成兩組：包含 mid 的下半組，以及不包含它的上半組。候選數 L 為偶數時，每組都有 L / 2 個；L 為奇數時，下半組比上半組多一個。成功保留下半組，失敗保留上半組，因此任一更新後都至多剩下 ceil(L / 2) 個候選。例如初始 M = 11 時，候選數的 worst-case 上界依序是 11 -> 6 -> 3 -> 2 -> 1。減半 t 次後，至多剩下 ceil(M / 2^t) 個候選。只要 2^t 達到 M 就足夠；ceil(log2 M) 就是滿足此條件的最小整數減半次數。因此，總工作量至多是某個常數乘上 n + n * ceil(log2 M)，記為 O(n * (1 + log M))。當 M >= 2，常見簡寫是 O(n log M)。保留起初的 n 這一項，也能說明 M = 1 的情況。因為 2^30 > 10^9，在題目限制內至多需要三十次候選速度的 scan。
- `alg-p-26` EN: An ascending search can try k = 1, 2, 3, ... and return the first speed whose complete pile-hours scan passes. It keeps only the current speed and running total, plus the largest-pile bound if used. All earlier speeds have been explicitly rejected, so its first success is minimal. If the answer is a, it performs a scans of n elements, or n * a pile visits; since a <= M, its worst-case time is O(nM). A single pile of size M with h = 1 forces it to test every speed through M. Reusing the accumulator on each scan keeps auxiliary and output space O(1) under the same numeric model. If a changed task guaranteed that M was a tiny fixed value, ascending search would be a reasonable choice for its simpler control flow; it has no speed advantage promised here. At M up to a billion, skipping ranges is the useful difference.
  ZH: Ascending search 可以依序嘗試 k = 1, 2, 3, ...，每次完整 scan 各堆的小時數，遇到第一個成功速度就回傳。它只保留當前速度、累計總和，以及選擇使用時的最大香蕉堆上界。之前所有速度都已明確被拒絕，因此第一次成功就是最小值。如果答案是 a，它會對 n 個元素 scan 共 a 次，也就是走訪 n * a 堆；因為 a <= M，worst-case time 是 O(nM)。單獨一堆大小為 M 的香蕉、h = 1，就會迫使它測試從 1 到 M 的每個速度。每次 scan 重用 accumulator，讓 auxiliary 和 output space 在相同 numeric model 下維持 O(1)。若改題後保證 M 是很小的固定值，ascending search 因為 control flow 較簡單，會是合理選擇；這裡沒有承諾它比較快。當 M 可達十億時，跳過整段候選才是有用的差別。
- `alg-p-27` EN: A different hourly rule changes the calculation more substantially. Suppose Koko could switch piles within an hour and use the entire capacity k across them. Let S be the total banana count. In that changed task, h hours can consume at most h * k bananas, and continuously taking bananas across pile boundaries can achieve that capacity until the supply ends. Therefore h * k >= S is sufficient as well as necessary, and the minimum integer speed is (S + h - 1) // h. A single pass adds each pile to S, followed by a fixed amount of arithmetic: O(n) time, O(1) auxiliary space, and one integer output under the same bounded model. No per-pile hours or candidate searches remain. This formula fails for the original [4, 4], h = 3 precisely because that original task does not allow switching piles mid-hour.
  ZH: 另一種每小時規則，會更大幅地改變計算。假設 Koko 能在一小時內切換香蕉堆，把完整容量 k 用在多堆之間。令 S 是香蕉總數。在這個改題版本中，h 小時至多能吃 h * k 根；持續跨堆取香蕉，也能在香蕉吃完前用滿這個容量。因此，h * k >= S 既是必要條件，也是充分條件，最小整數速度便是 (S + h - 1) // h。只需一次 pass 把每堆加到 S，再做固定數量的算術：在相同 bounded model 下，time 是 O(n)、auxiliary space 是 O(1)，output 是一個整數。不再需要逐堆的小時數或候選搜尋。這個公式套在原題的 [4, 4], h = 3 會失敗，正是因為原題不允許在一小時中途換堆。


## 實體比對驗證

兩頁全部 35 個正文段落分別與所供同語 Markdown 一致；全部完整 English reading text 移除視覺停頓／標記後與 English 正文一致；兩頁三個 pre blocks（trace、Python code、Master Map）與來源一致。發現的每一段可見引文及正文引文皆經 substring 精確核對。詳細結果在 verification.json。
