from pathlib import Path
import json, re, difflib
out = Path('/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko/output')
first = (out/'first-draft.en.md').read_text()
text = first.replace('# Koko Eating Bananas: Find the First Speed That Works', '# Koko Eating Bananas: find the first speed that works')
text = text.replace('The following is a worked state trace of the reference code\'s operations; each `hours` calculation starts again at zero.', 'Each `hours` calculation starts again at zero.')
text = text.replace(' This is a worked answer for checking a reconstruction, not an observation of anyone\'s understanding.', '')
text = text.replace('“', '"').replace('”', '"')
text = re.sub(r'\*\*(Why can we use binary search without sorting the piles\?|Why do we round each pile upward\?|What does the search invariant guarantee\?|What is the cost\?)\*\*', r'\1', text)
(out/'article.en.md').write_text(text)
(out/'evidence/english-edits.diff').write_text(''.join(difflib.unified_diff(first.splitlines(True), text.splitlines(True), fromfile='first-draft.en.md', tofile='article.en.md')))
code = re.search(r'```python\n(.*?)```', text, re.S).group(1)
(out/'reference.py').write_text(code)
print(json.dumps({'first_draft_words':len(first.split()), 'approved_candidate_words':len(text.split()), 'reference_extracted_from_article':True}))
