# Author reconstruction and English approval

Role: article Content Owner, same author, not an independent Reader. Audience: basic Python syntax/lists/arithmetic/loops. Read only the frozen inputs and the official problem/Python pages recorded in read-records.json. No solution/editorial or exemplar was consulted. First complete draft preserved as first-draft.en.md before this review. The editorial candidate and both edit diffs are preserved.

## Scope rebuilt from the finished body

The finished body proposes three methods, rather than only the main implementation: inclusive-interval binary search, ascending candidate enumeration, and a pooled-capacity formula under a changed hourly rule. It also mentions a tiny-M condition under which enumeration becomes reasonable. Their reasoning and costs are reconstructed below. I did not use source presence as the acceptance condition.

### Main hours calculation and candidate search

Body support: “One hour belongs to one pile” states one pile per hour and forbids moving unused capacity to another pile. “Count a proposed speed…” explains complete groups, remaining bananas, q*k+r and both remainder cases. “Each pile requires its own hours” provides a lower bound on schedules; finishing piles sequentially constructs a matching schedule. The connecting inference is therefore T(k) = the sum of per-pile ceilings, and T(k)<=h iff a feasible schedule exists. This is not derived from total bananas alone. The [4,4],h=3 witness separates those models: pooling predicts3 but required hours are2+2=4.

Body support: “A faster speed…” explains why increasing capacity cannot increase the hours of any pile and why summing preserves this. This establishes the false-then-true shape over positive integer speeds. It does not depend on pile sorting. At M, each of n piles takes one hour; h>=n therefore supplies existence, not merely an arbitrary endpoint. The explicit [low,high] invariant retains the minimum and a feasible upper bound.

A failed mid excludes every speed <=mid; a successful mid leaves the minimum somewhere <=mid, so retaining mid rather than immediately returning is necessary for the chosen first-success search. The proof uses the current invariant to retain the lower boundary. Progress uses low<=mid<high for low<high, making either update strict. Termination at a singleton plus membership implies minimality. No premise in this argument is supplied only by a theorem name or from a solution outline.

New worked witness from the body alone: [2,5],h=4 yields [1,5], mid3, hours1+2=3, [1,3]; mid2, hours1+3=4, [1,2]; mid1, hours2+5=7, [2,2], return2. The last excluded candidate1 is invalid and2 fits. The actual runtime test independently checks feasibility of result and infeasibility of result-1 on small inputs.

### Main cost and storage, including a discovered gap

Declared elementary assumptions: reading a list value, integer comparison and bounded-range integer arithmetic count as constant work. This is a stated comparison model, not a Python implementation timing guarantee. n<=10000, pile/speed<=1e9, hours<=nM<=1e13 make the scalars bounded for this model. The Python docs independently establish exact integer semantics; the article separately declines a claim about arbitrary-length inputs.

Operation frequencies: one n-item maximum scan; n pile contributions per candidate, each with fixed arithmetic/update work; no early exit in the supplied code. Thus if t probes run, work is proportional to n+n*t. The first complete draft asserted that each update retains at most ceil(L/2) candidates but did not explicitly count the lower/upper groups. Repair: the final cost paragraph now explains that the lower-middle split gives equal groups for even L and one extra member in the lower group for odd L; success keeps that lower group, failure keeps the upper. This is the elementary bridge needed for a novice to infer the bound. Repeating these reductions leaves at most ceil(M/2^t) candidates. When 2^t>=M only one can remain, so t<=ceil(log2 M). Therefore n+n*t <= n+n*ceil(log2 M). The 1+logM notation preserves the mandatory first scan at M=1. 2^30>1e9 bounds probes by30. The formula is derived from the updates rather than justified by the words “binary search.”

Live retained state: fixed endpoints, current midpoint, current running total, current pile and traversal state. Each update replaces a bounded scalar; no growing array or probe history survives. Fixed temporaries do not accumulate. Hence O(1) auxiliary space under the declared model, excluding the supplied n-item list, with one scalar returned. This is not “one source line therefore constant space.”

### Ascending alternative and tiny-M adaptation

Body support in “When simpler alternatives fit”: try speeds1,2,3,...; run a complete n-pile check each time; return first success. The state is only current speed, total, and optionally maximum bound. Since all earlier speeds were tested and failed, the result is minimum without using halving. If the answer is a, there are a full scans, so n*a pile visits plus at most one n-item bound scan; a>=1 absorbs the latter. a<=M yields O(nM). [M],h=1 forces a=M, demonstrating many probes without claiming an unsupported tight nM lower bound for every n. A reused scalar total avoids a per-probe or per-pile retained list; auxiliary/output space remain O(1) in the same model.

For a tiny fixed M, enumeration has only a tiny fixed number of scans and simpler updates. The text calls it reasonable, not faster; it does not infer that a linear scan can beat halving for large M or that the same exact iteration bound applies to both. Its elementary operations and storage reuse are explained at the same locations.

### Changed rule: allow switching piles within an hour

Body premise is explicit and hypothetical. If capacity k can flow across pile boundaries, h hours supply at most h*k bananas and a continuous allocation reaches that capacity until all S bananas are consumed. These are necessity and sufficiency, so the smallest positive integer meeting h*k>=S is ceil(S/h), computed by the previously derived positive-integer rounding formula. The article does not use this formula for the original rule.

State: accumulate total S, adding exactly n pile values; a fixed final addition/subtraction/division returns one integer. All n additions use the declared bounded numeric range; no per-pile hours or candidate loop remains. Thus O(n) time, one running total and fixed temporaries for O(1) auxiliary space, one output integer. Reuse of the main constant-arithmetic model remains valid because S<=1e13 and S+h-1 remains bounded. The reason for this adaptation is the changed scheduling premise, not resemblance to the original problem name.

## Actual faults, edits, and verification

1. Semantic teaching gap: missing lower/upper group count before the halving bound. Repaired in final English as above; dependent probe-count, time, interview and Master Map claims checked and remain correct.
2. Runtime presentation mismatch: first draft described setting low after the maximum scan, whereas code assigns it before the scan. Final Program Movie now initializes both endpoints first. Intermediate upper-bound values, candidate probes and code remain unchanged.
3. Editorial supplement: removed two process/provenance sentences around the trace and worked reconstruction; their removal changes no states, condition, proof step or algorithm fact. The outside evidence retains MENTAL_TRACE versus actual tests. Kept physical-pile explanation, code mapping and English interview repetition because they serve different reconstruction purposes.
4. Style flags: title case adjusted after the proper problem name, curly interview quotes changed to ASCII, unnecessary bold removed from questions. The self/instance copula flag is a contextual false positive; changing it would not clarify Python behavior. No code or links changed.
5. Detector actually executed on first draft, editorial candidate and semantically repaired final; raw JSON retained. Its score is not semantic evidence.
6. Executed reference with an independent hour-by-hour simulator plus ascending speed oracle over 17,883 small legal cases;10 examples/large boundary cases; all passed, inputs unchanged. Actual trace saved through sys.settrace. These tests do not prove the English explanation complete or observe a learner.

The final English body supports the three reconstructions above, including the newly added halving premise. English content approved for translation. No unresolved article fact is currently identified by this author review. An independent Reader has NOT_RUN, and this approval is not evidence of human comprehension. Compiler, website/browser, images and publication were not executed under this content-only scope.
