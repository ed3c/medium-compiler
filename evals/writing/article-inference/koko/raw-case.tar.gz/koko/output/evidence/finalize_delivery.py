from pathlib import Path
import json,re,datetime
out=Path('/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko/output')
(out/'article.zh-TW.md').write_bytes((out/'first-draft.zh-TW.md').read_bytes())
en=(out/'article.en.md').read_text()
zh=(out/'article.zh-TW.md').read_text()
def blocks(text):
    result=[]
    pending=[]
    fence=None
    for line in text.splitlines():
        if fence is not None:
            pending.append(line)
            if line=='```':
                result.append(('fence:'+fence,'\n'.join(pending)))
                pending=[];fence=None
        elif line.startswith('```'):
            if pending:
                result.append(('prose','\n'.join(pending)));pending=[]
            fence=line[3:];pending=[line]
        elif line.startswith('#'):
            if pending:
                result.append(('prose','\n'.join(pending)));pending=[]
            level=len(line)-len(line.lstrip('#'))
            result.append(('heading:'+str(level),line))
        elif not line.strip():
            if pending:
                result.append(('prose','\n'.join(pending)));pending=[]
        else:
            pending.append(line)
    assert fence is None
    if pending: result.append(('prose','\n'.join(pending)))
    return result
be,bz=blocks(en),blocks(zh)
assert [x[0] for x in be]==[x[0] for x in bz]
for a,b in zip(be,bz):
    if a[0].startswith('fence:'): assert a[1]==b[1]
assert re.findall(r'\]\((https?://[^)]+)\)',en)==re.findall(r'\]\((https?://[^)]+)\)',zh)
assert all(not re.match(r'^\s*\|',l) for text in (en,zh) for l in text.splitlines())
assert re.search(r'```python\n(.*?)```',en,re.S).group(1)==(out/'reference.py').read_text()
metadata={
 'slug':'leetcode-875-koko-eating-bananas',
 'title':zh.splitlines()[0][2:],
 'english_title':en.splitlines()[0][2:],
 'description':'從逐堆計算小時數，推導 Koko 的 binary search、搜尋 invariant、完整 Python 解法與成本，並比較每小時可換堆時的不同答案。',
 'english_description':'Derive Koko’s binary search from per-pile hours, follow its interval invariant and Python solution, and compare the result when switching piles within an hour is allowed.',
 'source':'articles/leetcode-875-koko-eating-bananas.zh-TW.md',
 'english_source':'articles/leetcode-875-koko-eating-bananas.en.md',
 'bilingual':True,
 'download_markdown':True,
 'delivered_sources':{'source':'article.zh-TW.md','english_source':'article.en.md'},
 'repository_paths_status':'Proposed exact copy destinations for formatter; this task wrote only its output directory.',
 'annotations_status':'NOT_AUTHORED; separate speed-reading Owner must consume approved bodies.'
}
(out/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
summary={'block_kind_sequence_equal':True,'block_count_per_edition':len(be),'prose_paragraph_count_per_edition':sum(k=='prose' for k,v in be),'heading_levels':[int(k.split(':')[1]) for k,v in be if k.startswith('heading:')],'fence_languages':[k.split(':')[1] for k,v in be if k.startswith('fence:')],'all_fence_bytes_equal':True,'reader_link_sequence_equal':True,'no_markdown_tables':True,'python_fence_equals_reference':True,'zh_first_draft_bytes_unchanged_in_final':True,'metadata_titles_match_h1':True,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'does_not_prove':'semantic fidelity or independent reader reconstruction'}
(out/'evidence/bilingual-structure.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'figures.json').write_text(json.dumps({'necessary_image_figures':[],'reason':'The material runtime boundaries and interval updates are fully represented in the retained text trace and Master Map; no additional image is needed for this edition.','image_generation':'NOT_RUN'},indent=2)+'\n')
print(json.dumps(summary,indent=2))
