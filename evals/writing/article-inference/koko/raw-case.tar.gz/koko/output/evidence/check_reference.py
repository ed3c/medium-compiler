from pathlib import Path
import importlib.util, itertools, json, sys, re
out = Path('/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko/output')
spec = importlib.util.spec_from_file_location('koko_reference',out/'reference.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
solve = module.Solution().minEatingSpeed
# Independent small-input oracle: consume bananas hour by hour, then enumerate speeds.
def simulated_hours(piles, speed):
    hours = 0
    for pile in piles:
        remaining = pile
        while remaining > 0:
            remaining -= speed
            hours += 1
    return hours

def oracle(piles, h):
    for speed in range(1,max(piles)+1):
        if simulated_hours(piles,speed) <= h:
            return speed
    raise AssertionError('legal case has no answer')

checked = 0
for n in range(1,5):
    for values in itertools.product(range(1,7), repeat=n):
        piles = list(values)
        for h in range(n, sum(piles)+2):
            before = piles[:]
            actual = solve(piles,h)
            expected = oracle(piles,h)
            assert actual == expected, (piles,h,actual,expected)
            assert piles == before
            assert simulated_hours(piles,actual) <= h
            if actual > 1:
                assert simulated_hours(piles,actual-1) > h
            checked += 1
examples = [([3,6,7,11],8,4),([30,11,23,4,20],5,30),([30,11,23,4,20],6,23),([4,4],3,4),([2],1,2),([2,5],4,2),([1]*10000,10000,1),([10**9]*10000,10000,10**9),([10**9],10**9,1),([10**9]*10000,10**9,10000)]
for piles,h,expected in examples:
    actual=solve(piles,h)
    assert actual==expected,(h,actual,expected)
# Capture the actual reference function's state at while/body/branch/return checkpoints.
trace=[]
def capture(frame,event,arg):
    if frame.f_code.co_filename == str(out/'reference.py') and event=='line':
        trace.append({'line':frame.f_lineno, **{k:frame.f_locals[k] for k in ('low','high','mid','hours','pile') if k in frame.f_locals}})
    return capture
sys.settrace(capture)
result=solve([3,6,7,11],8)
sys.settrace(None)
(out/'evidence/runtime-trace.json').write_text(json.dumps({'input':{'piles':[3,6,7,11],'h':8},'result':result,'events':trace},indent=2)+'\n')
# Cross-check article's code bytes without invoking any repository/compiler.
body=(out/'article.en.md').read_text()
code=re.search(r'```python\n(.*?)```',body,re.S).group(1)
assert code == (out/'reference.py').read_text()
summary={'exhaustive_cases':checked,'exhaustive_domain':'n=1..4; pile sizes=1..6; h=n..sum(piles)+1','oracle':'hour-by-hour pile consumption, then ascending speed enumeration','examples_and_large_boundaries':len(examples),'input_unchanged_on_exhaustive_cases':True,'article_python_equals_reference':True,'trace_return':result,'status':'PASS','python_version':sys.version}
(out/'evidence/runtime-tests.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
