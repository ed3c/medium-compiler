from pathlib import Path
import difflib
out = Path('/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko/output')
p = out/'article.en.md'
old = p.read_text()
(out/'evidence/editorial-candidate.en.md').write_text(old)
new = old.replace('Finding the largest pile starts with `high = 1` and reads `3, 6, 7, 11`; each exceeds the stored value, so `high` becomes `3`, then `6`, then `7`, then `11`. Set `low = 1`.', 'Initialize `low = 1` and `high = 1`. The largest-pile scan reads `3, 6, 7, 11`; each exceeds the stored upper bound, so `high` becomes `3`, then `6`, then `7`, then `11`.')
new = new.replace('If an interval contains `L` candidate integers, either update leaves at most `ceil(L / 2)` candidates.', 'The lower middle splits an interval into a lower group including `mid` and an upper group excluding it. With an even number `L` of candidates, each group has `L / 2` members; with an odd `L`, the lower group has one more member than the upper. Success keeps the lower group and failure keeps the upper, so either update leaves at most `ceil(L / 2)` candidates.')
p.write_text(new)
(out/'evidence/semantic-repairs.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='editorial-candidate.en.md', tofile='article.en.md')))
print('Two author-review repairs applied; original complete and editorial editions preserved.')
