class Solution:
    def minEatingSpeed(self, piles, h):
        low = 1
        high = 1
        for pile in piles:
            if pile > high:
                high = pile

        while low < high:
            mid = (low + high) // 2
            hours = 0
            for pile in piles:
                hours += (pile + mid - 1) // mid

            if hours > h:
                low = mid + 1
            else:
                high = mid

        return low
