import json,pathlib,copy,hashlib
base=pathlib.Path('/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko'); out=base/'annotation-output'; inp=base/'annotation-input'
m=json.loads((out/'first-draft-manifest.json').read_text()); p=json.loads((inp/'paragraphs.json').read_text())
# Preserve actual first serialized output, including its input-gap-induced shape failure.
(out/'pre-field-shape-manifest.json').write_bytes((out/'manifest.json').read_bytes())
for a in m['paragraph_annotations']:
    raw=a['english_source']; events={0:{'break':None,'bundle':False}}; bundle_ends=set(); bundle_starts=set()
    for mark in a['added_annotation_marks']:
        pos=mark['source_offset']; marker=mark['added_text']
        events.setdefault(pos,{'break':None,'bundle':False})
        if marker=='/ ': events[pos]['break']='minor'
        elif marker=='//\n': events[pos]['break']='major'
        elif marker=='[': bundle_starts.add(pos)
        elif marker==']': bundle_ends.add(pos)
    positions=sorted(events); positions.append(len(raw)); tokens=[]; inside=False
    for start,end in zip(positions,positions[1:]):
        if start in bundle_ends: inside=False
        if start in bundle_starts: inside=True
        if start==end: continue
        token={'text':raw[start:end],'break_before':events[start]['break']}
        if inside: token['bundle']=True
        tokens.append(token)
    assert ''.join(t['text'] for t in tokens)==raw
    a['kind']=a.pop('role'); a['decision_ids']=[a.pop('decision_id')]
    a['speed_reading']={'tokens':tokens,'skeleton':a.pop('cognitive_skeleton')}
    for field in ['english_mode_c','added_annotation_marks','reading_cue_label','active_item_ids','source_git_blob','english_source_git_blob']:
        a.pop(field,None)
# The original p28 is a descriptive exercise prompt, not an observed learner checkpoint.
m['paragraph_annotations'][28]['reading_context']['checkpoint']=None
m['paragraph_annotations'][17]['reading_context']['premises'][1]['text']='此段描述本文指定實作：總和放在 hours scalar，輸入與 instance 不儲存新的演算法狀態。'
for d in m['decisions']:
    d['title']=d.pop('question'); d['passive']=d.pop('condition'); d['source_paragraph_indices']=d.pop('paragraph_indices')
    items=[a for a in m['active_items'] if a['decision_id']==d['id']]
    if items:
        d['active_cue']=' '.join(a['self_expression_cue'] for a in items)
        d['oracle']=' '.join(a['oracle'] for a in items)
for a in m['active_items']:
    a['source_quote']=p[a['paragraph_index']]['english_source']
    a['english_sentence']=a.pop('production_sentences')[0]
    a['active_cue']=a.pop('self_expression_cue')
    for field in ['sense','source_git_blob','english_source_git_blob','learner_evidence']:a.pop(field,None)
m['reading_projection']['semantic_verification']='OWNER_REVIEW_PENDING'
(out/'first-structured-draft-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
(out/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
r=json.loads((out/'read-records.json').read_text()); f=inp/'field-shape.json'
r['records'].append({'path':'field-shape.json','sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'read_scope':'complete; supplied by parent after first draft','authority':'mechanical field names/types only'})
r['input_gap_and_followup']={'gap':'The initial natural-language contract and manifest template did not serialize per-paragraph, decision or Active field shapes. First draft used provisional fields.','followup':'Parent supplied field-shape.json from existing validator/projection after first draft. Original draft and pre-adaptation manifest preserved; structured tokens now carry annotation marks without ambiguous inline source delimiters.','first_draft_preserved':'first-draft-manifest.json','corrected_draft_preserved':'first-structured-draft-manifest.json'}
(out/'read-records.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print('Adapted 35 complete annotations to supplied existing field names; original first output preserved.')
