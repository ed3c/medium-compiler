import json, pathlib, hashlib, os
base=pathlib.Path('/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko')
inp=base/'annotation-input'; out=base/'annotation-output'
p=json.loads((inp/'paragraphs.json').read_text()); m=json.loads((inp/'manifest-template.json').read_text())
def refs(ids):
    return [{'paragraph_index':i,'english_quote':p[i]['english_source']} for i in ids]
# Each row below is authored from the paired complete article; indices only bind that reasoning mechanically.
rows=[
('monotone-range','先精確計算某個 speed 的 hours，再用 monotonicity 排除較慢的失敗候選；成功後仍要找更小答案。binary search 的對象是 speeds，所以不用排序 piles。','Why does one failed speed exclude slower speeds?', [('原題求最小正整數 speed；逐堆小時數的總和才是可行性判準。',[1,4,6]),('提高 speed 不會增加 T(k)，因此失敗速度以下也失敗；成功只給上界。',[8,9])],None),
('hourly-contract','每小時只能吃一堆；提早完成也不能把剩餘容量給另一堆。要求的是至多 h 小時內完成的最小正整數 speed。','Which hourly restriction changes the required speed?', [('piles 非空且每堆大小為正；同一小時不能換堆，目標是最小正整數 k。',[1])],None),
('hourly-contract','n 是堆數，每堆至少一小時；h >= n 才保證某個 speed 可行。此解法只讀取 piles，空輸入與 h < n 不適用。','Why does h >= n guarantee a feasible speed?', [('本題 n、h、pile sizes 皆受列出的限制；正數堆各佔至少一小時。',[1,2]),('取 M 為最大堆時，每堆一小時，所以 n <= h 給出可行上界。',[10])],None),
('hourly-contract','[4, 4]、h = 3 時，k = 3 要四小時，k = 4 才能完成。對總香蕉數一次取 ceiling 會錯把不同堆的容量合併。','Why does pooling suggest the wrong answer here?', [('原題不允許在同一小時換堆；例子的 deadline 為三小時。',[1,3]),('每堆 ceiling 必須分別計算後相加。',[4,6])],None),
('exact-hours','一堆的完整 k 根群組各佔一小時，remainder 也要一整小時，所以需要 ceiling(p / k)；11 根、k = 4 得到 4、4、3 三組。','Why does a remainder require another whole hour?', [('p 與 k 都為正，且一小時只處理一堆，剩餘香蕉不能借用別堆時段。',[1,4])],None),
('exact-hours','正整數可用 (p + k - 1) // k 算 ceiling。把 p 拆成 q * k + r：r = 0 商仍為 q，r > 0 商增加為 q + 1。','How do the two remainder cases produce the ceiling?', [('p、k 為正整數；// 向下取整；0 <= r < k。這些條件讓兩個 r 分支覆蓋所有情況。',[5]),('單堆需要完整群組數加上非零 remainder 所佔的一小時。',[4])],None),
('exact-hours','每堆各需自己的 ceiling hours，所以 T(k) 是合法 schedule 的下界；逐堆吃完可恰好達到它，因此 T(k) <= h 既必要也充分，順序不影響總和。','What establishes both directions of the feasibility test?', [('每小時只能處理一堆，單堆小時數是 ceiling(p / k)。',[1,4]),('任一合法 schedule 至少需 T(k)，而逐堆完成的 schedule 恰用 T(k)。',[6])],None),
('scalar-execution','固定 k = 4 時，hours 依序累加為 1、3、5、8。只保留 running total，不建立貢獻值 list，也不修改 piles。','What does hours contain after each pile?', [('此 trace 使用 [3, 6, 7, 11]、k = 4；每堆貢獻由 ceiling 算出。',[5,7])],('hours 從零開始；每處理完一堆才把該貢獻加到累計值，全部完成後為 8。',[7])),
('monotone-range','提高 k 後，原本足夠的時數仍足夠處理每堆；相加後 T(k) 不增加。因此 feasible speeds 接在 failing speeds 之後，失敗前綴可能為空。','Does non-increasing mean every speed increase saves an hour?', [('T(k) 是各堆所需 hours 的總和，以 T(k) <= h 判定可行。',[6]),('每堆都不因提高速度而需要更多小時，求和保留此方向。',[8])],None),
('monotone-range','由 monotonicity，6 失敗可排除 1 到 6；6 成功只證明最小成功速度至多為 6，不能直接回傳第一次成功的 probe。','What does success prove, and what remains unknown?', [('同一個 piles、h 下，T(k) 隨 k 增加而不增加。',[8]),('目標是最小可行速度；成功的 6 以下仍可能存在成功速度。',[1,9])],None),
('interval-invariant','M 是最大堆，k = M 讓每堆各需一小時，因 h >= n 而可行。以 [1, M] 儲存 inclusive speed interval，無須建立候選 list 或排序 piles。','Why is M a valid initial upper endpoint?', [('每堆為正且 h >= n；speed M 足以在一小時完成任何一堆。',[2,10]),('答案是正整數 speed，因此至少為 1，並在 M 前已有可行值。',[1,10])],('搜尋初始化為 [low, high] = [1, M] 時，答案在 interval 內且 high 可行。',[10])),
('interval-invariant','iteration 開始時，invariant 同時保證最小 feasible speed 留在 [low, high] 且 high 可行；它描述當前搜尋狀態，monotonicity 則描述所有 speeds 的可行性方向。','Which two facts must the current interval preserve?', [('feasible 表示通過 T(k) <= h；inclusive interval 含兩端。',[6,10,11]),('初始化已提供包含答案且 high 可行的狀態。',[10])],('每次 search iteration 開始時檢查兩項 invariant，不把單次 probe 成功當成最小值。',[11])),
('interval-invariant','lower middle 失敗就設 low = mid + 1，排除 mid 及更慢者；成功則設 high = mid，保留仍可能最小的 mid。兩端相等才回傳。','Why do the two branches treat mid differently?', [('monotonicity 允許排除失敗速度以下，成功速度仍可能就是最小值。',[8,9]),('開始 iteration 時答案在 inclusive interval 且 high 可行。',[11])],('先算完整 T(mid) 再依 > h 分支更新；low == high 時由 invariant 得到答案。',[12,18,19])),
('scalar-execution','trace 先以 high = 1 掃描 [3, 6, 7, 11]，high 逐步成為 3、6、7、11；每次測試新 speed 都重新把 hours 設為零。','When must the hours total restart?', [('本例 piles = [3, 6, 7, 11]、h = 8，scan 前 low、high 都為 1。',[13]),('每個新 speed 需要自己的總時數，不能沿用前一次的 hours。',[17])],('找最大堆的 scan 完成後 high = 11；每次 hours 計算開始時重新為零。',[13])),
('scalar-execution','這個 trace 的 6 已可行但答案為 4；4、5 都恰用八小時，顯示 equality 與首次 probe 成功都不能證明最小值。','Why is an exact deadline match insufficient to return?', [('本例使用 [3, 6, 7, 11]、h = 8；每堆單獨取 ceiling。',[7,13,14]),('找的是最小可行 speed，成功的 probe 只能提供上界。',[1,9])],('probe 6 成功後仍縮小上界；3 失敗排除 1、2、3；最後 interval 留下 4。',[12,14,19])),
('exact-hours','11 根以 speed 4 分成 4、4、3 三小時；最後未用滿容量的時段仍屬於該堆。這正是 scalar ceiling 計算不能改成 pooling 的原因。','Who owns the unused capacity in the last hour?', [('固定 p = 11、k = 4，原題不允許同小時換堆。',[1,4,15])],None),
('scalar-execution','最大堆 scan 的 high 表示已讀元素的最大值；之後每個 search iteration 都讀同一 list 算總時數。Solution 是 wrapper，演算法沒有把狀態存到 self。','What does high mean during the initial scan?', [('每堆大小至少為 1，使初始 high = 1 有效；此段描述文中指定實作。',[2,16])],('初始 scan 每處理完一個元素後 high 是目前最大值；之後才進入 speed search。',[16])),
('scalar-execution','hours = 0 在 while 內讓每個 speed 使用獨立總和；+= 更新 scalar。候選 speed 保持正值，division 無零 divisor；此實作不留 probe history。','Why must a new probe reset hours?', [('本文實作以 [1, M] 起始，且依兩種 interval 更新保留正數候選。',[10,12]),('這是指定實作的狀態安排，並非所有正確解法都只能如此命名變數。',[16,17])],('每次 while iteration 先將 hours 歸零，scan 完才更新 endpoint。',[17,12])),
('interval-invariant','初始 M 可行。mid 失敗時排除所有 <= mid 的速度，high 不變；成功時保留 [low, mid] 並讓新 high = mid 可行，所以兩個 branch 都維持 invariant。','How does each branch preserve both invariant clauses?', [('初始 [1, M] 包含答案；當前 inclusive interval 包含最小 feasible speed，且 high 可行。',[10,11]),('T(k) 不增加，故失敗排除更慢者、成功提供可行上界。',[8,9])],('假設 iteration 前 invariant 成立，完成對應 endpoint 更新後再檢查兩項保證。',[18])),
('interval-invariant','low < high 時 lower middle 小於 high；失敗提高 low，成功降低 high，候選數嚴格減少又不空。只剩一個時，invariant 已保證它是最小 feasible speed，無須額外 probe。','Why can the final candidate be returned without another test?', [('這個 lower-middle 與兩種更新保留答案和可行 high。',[12,18]),('low < high 時有 low <= mid < high，且每次更新減少整數候選數。',[19])],('停止時 low == high，將一直維持的 invariant 套到唯一剩餘候選。',[11,19])),
('interval-invariant','錯把 failure 更新寫成 low = mid，可能完全不縮小 interval。[2]、h = 1 時 [1, 2] 的 mid = 1 失敗，卻反覆保留同一狀態；+ 1 才移除失敗候選。','Which candidate must the failure branch actually remove?', [('反例使用 lower middle，piles = [2]、h = 1、interval = [1, 2]。',[20]),('正確規則是在 mid 失敗後設 low = mid + 1。',[12])],('錯誤 assignment 執行後 interval 仍是 [1, 2]，下一輪重複同一失敗 probe。',[20])),
('interval-invariant','全為 1 時 M = 1，免進 search；h = n 時最大堆迫使答案為 M；h 足夠容納每根一小時時答案為 1。h < n 則在原題規則下根本無解。','Which boundary inputs make the answer known immediately?', [('每堆為正且各佔至少一小時；speed 為正整數。',[1,2]),('M 可行的證明使用 h >= n，不能延用到 h < n。',[10,21])],('M = 1 初始化後 low == high，search loop 不執行就回傳 1。',[21,19])),
('bounded-cost','這裡把限制內的 list read、整數比較與算術各算 constant work；numeric range 有界且 Python integers 精確。這是 operation-count model，不是相同 wall-clock 耗時的宣稱。','Which assumptions make arithmetic constant work in this analysis?', [('n <= 10^4、pile sizes 與 speeds <= 10^9，總 hours <= n * M <= 10^13。',[2,10,22]),('本文明確宣告 bounded-integer cost model；不涵蓋任意長整數的 bit-size 成本。',[22,25])],None),
('bounded-cost','最大堆 scan 與每次 proposed-speed test 都讀 n 個元素；每堆固定數量的有界算術與更新，因此單次 test 成本與 n 成正比，即使 hours 已超過 h 仍繼續算完。','Why does one proposed-speed test cost proportional to n?', [('此實作每個 test 完整走訪 n 堆，每堆工作數固定。',[17,23]),('在 bounded-integer model 下，每次讀取、比較、算術與更新算 constant work。',[22,23])],('此處計數的是完成整個 pile-hours scan 的 test；沒有超過 h 就提前結束。',[23])),
('bounded-cost','任一更新後至多剩 ceil(L / 2) 候選，故至多 ceil(log2 M) 次 test；加上初始 n-element scan，總成本為 O(n * (1 + log M))。M = 1 仍需初始 scan。','How do scan cost and interval halving combine?', [('初始有 M 個整數候選，更新分別保留下半組或上半組，最多 ceil(L / 2) 個。',[10,12,24]),('初始 scan 有 n 次訪問；每次 proposed-speed scan 也有 n 次固定有界工作。',[22,23])],('完成 t 次 interval 更新後，候選數至多 ceil(M / 2^t)；降到 1 時停止。',[24,19])),
('bounded-cost','此實作只保留固定數量 scalar 與 traversal state，更新取代舊值；bounded-integer model 下 auxiliary 與單整數 output 都是 O(1)，排除輸入 list。任意長整數需另算 bit-size。','What remains live, and which storage convention is used?', [('本文程式不複製輸入、不存 probes 或逐堆貢獻 list。',[7,17]),('整數大小受本題限制，auxiliary space 不包含呼叫者提供的 input list。',[22,25])],('任一時點只計仍存活的固定數量 scalar、traversal state 與暫時 bounded values；舊值不保留成 history。',[25])),
('ascending-alternative','Ascending search 逐一拒絕 1 到 a - 1，故首個成功 a 最小；共 a 次完整 scan，即 n * a visits，worst case O(nM)。重用 accumulator 保持 O(1) space；M 很小時 control flow 較簡單，但未保證較快。','When is ascending search a reasonable simpler alternative?', [('沿用原題的 per-pile hours test 與可行上界 a <= M。',[1,6,10]),('一個完整 scan 有 n 次固定有界工作；ascending search 不儲存歷次結果。',[22,23,26]),('M 為很小固定值是本段替代選擇的改題條件；單堆 M、h = 1 可迫使測試到 M。',[26])],('從 k = 1 依序測試到第一次成功 a；停止前所有更小 speed 已明確失敗。',[26])),
('pooled-alternative','只有改成一小時內可跨堆用滿容量，h * k >= S 才既必要又充分，答案為 ceiling(S / h)。單次累加 S 加固定算術為 O(n) time、O(1) auxiliary；原題 [4,4] 不允許這種 pooling。','Which changed rule makes the total-capacity formula sufficient?', [('此段另假設同小時可換堆並把容量 k 用在多堆，與原題規則不同。',[1,27]),('跨堆連續取香蕉可達 h * k 容量直到供應用盡；S 為總數，h 為正。',[2,27]),('單次 pass 各堆加到 S、再做固定算術；沿用 bounded-integer model。',[22,27])],None),
('interval-invariant','練習用 [2,5]、h = 4 從 [1,5] 重建每次 speed、總 hours 與 endpoints；重點是用 monotonicity 解釋為何可排除未逐一測試的速度。','What justifies discarding an untested smaller speed?', [('本練習固定 piles = [2, 5]、h = 4，使用原題的逐堆 hours test。',[28,1,6]),('排除範圍需依 monotonicity 與既有 interval 更新，不只是記 assignment。',[8,12])],('這是閱讀練習提示；未記錄任何學習者的回答或成功。',[28])),
('interval-invariant','本例依序測 mid 3、2、1，hours 為 3、4、7；interval 由 [1,5] 經 [1,3]、[1,2] 到 [2,2]，由最後一次失敗排除 1，回傳 2。','How does the final failed probe leave a minimum of 2?', [('輸入固定為 [2, 5]、h = 4；每堆分別取 ceiling 並相加。',[28,4,6]),('成功保留 mid，失敗排除 mid 以下；invariant 保留最小 feasible speed。',[11,12])],('依原文 trace 完成三次 endpoint 更新後 [2,2] 只剩候選 2。',[29])),
('monotone-range','面試回答要把搜尋對象說清楚：有序的是正整數 speeds，並非 piles 位置；T(k) 不增加讓 feasibility 不會由 true 回到 false，所以不需先排序 piles。','What is ordered when the piles are unsorted?', [('speed 為正整數；每個 speed 的判準是 T(k) <= h。',[1,6]),('T(k) 不增加，失敗前綴可能為空；不必每次增加 k 都切換 feasibility。',[8,30]),('interval 的 endpoints 是 speeds，非 piles indices。',[10])],None),
('exact-hours','面試回答把 remainder 與小時歸屬連起來：未完成的一堆要再佔完整小時，不能把剩餘容量挪走，所以總時數是 per-pile ceilings 的和。','Why sum per-pile ceilings instead of pooling all bananas?', [('原題每小時只處理一堆；單堆 remainder 要額外完整小時。',[1,4]),('逐堆小時下界可由逐堆完成達到，故總和是正確所需時間。',[6,31])],None),
('interval-invariant','面試回答要同時保留「最小值仍在 inclusive interval」與「high 可行」。失敗 mid 及更小者被移除；成功 mid 留下，避免丟掉可能的最小值。','Which success candidate must remain after the interval update?', [('當前 iteration 開始時最小 feasible speed 在 interval，且 high 可行。',[11]),('monotonicity 支持兩分支的排除方向；不是只憑某次 probe 結果宣稱最小。',[8,18,32])],('每個 branch 更新完成後兩項 invariant 都成立，直到 low == high。',[18,19])),
('bounded-cost','面試成本回答需連上推導：初始 scan、每次 n 堆 test、至多 ceil(log2 M) 次減半，得到 O(n * (1 + log M))；固定 scalar 在 bounded-integer model 下用 O(1) auxiliary。','Which three counts support the stated time bound?', [('n 是堆數，M 是最大堆；每次有界算術算 constant work。',[2,10,22]),('初始與每個 probe 都完整 scan n 堆，候選反覆減半至一個。',[23,24]),('固定 scalar 與 traversal state 不保留 history；input 不算 auxiliary。',[25,33])],None),
('source-provenance','這段區分引用與推導：LeetCode 提供規則，Python documentation 提供取整與整數語意；本文由這些規則推導 interval、trace、alternatives 與 proof。','Which claims are rules, and which are derived here?', [('本段只陳述文章的來源分工；annotation 未另讀取外部頁面核驗引用。',[34]),('正文已給逐堆計算、monotonicity、interval proof 與成本推導，來源連結不能取代它們。',[5,6,8,18,24,26,27])],None)
]
assert len(rows)==len(p)==35
# Explicit, individually selected syntax/bundle placements. No automatic phrase/word-count segmentation.
marks={
0:[('finding the slowest','/ '),('Once that calculation','//\n'),('over possible answers','/ ')],
1:[('measured in bananas','/ '),('During each hour','//\n'),('during the same hour','/ ')],
2:[('where n is','/ '),('so h >= n','//\n'),('Empty lists','//\n')],
3:[('even though dividing','//\n'),('from one pile on another','/ ')],
4:[('at speed k','/ '),('If some bananas remain','//\n'),('For p = 11','//\n')],
5:[('For positive integers','//\n'),('where q is','/ '),('When r = 0','//\n'),('When r > 0','//\n')],
6:[('for every pile','/ '),('so any valid schedule','//\n'),('Eating one pile','//\n'),('Thus T(k)','//\n')],
7:[('an accumulator named hours','/ '),('changing hours to 1','/ '),('The calculation stores','//\n')],
8:[('for any individual pile','/ '),('Adding the pile counts','//\n'),('Therefore T(k)','//\n')],
9:[('If speed 6 fails','//\n'),('If speed 6 works','//\n'),('but might be smaller','//\n')],
10:[('using exactly n hours','/ '),('which fits the guaranteed','/ '),('so start with','//\n'),('These numbers are speeds','//\n')],
11:[('At the start of every search iteration','/ '),('The minimum feasible speed','//\n'),('The monotone property describes','//\n')],
12:[('the lower middle integer','/ '),('When T(mid) > h','//\n'),('Otherwise set high','//\n'),('Stop when low','//\n')],
13:[('The largest-pile scan reads','//\n'),('so high becomes','//\n'),('Each hours calculation','//\n')],
14:[('yet the final answer','//\n'),('so an exact match','//\n'),('including when several speeds','/ ')],
15:[('for 4, 4, and 3 bananas','/ '),('That last partially used hour','//\n'),('at the place where pooling','/ ')],
16:[('after each item','/ '),('with initial value 1','/ '),('Each search iteration then','//\n'),('and the algorithm stores','//\n')],
17:[('because a new speed','//\n'),('not to the input list','/ '),('so the division never','//\n')],
18:[('Suppose the invariant holds','//\n'),('If mid fails','//\n'),('so the answer remains','//\n'),('If mid succeeds','//\n'),('Each branch preserves','//\n')],
19:[('the lower middle satisfies','/ '),('In the failure branch','//\n'),('so it must eventually','//\n'),('even if that exact speed','/ ')],
20:[('For piles = [2]','//\n'),('That incorrect assignment','//\n'),('that the hours test','/ ')],
21:[('With all piles of size 1','//\n'),('If h = n','//\n'),('If h is at least','//\n'),('outside it','/ ')],
22:[('reading a list element','/ '),('not equal wall-clock time','/ '),('so their required numeric range','//\n')],
23:[('performing a fixed number','/ '),('so one test costs','//\n'),('even when it already exceeds h','/ ')],
24:[('including mid','/ '),('excluding it','/ '),('With an even number L','//\n'),('with an odd L','//\n'),('so either update leaves','//\n'),('After t halvings','//\n'),('Thus the total work','//\n'),('For M >= 2','//\n')],
25:[('it does not retain','//\n'),('excluding the supplied input list','/ '),('under this model','/ '),('If arbitrary-length integer inputs','//\n')],
26:[('whose complete pile-hours scan passes','/ '),('so its first success is minimal','//\n'),('If the answer is a','//\n'),('since a <= M','//\n'),('under the same numeric model','/ '),('If a changed task guaranteed','//\n')],
27:[('Suppose Koko could switch piles','//\n'),('and use the entire capacity k','/ '),('and continuously taking bananas','//\n'),('Therefore h * k >= S','//\n'),('under the same bounded model','/ '),('precisely because that original task','//\n')],
28:[('Before checking the result','//\n'),('rather than only remembering','/ ')],
29:[('then mid 2','//\n'),('then mid 1','//\n'),('The last failure removes','//\n')],
30:[('without sorting the piles','/ '),('not pile positions','/ '),('so feasibility changes','//\n')],
31:[('and unused capacity cannot move','//\n'),('in that hour','/ ')],
32:[('and the upper endpoint is feasible','//\n'),('a feasible midpoint stays','//\n')],
33:[('Each midpoint takes','//\n'),('and halving the candidate range','//\n'),('with constant auxiliary space','/ '),('under the bounded-integer model','/ ')],
34:[('the rounding and integer guarantees','//\n'),('from those rules','/ ')]}
bundles={0:['binary search'],4:['at least as large as'],6:['necessary and sufficient'],7:['running total'],8:['an initial run of'],10:['inclusive interval'],11:['search iteration'],16:['seen so far'],18:['both parts of the invariant'],21:['at least'],22:['bounded-integer cost model'],23:['a fixed number of'],25:['remain live'],26:['control flow'],27:['sufficient as well as necessary'],28:['rather than'],29:['The last failure'],30:['integer speeds'],31:['per-pile ceilings'],32:['upper endpoint'],33:['constant auxiliary space']}
def project(i):
    text=p[i]['english_source']; inserts=[]
    for anchor,marker in marks[i]:
        pos=text.index(anchor); inserts.append((pos,marker))
    for bundle in bundles.get(i,[]):
        pos=text.index(bundle); inserts += [(pos,'['),(pos+len(bundle),']')]
    # tie order: bundle open occurs after a boundary marker; closure is at phrase end.
    inserts.sort(key=lambda it:(it[0], 0 if it[1] != '[' else 1))
    result=''; prev=0; ledger=[]
    for pos,marker in inserts:
        result += text[prev:pos]; prev=pos
        ledger.append({'projection_offset':len(result),'added_text':marker,'source_offset':pos})
        result += marker
    result += text[prev:]
    recovered=result
    for item in reversed(ledger):
        start=item['projection_offset']; assert recovered[start:start+len(item['added_text'])]==item['added_text']
        recovered=recovered[:start]+recovered[start+len(item['added_text']):]
    assert recovered==text
    return result,ledger
for i,(decision,note,cue,premises,checkpoint) in enumerate(rows):
    projection,ledger=project(i)
    annotation={'paragraph_index':i,'decision_id':decision,'role':'PASSIVE','source_git_blob':m['source']['git_blob'],'english_source_git_blob':m['english_source']['git_blob'],'zh_note':note,'english_source':p[i]['english_source'],'english_mode_c':projection,'cognitive_skeleton':cue,'reading_cue_label':'閱讀提示（非獨立結論）','reading_context':{'premises':[{'text':text,'supporting_sources':refs(ids)} for text,ids in premises],'checkpoint':None if checkpoint is None else {'text':checkpoint[0],'supporting_sources':refs(checkpoint[1])}},'active_item_ids':[],'added_annotation_marks':ledger}
    m['paragraph_annotations'].append(annotation)
decisions=[
('hourly-contract','何時必須逐堆而不能共用容量？','原題一小時只屬於一堆；提早完成不能換堆。',[1,2,3,15]),
('exact-hours','如何精確測試一個 speed？','正整數 ceiling 逐堆計算並相加；下界與可達 schedule 共同證成判準。',[4,5,6,7,31]),
('monotone-range','為何可跳過未逐一測試的速度？','T(k) 不增加；失敗排除較慢者，成功僅給上界。',[0,8,9,30]),
('interval-invariant','如何保留最小答案並確保終止？','[1,M] 初始化，lower middle 兩分支保留 invariant 並嚴格縮短 interval。',[10,11,12,18,19,20,21,28,29,32]),
('scalar-execution','實作各階段的 scalar 表示什麼？','最大堆 scan 後再搜索；每個 speed 都用新 hours total，不留 history。',[13,14,16,17]),
('bounded-cost','何種 cost model 支持時間與空間界線？','bounded integer 的固定工作、n-element scans、候選減半與固定 live state。',[22,23,24,25,33]),
('ascending-alternative','何時逐一測 speed 是合理簡化？','M 很小時 control flow 較簡單；a 次完整 scan 不承諾速度優勢。',[26]),
('pooled-alternative','哪個規則改變讓總量公式成立？','可在一小時跨堆並用滿容量，才可直接使用 ceiling(S/h)。',[27]),
('source-provenance','哪些依據是引用、哪些是本文推導？','規則與 Python 語意由引用提供，interval、trace、proof 和 alternatives 由正文推導。',[34])]
m['decisions']=[{'id':key,'question':question,'condition':condition,'paragraph_indices':ids,'supporting_sources':refs(ids)} for key,question,condition,ids in decisions]
active=[
('ceiling','ceiling','exact-hours',4,'An unfinished remainder needs another whole hour, so each pile uses the ceiling of its size divided by the speed.','Explain why one pile needs upward rounding.','A correct explanation keeps p and k positive, counts full groups, and assigns a whole extra hour to a nonzero remainder; it does not pool spare capacity across piles.',[1,4,5]),
('necessary-and-sufficient','necessary and sufficient','exact-hours',6,'For the original hourly rule, T(k) <= h is necessary and sufficient for speed k to work.','Explain both directions of the hours test.','Each pile needs its own ceiling hours, so every schedule requires at least their sum; finishing one pile and then the next achieves that sum. Keep the one-pile-per-hour restriction.',[1,4,6]),
('running-total','running total','scalar-execution',7,'The calculation keeps a running total of pile hours without storing a list of contributions.','Describe what hours stores during the scan.','hours begins at zero for the proposed speed, adds one per-pile ceiling at a time, and equals the sum for processed piles; the supplied piles are unchanged.',[5,7,17]),
('monotone','monotone','monotone-range',8,'The feasibility test is monotone because increasing the speed cannot increase any pile’s required hours or their sum.','Explain why a failed speed rules out slower speeds.','T(k) is a sum of non-increasing pile-hour counts. If T(k) > h, a slower speed cannot have a smaller total. Do not claim strict decrease: speeds 4 and 5 in the worked example both need eight hours.',[6,8,9,14]),
('inclusive-interval','inclusive interval','interval-invariant',10,'The inclusive interval [1, M] contains the minimum feasible speed because speeds are positive and speed M uses n hours, with h >= n.','Justify both initial endpoints of the speed search.','The searched objects are positive integer speeds. M is the largest pile and finishes every pile in one hour; h >= n makes M feasible. Both endpoints are included.',[1,2,10]),
('invariant','invariant','interval-invariant',11,'At each iteration’s start, the invariant keeps the minimum feasible speed in [low, high] and keeps high feasible.','Explain how both branches preserve the invariant.','Failure excludes mid and all slower speeds, so low becomes mid + 1 while feasible high remains. Success keeps mid as feasible high and excludes only larger speeds. At one remaining candidate, the invariant identifies the minimum.',[8,10,11,12,18,19]),
('bounded-integer','bounded-integer cost model','bounded-cost',22,'Under the bounded-integer cost model, n-element scans and repeated halving give O(n * (1 + log M)) time and fixed live scalar state gives O(1) auxiliary space.','Derive time and auxiliary space under the stated model.','Define n as pile count and M as largest pile. Bounded reads, comparisons and arithmetic count as constant work. One initial n scan plus at most ceil(log2 M) complete n scans yields n + n * ceil(log2 M). Fixed scalars and transient bounded values remain live, excluding input; arbitrary-length integers need separate bit-size analysis.',[2,10,22,23,24,25]),
('ascending-search','ascending search','ascending-alternative',26,'Ascending search performs a complete n-pile scan for each speed through the first successful speed a, for n * a pile visits.','Compare ascending search with range skipping.','All earlier speeds are explicitly rejected, so first success is minimal. Since a <= M, worst-case time is O(nM), reached by one pile M with h = 1. It reuses scalar state under the same bounded model. Tiny fixed M can justify simpler control flow, without a speed guarantee.',[6,10,22,23,26]),
('capacity','capacity','pooled-alternative',27,'If Koko may switch piles within an hour and use the entire capacity across them, h * k >= S is sufficient as well as necessary.','State the changed rule and derive the new minimum speed.','Only the changed task permits mid-hour pile switches. Its h * k capacity bounds total consumption and can be attained across pile boundaries until bananas run out, so the minimum integer k is (S + h - 1) // h. One n-pile sum and fixed bounded arithmetic cost O(n) time and O(1) auxiliary space. Original [4, 4], h = 3 forbids pooling.',[1,2,3,5,22,27])]
for key,term,decision,idx,sentence,cue,oracle,ids in active:
    item={'id':'koko-'+key,'term':term,'sense':decision,'decision_id':decision,'paragraph_index':idx,'source_git_blob':m['source']['git_blob'],'english_source_git_blob':m['english_source']['git_blob'],'production_sentences':[sentence],'self_expression_cue':cue,'oracle':oracle,'supporting_sources':refs(ids),'learner_evidence':'NOT_OBSERVED'}
    m['active_items'].append(item); m['paragraph_annotations'][idx]['role']='PASSIVE_AND_ACTIVE'; m['paragraph_annotations'][idx]['active_item_ids'].append(item['id'])
m['reading_projection']['semantic_verification']='OWNER_REVIEW_PENDING'
def write_json(name,value): (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
write_json('first-draft-manifest.json',m)
write_json('manifest.json',m)
records=[]
for f in sorted(inp.rglob('*')):
    if f.is_file():
        records.append({'path':str(f.relative_to(inp)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'read_scope':'complete input text; selected passages reread for reconstruction','authority':'frozen annotation input'})
write_json('read-records.json',{'input_root':str(inp),'records':records,'outside_source_reads':[],'limitation':'External linked pages and pronunciation sources were not read; supplied article is the sole semantic evidence. Large combined displays were followed by separate complete-body reads.','CODEX_THREAD_ID':os.environ.get('CODEX_THREAD_ID')})
write_json('output.json',{'annotation_content_created':True,'publication_performed':False,'source_body_changed':False})
write_json('limitations.json',{'pronunciation':{'status':'NOT_VERIFIED','source_queries':[],'strategy':'plain-word fallback for every word','bold_spans':0},'chunks':{'status':'OWNER_REVIEWED','method':'explicit paragraph-specific syntactic boundaries and a small set of tight lexical bundles; no length or keyword splitting','recovery':'remove only ledger-recorded added marks in reverse projection-offset order; original formula slashes and brackets remain'},'learner_evidence':'NOT_OBSERVED','human_reading_speed':'NOT_OBSERVED','independent_reader':'NOT_RUN','runtime_or_publication':'NOT_RUN','source_body_defects':[]})
print(json.dumps({'paragraphs':len(p),'annotations':len(rows),'active_items':len(active),'CODEX_THREAD_ID':os.environ.get('CODEX_THREAD_ID')},ensure_ascii=False))
