import json,pathlib,copy,hashlib,difflib
b=pathlib.Path('/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko');o=b/'annotation-output/correction-01';inp=b/'annotation-input'
old=json.loads((o/'pre-feedback/manifest.json').read_text());m=copy.deepcopy(old);ps=json.loads((inp/'paragraphs.json').read_text())
def ref(idx):return {'paragraph_index':idx,'english_quote':ps[idx]['english_source']}
a=m['paragraph_annotations'][10]
a['reading_context']['premises'][1]['text']='答案是正整數 speed，因此至少為 1；speed M 已可行，所以最小可行速度不超過 M，且可能恰好等於 M。'
a['reading_context']['premises'][1]['supporting_sources'].append(ref(21))
# Dependent summary did not reverse the bound, but explicitly retain its legal equality case.
interval_item=next(x for x in m['active_items'] if x['id']=='koko-inclusive-interval')
interval_item['oracle']='The searched objects are positive integer speeds. M is the largest pile and finishes every pile in one hour; h >= n makes M feasible. Both endpoints are included. The minimum can equal M: when h = n, every pile must fit into one hour and the largest pile requires speed M.'
interval_item['supporting_sources'].append(ref(21))
interval=next(x for x in m['decisions'] if x['id']=='interval-invariant')
interval['oracle']=' '.join(x['oracle'] for x in m['active_items'] if x['decision_id']=='interval-invariant')
# State the forward conditional licensed by paragraph 27, without a universal reverse implication.
a=m['paragraph_annotations'][27]
a['zh_note']='在這個允許一小時內跨堆並用滿容量的改題中，h * k >= S 既必要又充分，答案為 ceiling(S / h)。單次累加 S 加固定算術為 O(n) time、O(1) auxiliary；這個總量判準不能通用於原題，[4,4]、h = 3 就會失敗。'
d=next(x for x in m['decisions'] if x['id']=='pooled-alternative')
d['passive']='此改題允許一小時內跨堆用滿容量，因此 h * k >= S 可判定可行，並得到最小速度 ceiling(S/h)。'
capacity=next(x for x in m['active_items'] if x['id']=='koko-capacity')
capacity['oracle']='In the changed task, Koko may switch piles within an hour; the original task forbids this. The changed task can attain total capacity h * k across pile boundaries until bananas run out, so h * k >= S is necessary and sufficient and the minimum integer k is (S + h - 1) // h. One n-pile sum and fixed bounded arithmetic cost O(n) time and O(1) auxiliary space. Original [4, 4], h = 3 shows that the total-capacity criterion is not a general feasibility test for the original task.'
d['oracle']=capacity['oracle']
# Keep all original identity, English tokens, checkpoints, cues and bodies. No other content is rewritten.
assert m['source']==old['source'] and m['english_source']==old['english_source']
for a0,a1 in zip(old['paragraph_annotations'],m['paragraph_annotations']):
 assert a0['english_source']==a1['english_source'] and a0['speed_reading']==a1['speed_reading']
changes=[]
def compare(a,z,path=''):
 if type(a)!=type(z):changes.append({'path':path,'before':a,'after':z});return
 if isinstance(a,dict):
  assert a.keys()==z.keys()
  for k in a:compare(a[k],z[k],path+'/'+k)
 elif isinstance(a,list):
  if len(a)!=len(z):changes.append({'path':path,'before':a,'after':z})
  else:
   for j,(x,y) in enumerate(zip(a,z)):compare(x,y,path+'/'+str(j))
 elif a!=z:changes.append({'path':path,'before':a,'after':z})
compare(old,m)
(o/'revised-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
(o/'exact-delta.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
(o/'manifest.diff').write_text(''.join(difflib.unified_diff((o/'pre-feedback/manifest.json').read_text().splitlines(True),(o/'revised-manifest.json').read_text().splitlines(True),fromfile='pre-feedback/manifest.json',tofile='revised-manifest.json')))
(o/'output.json').write_text(json.dumps({'annotation_content_created':True,'publication_performed':False,'source_body_changed':False},indent=2)+'\n')
# Boundary/countermechanism calculations from the article's ceiling test; not a Reader answer.
witnesses=[]
for piles,h in [([4,4],2),([1],1),([4,4],3),([3,6,7,11],8)]:
 M=max(piles);S=sum(piles);rows=[]
 for k in range(1,M+1):
  total=sum((p+k-1)//k for p in piles)
  rows.append({'k':k,'T':total,'original_feasible':total<=h,'capacity_feasible':h*k>=S})
 minimum=next(r['k'] for r in rows if r['original_feasible'])
 witnesses.append({'piles':piles,'h':h,'M':M,'minimum_original':minimum,'minimum_pooled':(S+h-1)//h,'feasible_original_strictly_below_M':any(r['original_feasible'] and r['k']<M for r in rows),'criteria_agree_for_this_instance_through_M':all(r['original_feasible']==r['capacity_feasible'] for r in rows),'rows':rows})
assert witnesses[0]['minimum_original']==4 and not witnesses[0]['feasible_original_strictly_below_M']
assert witnesses[0]['criteria_agree_for_this_instance_through_M']
assert witnesses[1]['minimum_original']==1 and not witnesses[1]['feasible_original_strictly_below_M']
assert witnesses[2]['minimum_original']==4 and witnesses[2]['minimum_pooled']==3
(o/'boundary-checks.json').write_text(json.dumps({'method':'Evaluated article per-pile ceiling expression for every k in [1,M] in these bounded cases. For k>M every positive pile takes one hour, and h>=n makes both criteria true; no measured performance or learner inference.','witnesses':witnesses},ensure_ascii=False,indent=2)+'\n')
# Record only allowed actual artifact reads for this correction, never Reader material.
reads=[inp/'paragraphs.json',inp/'field-shape.json',o/'pre-feedback/manifest.json',o/'pre-feedback/semantic-review.md']
(o/'read-records.json').write_text(json.dumps({'scope':'First feedback-directed correction of existing generation; not blind generation','records':[{'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'purpose':'source/shape or own prior-output adjudication'} for f in reads],'Reader_report_read':False,'expected_answers_read':False,'other_outputs_read':False,'instructions':'Original allowed frozen instructions were retained from first generation; no new instruction paths read.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'changed_json_paths':[x['path'] for x in changes],'revised_manifest':str(o/'revised-manifest.json')},ensure_ascii=False))
