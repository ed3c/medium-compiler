# Koko annotation Owner semantic review

Review scope: the complete supplied English and Traditional Chinese bodies, all 35 notes, full structured English projections, reading contexts/cues, nine derived decision/concept IDs and nine Active items. This is the annotation author's review, not an independent Reader verdict. No external source pages, other article outputs, author reviews, Reader results or expected answers were read. The article's references remain its attribution; this task did not independently verify those external pages.

## Draft history and actual corrections

`first-draft-manifest.json` is the actual first complete annotation draft, written before final review. Its semantic content was authored individually; the script only binds supplied paragraph text and IDs and applies explicitly selected formatting offsets. The initial template/natural-language contract omitted serialized entry shapes. I told the parent the provisional shape. The parent subsequently supplied input `field-shape.json`, containing existing consumer fields and types without semantic examples. The pre-adaptation manifest is additionally preserved in `pre-field-shape-manifest.json`. `first-structured-draft-manifest.json` preserves the adaptation before final acceptance. No failures or drafts were deleted.

The first shape was unsuitable for the existing consumer: `role`/`decision_id`/inline projection were replaced with `kind`/`decision_ids`/`speed_reading.tokens`. These are mechanical repairs using the supplied field shape. Exact source slashes and brackets now remain token text; rendering markers are separate fields.

Semantic corrections during that adaptation: paragraph 28's checkpoint initially included the review fact that no learner response was observed. That is not an article state checkpoint, so it is now null; learner evidence remains a limitation outside article notes. Paragraph 17's premise initially generalized beyond this implementation's variable naming. It now describes only this implementation's scalar state. Neither correction changes the source body or supplies an absent body argument.

## Reconstruct the main claim and test direction

The domain is a nonempty positive-integer pile list and a positive-integer speed, with h >= n. Paragraph 1 explicitly says, “Finishing that pile early does not let her start another pile during the same hour.” For each pile, paragraph 4 counts complete groups and a nonzero remainder as a full extra hour. Paragraph 5 supplies both remainder cases for the exact integer expression. Paragraph 6 then establishes both directions: “Each pile requires its own hours, so any valid schedule needs at least T(k) hours.” Its next sentence supplies a schedule achieving that lower bound: “Eating one pile to completion and then the next achieves exactly that total.” Thus the necessary-and-sufficient note has an actual lower-bound/achievability argument, not just a quoted predicate.

Paragraph 8 explains why every per-pile count is non-increasing with speed and why summing preserves direction. This licenses excluding slower speeds after a failed probe. The reverse implication is narrower: successful k establishes an upper bound on the minimum, not equality with that minimum. Paragraph 14's 6-versus-4 witness refutes immediate return, and 4/5 both needing eight hours refutes strict decrease or return-on-equality. Neither “monotone” note nor Active oracle claims every speed increase reduces hours.

An example of attaining the lower bound is sufficient to prove achievability; it does not prove that every valid schedule must finish each pile before visiting another. A different legal schedule could interleave whole hours among piles and attain the same sum. The notes say sequential completion achieves the sum; they never require that schedule as the only mechanism. Likewise the particular low/high variable names and wrapper are properties of this displayed implementation, not necessities for every correct algorithm. Ascending search in paragraph 26 is an explicit legal alternative to binary search.

## State, observation boundary and progress

Paragraph 10 constructs [1,M]: positivity gives the lower bound; M is the largest pile, so n one-hour pile visits are enough, and h >= n makes high feasible. Paragraph 11 fixes the observation point: “At the start of every search iteration”. Both facts matter: merely containing some feasible candidate would not establish that the minimum remains inside. Paragraph 18 uses each branch to preserve minimum containment and feasible high. After an unsuccessful mid, all speeds at most mid fail and high stays feasible. On success, mid becomes feasible high and remains eligible to be the minimum. Paragraph 19 proves strict integer-candidate reduction with low <= mid < high. At low == high, containment plus feasibility identifies the answer; there is no logical need for one further test.

The erroneous update in paragraph 20 produces [1,2] -> mid 1 -> fail -> [1,2]. That violates progress without necessarily violating containment. This distinguishes termination from the invariant rather than treating either word as a substitute for proof. Changing h to be below n invalidates initial feasible high; retaining the update rules cannot repair the now-impossible original task.

New article-rule-only witness, checked arithmetically by `verify_annotations.py`: piles [5,8], h=5. [1,8], mid=4 gives 2+2=4, so [1,4]. Mid=2 gives 3+4=7, so [3,4]. Mid=3 gives 2+3=5, so [3,3], return 3. Speed 2 fails and speed 3 succeeds. Each discard and stop follows paragraphs 4–6, 8, 12, 18–19. This local arithmetic witness is not a full production runtime or learner measurement.

## Cost reconstruction, including alternatives

The assumed elementary model is stated in paragraph 22, not inferred from Python syntax: “reading a list element, comparing these integers, and doing arithmetic on values within this problem's limits each count as constant work.” The range bound uses n <= 10^4 and M <= 10^9, with hours <= n*M <= 10^13. No note equates these abstract work units with equal wall-clock latency.

Paragraph 23 counts n visits in the initial largest-pile scan and n visits with a fixed amount of work per pile in each complete test. Paragraph 24 explains even and odd candidate splits, leaves at most ceil(L/2), then bounds remaining candidates by ceil(M/2^t). Requiring 2^t >= M gives at most ceil(log2 M) tests. Consequently work is bounded by constants times n + n*ceil(log2 M). M=1 has no search tests but still the initial n visits, so the annotation retains O(n*(1+log M)); the abbreviated O(n log M) is conditional on M>=2. The “at most thirty” assertion follows from 2^30 > 10^9, without claiming thirty tests always occur.

Paragraph 25 explains retained versus replaced values: “Reassigning hours or an endpoint replaces its previous value; it does not retain one entry per pile or per iteration.” A fixed number of scalar/traversal and temporary bounded values is live. That supports O(1) auxiliary space excluding supplied input and a separate single-integer O(1) output under the bounded model. Arbitrary-length integer inputs defeat that scalar-size assumption; notes and the Active oracle retain the explicit bit-size caveat.

Ascending search reuses the same exact per-pile test, bounds and elementary work assumptions, but changes frequency: paragraph 26 tests every speed through answer a, a complete scans or n*a pile visits, at most n*M. Its single-pile M with h=1 witness attains M scans. Reusing the running total rather than retaining contributions/history preserves the fixed live-state argument. A tiny fixed M can favor simpler control flow; that is not a claim of lower measured time. Changing M to 10^9 removes that practical simplicity argument for enumerating all speeds. Thus both cost and design boundary have body explanations.

The changed hourly task is a different premise, explicitly introduced in paragraph 27: “Suppose Koko could switch piles within an hour and use the entire capacity k across them.” Necessity is total supply S <= h*k; sufficiency is the stated achievable continuous cross-pile consumption until supply ends. Integer rounding from paragraph 5 yields (S+h-1)//h. Frequency changes to one sum of n elements plus fixed bounded arithmetic. Only S and loop/scalar state are retained, so time O(n), auxiliary O(1), one integer output under paragraph 22's model. For this task S <= n*M; this bound is already within the article's numeric model. Reverting to original [4,4], h=3 invalidates sufficiency of total capacity: formula says 3 while per-pile hours total four. No note treats the changed-task formula as valid in the original task.

No needed inference in these reconstructed paths was supplied from an external solution, author notes or private knowledge. The calculations combine explained body premises and declared elementary costs. No missing-body defect was found within this bounded review; that finding is not universal article correctness or Reader reliability.

## Every-paragraph whole-annotation review

Each item below reviews the note together with its full English projection and linked reading context; the question cue is supplemental. The manifest contains exact full-paragraph English quotes for all named supporting indices, so retained summaries and Active dependencies are navigable rather than relying on this sidecar alone.

- 0: Summary is conditional on the exact test (1,4,6) and non-increasing direction (8,9); it does not claim any arbitrary failed function value licenses binary search.
- 1: One positive speed, a nonempty positive list and one pile per hour are preserved. The changed rule at 27 is not imported here.
- 2: n is pile count; one hour per positive pile plus M's feasibility at 10 explains h>=n. “Outside contract” is not conflated with an empty-list result.
- 3: The [4,4] totals are separate ceilings; k=3 uses four hours, whereas k=4 uses two. Total bananas divided by h fails exactly at no-sharing premise.
- 4: p,k positive and the whole-hour remainder rule license ceiling; the example is an instance, not proof of a unique scheduling order.
- 5: The quotient/remainder cases preserve 0<=r<k. Negative or zero divisor inputs would not inherit this rounding derivation.
- 6: Distinguishes lower bound for every schedule from one schedule attaining it. Only the two directions together establish the exact test; arbitrary pile order has the same sum.
- 7: After each completed pile contribution, hours equals the processed-prefix total. Before all piles are scanned it is not the completed T(k); no list allocation or input mutation is asserted.
- 8: Each per-pile non-increase is summed; plateaus are allowed and the failing prefix may be empty. Does not assert strict decrease or that every legal instance has a failing speed.
- 9: Failure at 6 rejects <=6; success at 6 yields minimum<=6. The note expressly leaves smaller success unresolved.
- 10: [1,M] relies on positivity and h>=n. Speeds, not pile positions, are stored; h<n breaks feasibility and cannot be rescued by sorting.
- 11: The invariant is anchored to iteration start and has two clauses; the context does not substitute global monotonicity for present-state containment.
- 12: Hours calculation precedes endpoint update; lower middle and two asymmetric assignments preserve the successful mid and remove failed mid. Return is at equal endpoints.
- 13: High is 1 before largest-pile scan and 11 after it; resetting hours concerns each new speed, not accumulating totals from multiple probes.
- 14: This specific trace distinguishes first success 6 from minimum 4, and exact deadline equality from minimality. It does not assert an equality test can never be part of a different correct algorithm.
- 15: The final partial hour belongs to the 11-banana pile under the original rule, supporting the specific rejection of cross-pile pooling.
- 16: Prefix maximum is checked after each read item; initial 1 follows positive pile sizes. Solution/self statements describe this code only and do not establish all wrappers are stateless.
- 17: Current implementation resets hours per speed and uses scalar +=; positivity follows [1,M] and updates. Revised premise does not generalize variable choices to all implementations.
- 18: Each branch is considered under the pre-iteration invariant. Unchanged feasible high on failure and feasible mid on success separately preserve both clauses.
- 19: Nonempty candidate set, strict integer-count decrease, and invariant at equal endpoints together justify termination/minimality. A final redundant test is not required.
- 20: [2],h=1 demonstrates lack of progress with low=mid; failure removal with +1 is specific to this lower-middle inclusive algorithm, not every binary search convention.
- 21: All-one, h=n and h>=total cases preserve their distinct assumptions; h<n has no solution under the original positive-pile hourly rule. M=1 skips while but not the initial maximum scan.
- 22: The bounded elementary work model is stated explicitly; integer exactness does not imply arbitrary bit-size arithmetic is constant work.
- 23: Full n scans and fixed operations give the proportional bound under 22. An early-exit alternative is not falsely described as the displayed code.
- 24: Both candidate group sizes and n-work frequency are linked, not only the O expression. The additive initial scan remains for M=1; loop-update checkpoint tracks t completed halvings.
- 25: Live values are counted, not all scalar assignments ever performed. Input, auxiliary and output conventions and bit-size limitation remain explicit.
- 26: First success is minimal because every earlier speed has been tested. The n*a calculation and a<=M bound are linked to the exact test and model; tiny M is a conditional simplicity choice, not a speed theorem.
- 27: The hypothetical switch-within-hour rule is indispensable to sufficiency. Full capacity achievement and one-sum operation/storage counts support both formula and costs; original-task counterexample remains linked.
- 28: An exercise invitation has input premises but no algorithm-state checkpoint or learner outcome. The cue asks for justification, without revealing a fabricated human answer.
- 29: Three actual proposed speeds, totals, updates and sole candidate follow the same test and invariant. The final failure removes 1; minimum 2 is not inferred from success alone.
- 30: Interview recall links 1,6,8,10 as well as the retained summary at 30. Ordered speeds and non-increasing hours explain no pile sorting; feasibility need not actually change on every instance.
- 31: Interview recall links hourly ownership, remainder calculation and the lower-bound/achievable schedule at 6. “Sum” is not just an unexplained quotation at 31.
- 32: Interview recall keeps both invariant clauses and both branch reasons via 8,11,18–19. The checkpoint remains the complete update and eventual equal endpoints.
- 33: Interview recall links bounded primitive costs, complete n scans, candidate halvings, fixed live state and excluded input. The formula is not treated as its own proof.
- 34: The note describes the article's attribution, not independent retrieval of LeetCode/Python. Complete earlier body arguments are linked, so a source URL is not offered as a missing explanation.

## Active, syntactic projection and retained summaries

The nine Active terms were selected for the decisions they help explain, not a quota. `ceiling` binds positive p/k, remainder and hourly rule; `necessary and sufficient` binds both lower-bound and achievable-schedule directions; `running total` binds accumulator updates/reset; `monotone` binds per-pile direction, summation and plateau counterexample; `inclusive interval` binds speed domain and feasible M; `invariant` binds initialization, both branches and stop; `bounded-integer cost model` binds primitive assumptions, frequencies, halving and live storage; `ascending search` binds explicit rejected-prefix minimality, n*a scans and model; `capacity` binds the changed rule, achievable aggregate capacity and original-task counterexample. Every item has a source-attested exact term, exact primary source quote, complete faithful English sentence, cue/oracle and all cross-paragraph premises. Source → decision → term → sentence → oracle links were checked. The summary decisions and combined decision-level oracles preserve the same scope; none demands this mechanism be the only correct implementation.

I inspected all explicit formatting selections against sentence syntax. Major boundaries split meaningful sentences or coordinate/causal clauses while retaining their original punctuation and scope; minor boundaries attach the following prepositional/appositional/participial phrase. No formula, identifier or existing slash/bracket is split as an added marker. Bundles enclose selected tight noun/comparative/prepositional units without changing source text. The full English projection remains visible; no cue replaces it. Cue strings are questions and all have at most fifteen whitespace-separated words. Chunk length was not enforced mechanically.

Pronunciation sources were unavailable within the allowed read set. Every word remains plain; stress lists are omitted, and no claim of reviewed prosody is made. Structured token concatenation verifies exact paragraph text, but does not itself prove syntax or semantic scope. Original English and Chinese body bytes were not changed. This task authored no body, Git/CI/provider/publication changes and no learner session. Four encounters remain a design for the same source text; production targets do not establish mastery. Reading speed, human benefit, latency, independent Reader response and delayed recall are NOT_OBSERVED/NOT_RUN.

Final Owner judgment: complete source-bound annotation content is ready for the parent's existing consumer validation. No unresolved source-body defect was identified in this review. This does not authorize publication or imply validation by the repository consumer, which this isolated owner did not read or run.
