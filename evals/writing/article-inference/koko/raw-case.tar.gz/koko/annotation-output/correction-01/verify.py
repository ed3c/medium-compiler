import json,pathlib,hashlib
b=pathlib.Path('/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko'); o=b/'annotation-output'; c=o/'correction-01';i=b/'annotation-input'
m=json.loads((c/'revised-manifest.json').read_text());p=json.loads((i/'paragraphs.json').read_text());old=json.loads((c/'pre-feedback/manifest.json').read_text());snap=json.loads((c/'snapshot-record.json').read_text())
for f in snap['files']:
 assert hashlib.sha256((o/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
 assert hashlib.sha256((c/'pre-feedback'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
def refs(xs):
 assert xs
 for x in xs:assert x['english_quote'] and x['english_quote'] in p[x['paragraph_index']]['english_source']
assert [a['paragraph_index'] for a in m['paragraph_annotations']]==list(range(35))
ids={d['id'] for d in m['decisions']}; assert len(ids)==len(m['decisions'])
for a in m['paragraph_annotations']:
 assert a['english_source']==p[a['paragraph_index']]['english_source']
 assert ''.join(t['text'] for t in a['speed_reading']['tokens'])==a['english_source']
 assert len(a['speed_reading']['skeleton'].split())<=15
 assert set(a['decision_ids'])<=ids
 for r in a['reading_context']['premises']:refs(r['supporting_sources'])
 if a['reading_context']['checkpoint']:refs(a['reading_context']['checkpoint']['supporting_sources'])
for a in m['active_items']:
 assert a['term'] in p[a['paragraph_index']]['english_source'];assert a['source_quote'] in p[a['paragraph_index']]['english_source']
 assert a['decision_id'] in m['paragraph_annotations'][a['paragraph_index']]['decision_ids']; refs(a['supporting_sources'])
 assert a['english_sentence'] and a['active_cue'] and a['oracle']
for name,key in [('article.en.md','english_source'),('article.zh-TW.md','source')]:
 raw=(i/name).read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==m[key]['git_blob']
assert m['source']==old['source'] and m['english_source']==old['english_source']
assert all(a['english_source']==z['english_source'] and a['speed_reading']==z['speed_reading'] for a,z in zip(m['paragraph_annotations'],old['paragraph_annotations']))
r={'annotation_coverage':35,'active_items':9,'exact_quote_bindings':True,'lossless_structured_english':True,'all_cues_at_most_15_words':True,'original_top_level_and_snapshot_files_unchanged':len(snap['files']),'source_blobs_unchanged_and_match_bodies':True,'source_text_and_tokens_unchanged_from_original':True,'semantic_acceptance':'See revision-report.md; mechanical success is not semantic proof.','publication_performed':False,'source_body_changed':False}
(c/'checks.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
