import json,pathlib,hashlib
b=pathlib.Path('/var/folders/l6/44bf7nvs64j60f1mpyy88hdm0000gn/T/article-entailment-2x13kv72/koko'); o=b/'annotation-output'; i=b/'annotation-input'
m=json.loads((o/'manifest.json').read_text()); p=json.loads((i/'paragraphs.json').read_text()); issues=[]
def check_sources(refs,label):
    assert refs,label
    for ref in refs:
        assert isinstance(ref['paragraph_index'],int),label
        assert ref['english_quote'] and ref['english_quote'] in p[ref['paragraph_index']]['english_source'],label
ids={d['id'] for d in m['decisions']}; assert len(ids)==len(m['decisions'])
assert [a['paragraph_index'] for a in m['paragraph_annotations']]==list(range(35))
for a in m['paragraph_annotations']:
    idx=a['paragraph_index']; assert a['english_source']==p[idx]['english_source']
    assert ''.join(t['text'] for t in a['speed_reading']['tokens'])==p[idx]['english_source']
    assert len(a['speed_reading']['skeleton'].split())<=15,(idx,a['speed_reading']['skeleton'])
    assert a['speed_reading']['skeleton'].endswith('?'),idx
    assert set(a['decision_ids'])<=ids
    assert a['kind'] in ('PASSIVE','PASSIVE_AND_ACTIVE')
    assert a['zh_note'] and a['reading_context']['premises']
    for premise in a['reading_context']['premises']:check_sources(premise['supporting_sources'],str(idx))
    checkpoint=a['reading_context']['checkpoint']
    if checkpoint is not None:check_sources(checkpoint['supporting_sources'],str(idx))
    for t in a['speed_reading']['tokens']:
        assert t['break_before'] in (None,'minor','major')
        assert not t.get('stress')
active_ids=set()
for a in m['active_items']:
    assert a['id'] not in active_ids; active_ids.add(a['id'])
    raw=p[a['paragraph_index']]['english_source']
    assert a['term'] in raw,(a['id'],a['term'])
    assert a['source_quote'] in raw
    assert a['decision_id'] in m['paragraph_annotations'][a['paragraph_index']]['decision_ids']
    assert m['paragraph_annotations'][a['paragraph_index']]['kind']=='PASSIVE_AND_ACTIVE'
    assert a['english_sentence'] and a['active_cue'] and a['oracle']
    check_sources(a['supporting_sources'],a['id'])
for d in m['decisions']:
    assert d['title'] and d['passive']
    if any(a['decision_id']==d['id'] for a in m['active_items']):assert d['active_cue'] and d['oracle']
# New arithmetic witness follows the published test and transitions, without reading a solution elsewhere.
lo,hi=1,8; trace=[]
while lo<hi:
    mid=(lo+hi)//2; hours=sum((x+mid-1)//mid for x in [5,8]); before=[lo,hi]
    if hours>5:lo=mid+1
    else:hi=mid
    trace.append({'before':before,'mid':mid,'hours':hours,'after':[lo,hi]})
assert lo==3
checks={'paragraph_count':35,'lossless_token_reconstruction':True,'exact_quote_bindings':True,'cue_questions_at_most_15_words':True,'known_unique_decisions_and_active_ids':True,'source_attested_active_terms':True,'verified_stress_spans':0,'new_arithmetic_witness':{'piles':[5,8],'h':5,'trace':trace,'result':lo},'source_body_identities':{name:hashlib.sha256((i/name).read_bytes()).hexdigest() for name in ['article.en.md','article.zh-TW.md']},'limits':'These deterministic checks establish identity, shape and arithmetic for the stated witness; semantic acceptance remains the separate Owner review, not a real Reader or learner measurement.'}
(o/'mechanical-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(checks,ensure_ascii=False))
