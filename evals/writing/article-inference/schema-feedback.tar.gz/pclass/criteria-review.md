# P-class 動作條件審查

審查者：/root/entailment_criteria（native condition reviewer）。

koko 與 intervals 的四個預期動作均有支持：完整雙語閱讀 true、建立註解內容 true、改動來源正文 false、執行發布 false。精確引文與逐欄理由見 criteria-review.json；schema、protocol_sha256、case 與 field identity 保留模板值。

原始需求直接支持註解產出與來源／發布邊界。完整雙語閱讀由 protocol 明確列入且 task 選用的 speed-reading 指令直接規定。更新原 PR 屬完整任務的授權；此註解消費者禁止 Git 寫入，並無衝突。

本審查評估預期條件，沒有讀取 Writer 產物，也沒有觀察實際執行。建立內容不等於完整或正確，完整閱讀不等於理解，未改來源不等於新增主張正確，未發布不等於網站驗收成功。這兩個條件審查均不能支持通用流程穩定性或人類學習效果。

讀取紀錄為審查者自身工具紀錄，未經外部讀取監控；未計算或自行驗證摘要。
